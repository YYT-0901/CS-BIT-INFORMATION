function ProhibitAccount(nowplace) {
    var number = nowplace.parentNode.parentNode.children[0];//学工号节点
    var flag = true;
    if (nowplace.innerHTML == '禁用') {
        flag = confirm("你是否确认要禁用学工号为" + number.innerHTML + "的账户?")
        if (flag) {
            var nowstate = nowplace.parentNode.parentNode.children[2];
            nowstate.style.color = 'red';
            nowstate.innerHTML = "禁止";
            nowplace.innerHTML = "解禁";
        }
    }
    else if (nowplace.innerHTML == '解禁') {
        flag = confirm("你是否确认要解禁学工号为" + number.innerHTML + "的账户?")
        if (flag) {
            var nowstate = nowplace.parentNode.parentNode.children[2];
            nowstate.style.color = 'rgb(10, 179, 10)';
            nowstate.innerHTML = "正常";
            nowplace.innerHTML = "禁用";
        }
    }
}

function DelAccount(nowplace) {
    var number = nowplace.parentNode.parentNode.children[0];
    var flag = confirm("你是否确认要删除学工号为" + number.innerHTML + "的账户?")
    if (flag) {
        $.ajax({
            url: '/api/user/delete',
            type: 'post',
            data: {
                bitid: number.innerText,
            },
            success: (res) => {
                if(res.status) {
                    alert(res.message);
                }
                else {
                    nowplace.parentNode.parentNode.remove();
                }
            }
        });
    }
}
function ChangePassword(nowplace) {
    var number = nowplace.parentNode.parentNode.children[0];
    var newpassword = prompt("请输入学工号为" + number.innerHTML + "的新密码")
    if (newpassword != null && newpassword != '') {
        var oldpassword = nowplace.parentNode.parentNode.children[1];
        oldpassword.innerHTML = newpassword;
    }
}
function AccountSearch() {
    var trlist = document.getElementsByClassName('AccountTr')
    var search = document.getElementById('AccountInput');
    var list = document.getElementsByClassName('accountnumber');
    for (i = 0; i < list.length; i++) {
        trlist[i].style.display = 'table';
    }
    for (i = 0; i < list.length; i++) {
        for (j = 0; j < search.value.length; j++) {
            if (list[i].innerHTML[j] != search.value[j]) {
                trlist[i].style.display = 'none';
            }
        }
    }
    console.log(list.length);
}

function AddAccount(){
        if(document.getElementById("show").style.display="none")
        {
            document.getElementById("show").style.display="block"
        }
        document.getElementById("show").innerHTML = '<table cellspacing="1" border="1" >' + '<tr>'
            + '<td id="name">姓名：</td>' +
            '<td ><input type="text" class="input" id="addName"></td>'+
            '</tr>'+
            '<tr>'
            + '<td id="name">学工号：</td>' +
            '<td ><input type="number" class="input" id="addID"></td>'+
            '</tr>'+
            '<tr>'
            + '<td id="name">密码：</td>' +
            '<td ><input type="password" class="input" id="addPwd"></td>'+
            '</tr>'+
            '<tr>'
            + '<td id="name">身份：</td>' +
            '<td ><input type="radio" name="role" value="1">管理员 <input type="radio" name="role" value="3">教师 <input type="radio" name="role" value="2">学生</td>'+
            '</tr>'+
            '<tr>' +
            '<td colspan="2" align="center"><button id="Button2" onclick="send()" value="提交">提交</button> <button onclick="Close()">取消</button></td>'
            +'</tr>'
            + '</table>';
    }

function Close(){
    document.getElementById("show").style.display="none";
}

function send(){

    var add_name = document.getElementById("addName").value
    var add_id   = document.getElementById("addID").value
    var add_pwd  = document.getElementById("addPwd").value

    var add_role = 0
    var roleObj = document.getElementsByName("role")
    for (var i = 0; i < roleObj.length; i++) {

        if (roleObj[i].checked) {

            add_role = roleObj[i].value
        }
    }
    
    $.ajax({
        url: 'http://82.156.175.138:8000/api/user/insert',        
        type: 'post',
        headers:{'Accept': 'aplication/json','Authorization': localStorage.getItem('token')},
        data: {
            
            name : add_name,
            password : add_pwd,
            bitid : add_id,
            role : add_role,
        },
        success: (res) => {
            if (res.status) {
                alert(res.message)
            } else {
                location.reload();
            }
        }
    })
}

function AddClass(){
    var classname = prompt("课程名称");
    var tid = prompt("教师工号(若是教师则空)");
    $.ajax({
        url: 'http://82.156.175.138:8000/api/class/insert',        
        type: 'post',
        headers:{'Accept': 'aplication/json','Authorization': localStorage.getItem('token')},
        data: {
            tid : tid,
            classname : classname,
        },
        success: (res) => {
            if (res.status) {
                alert(res.message)
            } else {
                location.reload();
            }
        }
    })
}

function DeleteClass(){
    var classid = prompt("课程ID");
    $.ajax({
        url: 'http://82.156.175.138:8000/api/class/delete',        
        type: 'post',
        headers:{'Accept': 'aplication/json','Authorization': localStorage.getItem('token')},
        data: {
            cid : classid,
        },
        success: (res) => {
            if (res.status) {
                alert(res.message)
            } else {
                location.reload();
            }
        }
    })
}