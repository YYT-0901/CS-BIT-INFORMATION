#include<stdio.h>

int main(){
	int n;
	while(~scanf("%d",&n))
	{
		int a[105]={0};
		int k=0,i=0,j=-1,num=1;
		while(k<n)
		{
			k++;
			i=0;
			while(i<k){
				++j;
				j%=n;
				if(a[j]==0)
				{
					++i;
				}
				if(i==k)
				{
					a[j]=k;
					break;
				}
			}
		}
		for(int i=0;i<n;++i)
		{
			if(i==0)
			{
				printf("%d",a[i]);
			}
			else
			{
				printf(" %d",a[i]);
			}
		}
		printf("\n");
	}
	return 0;
} 
