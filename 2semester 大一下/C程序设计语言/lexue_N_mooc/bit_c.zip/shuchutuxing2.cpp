#include<stdio.h>

int main(){
	int n,k=0;
	char c;
	char a[200][200]={0};
	scanf("%d %c", &n,&c);
	if(c>='a' && c<='z')
	{
		c-=32;
	}
	else if(c>='A' && c<='Z');
	else{
		printf("input error!\n");
		return 0;
	}
	if(n%2 == 0)
	{
		printf("input error!\n");
		return 0;
	}
	for(int i=0;i<n;++i)
	{
		for(int j=0;j<n;++j)
		{
			a[i][j]=c++;
			if(c>'Z')
			{
				c = 'A';
			}
			k=j;
		}
		c = a[i][k-n+2];
	}
	for(int i=0;i<n;++i)
	{
		for(int j=0;j<n;++j)
		{
			if(i>0 && i<n-1 && j>0 && j<n-1)
			{	
				if(j == n/2)
				{
					printf("%c", a[i][j]);
					continue;
				}
				printf(" ");
				continue;
			}
			printf("%c", a[i][j]);
		}
		printf("\n");
	}
	return 0;
}