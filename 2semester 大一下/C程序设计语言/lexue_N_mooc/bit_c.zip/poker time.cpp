#include<stdio.h>

int main(){
	char a[5][10];
	int swap;
	int n=0,b=0,yyt=0;
	gets(a[0]);
	gets(a[1]);
	for(int k=0;k<2;++k)
	{
		for(int i=2;i<8;i+=3)
		{
			if(a[k][i]=='0')
			{
				for(int j=i;j<10;++j)
				{
					a[k][j]=a[k][j+1];
				}
			}
		}
	}
	for(int k=0;k<2;++k)
	{
		for(int i=1;i<8;i+=3)
		{
			if(a[k][i]!='J' && a[k][i]!='A' && a[k][i]!='K' && a[k][i]!='Q')
			{
				yyt=1;
				if(a[k][i]>=49 && a[k][i]<=57)
				{
					yyt=0;
				}
			}
			if(yyt==1) 
			{
				break;
			}
			if(a[k][i]=='K')
			{
				a[k][i]='R';
			}
			else if(a[k][i]=='A')
			{
				a[k][i]='U';
			}
			else if(a[k][i]=='1')
			{
				a[k][i]='B';
			}
		}
		if(yyt==1) 
		{
			break;
		}
		for(int i=0;i<7;i+=3)
		{
			if(a[k][i]!='H' && a[k][i]!='S' && a[k][i]!='D' && a[k][i]!='C')
			{
				yyt=1;
			}
			if(yyt==1) 
			{
				break;
			}
			if(a[k][i]=='H')
			{
				a[k][i]='T';
			}
		}
		if(yyt==1) 
		{
			break;
		}
		for(int i=1;i<5;i+=3)
		{
			for(int j=i+3;j<8;j+=3)
			{
				if(a[k][i-1]<a[k][j-1])
				{
					swap=a[k][i];
					a[k][i]=a[k][j];
					a[k][j]=swap;
					swap=a[k][i-1];
					a[k][i-1]=a[k][j-1];
					a[k][j-1]=swap;
				}
				else if(a[k][i-1]==a[k][j-1])
				{
					if(a[k][i]<a[k][j])
					{
					 	swap=a[k][i];
						a[k][i]=a[k][j];
						a[k][j]=swap;
						swap=a[k][i-1];
						a[k][i-1]=a[k][j-1];
						a[k][j-1]=swap;
					}
					else if(a[k][i]==a[k][j])
					{
						yyt=1;
						break;
					}
				}
			}
			
		}
		if(yyt==1) 
		{
			break;
		}
	}
	if(yyt==0)
	{
		for(int i=1;i<8;i+=3)
		{
			if(a[0][i]<a[1][i])
			{
				++b;
			}
			else if(a[0][i]==a[1][i])
			{
				if(a[0][i-1]<a[1][i-1])
				{
					++b;
				}
				else if(a[0][i-1]>a[1][i-1])
				{
					++n;
				}
				else{
					continue;
				}
			}
			else
			{
				++n;
			}	
		}
	}
	if(yyt==1)
	{
		printf("Input Error!\n");
	}
	else{
		if(n>b)
		{
			printf("Winner is A!\n");
		}
		else if(n<b)
		{
			printf("Winner is B!\n");
		}
		else
		{
			printf("Winner is X!\n");
		}
		for(int k=0;k<2;++k)
		{
			for(int i=1;i<8;i+=3)
			{
				if(a[k][i]=='R')
				{
					a[k][i]='K';
				}
				else if(a[k][i]=='U')
				{
					a[k][i]='A';
				}
				else if(a[k][i]=='B')
				{
					a[k][i]='1';
				}
			}
			for(int i=0;i<7;i+=3)
			{
				if(a[k][i]=='T')
				{
					a[k][i]='H';
				}
			}
		}
		printf("A:");
		for(int i=0;i<7;i+=3)
		{
			printf(" ");
			for(int j=i;j<i+2;++j)
			{
				printf("%c",a[0][j]);
				if(a[0][j]=='1')
				{
					printf("0");
				}
			}
		}
		printf("\n");
		printf("B:");
		for(int i=0;i<7;i+=3)
		{
			printf(" ");
			for(int j=i;j<i+2;++j)
			{
				printf("%c",a[1][j]);
				if(a[1][j]=='1')
				{
					printf("0");
				}
			}
		}
		printf("\n");
		
	}
	return 0;
}