#include<stdio.h>
int main(){
	int n;
	int sum=25;
	while(scanf("%d",&n)!=EOF){
		int ai;
		sum-=n;
		ai=4-n;
		if(sum==0){
			printf("Game Over!\n");
			sum=25;
		}
		else{
			printf("%d\n",ai);
			sum-=ai;
		}	
	}
	return 0;
}