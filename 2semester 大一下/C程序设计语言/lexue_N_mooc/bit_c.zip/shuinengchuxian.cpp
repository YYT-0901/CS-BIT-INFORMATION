#include<stdio.h>

int main(){
	int a[15]={0},max=0;
	for(int i=1;i<11;++i)
	{
		scanf("%d",&a[i]);
		if(max<a[i])
		{
			max=a[i];
		}
	}
	for(int i=1;i<11;++i)
	{
		if(max==a[i])
		{
			printf("%d\n",i);
		}
	}
	return 0;
}
