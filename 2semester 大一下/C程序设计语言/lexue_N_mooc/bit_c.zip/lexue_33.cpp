#include<stdio.h>

int main(){
	char a[100][100];
	int n,b;
	scanf("%d%d",&n,&b);
	int l=1,k=b-2;
	int p=b-3,yyt=1;
	for(int i=0;i<b;++i)
	{
		if(n==10)
		{
			n=0;
		}
		a[0][i]=n+++'0';
	}
	while(k>0)
	{
		if(n==10)
		{
			n=0;
		}
		a[l][1]=n+++'0';
		--k;
		++l;
	}
	while(l>=1)
	{
		if(n==10)
		{
			n=0;
		}
		a[l][0]=n+++'0';
		--l;
	}
	for(int i=0;i<b;++i)
	{
		printf("%c",a[0][i]);
	}
	printf("\n");
	for(int j=1;j<b-1;++j)
	{
		for(int i=0;i<2;++i)
		{
			printf("%c",a[j][i]);
			if(yyt==1)
			{
				for(int i=0;i<p;++i)
				{
					printf(" ");
				}
				yyt=0;
			}
		}
		yyt=1;
		--p;
		printf("\n");
	}
	printf("%c\n",a[b-1][0]);
	return 0;
}