#include<stdio.h>

int main(){
	int n,m,a[100],i,k=1,p=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;++i)
	{
		a[i]=i;
	}
	while(i>1)
	{
		
		if(a[k++]!=0)
		{
			k%(n+1);
			++p;
		}
		else
		{
			k++;
			k%(n+1);
		}
		if(p==m)
		{
			p=0;
			a[k]=0;
			--i;
		}
	}
	for(int i=1;i<=n;++i)
	{
		if(a[i]!=0)
		{
			printf("%d\n",a[i]);
		}
	}
	return 0;
}
