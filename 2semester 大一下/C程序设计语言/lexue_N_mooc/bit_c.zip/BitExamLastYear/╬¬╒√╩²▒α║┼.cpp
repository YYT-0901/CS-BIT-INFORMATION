#include <stdio.h>
#include <string.h>  
struct nn  
{  int no;     
   int num;     
};  
  
typedef struct nn DATA;  
  
int number( char * , DATA []);  
  
int main( )  
{     
   DATA b[100];    
   char sa[500];    
   int i, n;    
   gets( sa );   
   n = number( sa, b );   
   for ( i=0; i<n; i++ )   
       printf("%d %d\n", b[i].num, b[i].no );   
   return 0;  
}  
  
int number( char * str, DATA a[] ) 
{ 
	int k=0;
	int count = 0;
	for(int i=0;i<strlen(str);i+=2)
	{
		a[k++].num = str[i] - '0';
	}
	for(int i=0;i<(strlen(str)+1)/2;++i)
	{
		for(int j=0;j<(strlen(str)+1)/2;++j)
		{
			if(a[i].num >= a[j].num)
			{
				if(a[i].num == a[j].num && i<j);
				else{
					++count;
				}
			}
		}
		a[i].no = count;
		count = 0;
	}
	return (strlen(str)+1)/2;
}