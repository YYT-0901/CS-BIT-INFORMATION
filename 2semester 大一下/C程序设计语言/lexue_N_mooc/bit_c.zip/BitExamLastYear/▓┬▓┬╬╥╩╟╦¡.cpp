#include<stdio.h>
#include<string.h>
int main()
{
	char s[20],line[10],ch;
	int num,i=0,numread;
	FILE* fp;
	scanf("%s %d",s,&num);
 
	if(fp=fopen(s,"r"))
	{
		while(++i<=num)
		{
			if(fgets(line,10,fp)!= NULL)
			{
				if(i == num)
				{
					printf("%s",line);
					while((line[strlen(line)-1]!='\n')&&(fgets(line,10,fp)!= NULL))
					{
						printf("%s",line);
						if(num == 2)
						{
							printf("\n");
						}
					}
				}
				else
				{
					while((line[strlen(line)-1]!='\n')&&(fgets(line,10,fp)!= NULL));
				}
			}
			else
			{
				printf("Line No Error.\n");
				fclose(fp);
				return 0;
			}
		}
	
	}
	else
	{
		printf("File Name Error.\n");
	}
}