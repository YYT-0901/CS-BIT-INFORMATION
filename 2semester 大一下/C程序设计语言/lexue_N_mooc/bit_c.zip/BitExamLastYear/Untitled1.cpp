#include<stdio.h>
#include<string.h>

int main(){
	int n;
	char str1[100]={0};
	char str2[100]={0};
	
	scanf("%s",&str1);
	scanf("%d",&n);
	scanf("%s",&str2);
	for(int i=0 ; i<strlen(str1) ; ++i)
	{
		if(i == n)
		{
			printf("%s",str2);
		}
		printf("%c",str1[i]);
	}
	printf("\n");
	return 0;
}