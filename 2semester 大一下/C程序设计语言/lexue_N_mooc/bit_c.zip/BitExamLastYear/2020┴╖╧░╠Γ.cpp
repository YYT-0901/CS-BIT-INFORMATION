#include<stdio.h>

int main(){
	int n,k;
	char c;
	scanf("%c %d",&c,&n);
	if((c>='a' && c<='z') || (c>='A' && c<='Z'))
	{
		if(n%2 == 1)
		{
			for(int i=0;i<n;++i)
			{
				k=n-i-1;
				for(int j=0;j<n;++j)
				{
					if(j == i || j == k)
					{
						printf(" ");
					}
					else{
						printf("%c",c);
					}
					if(j < n-1)
					{
						printf(" ");
					}
					else{
						printf("\n");
					}
				}
			}
		}
		else
		{
			printf("Wrong! Please enter an odd number.\n");
		}
	}
	else
	{
		printf("Wrong! Please enter English character.\n");
	}
	return 0;
}