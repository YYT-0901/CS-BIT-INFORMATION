#include<stdio.h>
#include<stdlib.h>

typedef struct Node{
	int data;
	struct Node *next;
}NODE;

void CreateNode(NODE *head,int *a);
//NODE* CreateNode(NODE *head,int *a);
void PrintNode(NODE *head,NODE *move);
void arrange(NODE *head,NODE *move,int a,int b);

int main(){
	int a[8] = {22,31,67,35,40,36,96,'\0'};
	int n1,n2;
	scanf("%d%d",&n1,&n2);
	NODE *head = (NODE*)malloc(sizeof(NODE));
	head->next = NULL;
	NODE *move = (NODE*)malloc(sizeof(NODE));
	move->next = NULL;
//	head = CreateNode(head,a); //都可以用
	CreateNode(head,a);
	arrange(head,move,n1,n2);
	PrintNode(head,move);
	return 0;
}

void CreateNode(NODE *head,int *a)
{
	NODE *p = head;
	NODE *q = NULL;
	while(*a != '\0')
	{
		q = (NODE*)malloc(sizeof(NODE));
		q->data = *a;
		p->next = q;
		p = p->next;
		a++;
	}
	p->next = NULL;
	return;
}

void arrange(NODE *head,NODE *move,int a,int b){
	NODE *p = head->next;
	NODE *save = head;
	NODE *q = move;
	while(p != NULL)
	{
		if(p->data > a && p->data < b)
		{
			save->next = p->next;
			p->next = q->next;
			q->next = p;
			p = save->next;
			q = q->next;
		}
		else{
			p = p->next;
			save = save->next;
		}
	}
}

void PrintNode(NODE *head,NODE *move){
	NODE *p = head->next;
	NODE *q = move->next;
	while(p != NULL)
	{
		printf("%d ",p->data);
		p = p->next;
	}
	printf("\n");
	while(q != NULL)
	{
		printf("%d ",q->data);
		q = q->next;
	}
	printf("\n");
}