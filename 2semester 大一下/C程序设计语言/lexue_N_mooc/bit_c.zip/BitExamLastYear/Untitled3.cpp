#include<stdio.h>
#include<string.h>

function(char* p1,char* p2){
	int count = 0;
	int j=0;
	for(int i=0;i<strlen(p1);++i)
	{
		for(j=0;j<strlen(p2);++j)
		{
			if(p1[i+j] != p2[j])
			{
				break;
			}
		}
		if(j == strlen(p2))
		{
			count++;
		}
	}
	return count;
}

int main(){
	char str1[100] = "";
	char str2[100] = "";
	gets(str1);
	gets(str2);
	
	if(function(str1,str2))
	{
		printf("%d\n",function(str1,str2));
	}
	else{
		printf("No\n");
	}
	return 0;
}