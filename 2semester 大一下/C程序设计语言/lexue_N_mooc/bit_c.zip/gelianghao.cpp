#include<stdio.h>

int main(){
	int n,a[25],k;
	scanf("%d",&n);
	k=n-1;
	for(int i=0;i<n;++i)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n/2;++i,--k)
	{
		printf("%d ",a[i]*a[k]);
	}
	if(n%2==1)
	{
		printf("%d \n",a[n/2]);
	}
	else{
		printf("\n");
	}
	return 0;
}
