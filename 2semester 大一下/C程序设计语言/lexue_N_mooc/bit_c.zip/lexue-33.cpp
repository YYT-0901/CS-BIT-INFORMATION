#include<stdio.h>
#include<string.h>

int main(){
	int yyt,p=0;
	char s[100],t[100],u[100];
	fgets(s,sizeof(s),stdin);
//	getchar();
	fgets(t,sizeof(t),stdin);
	for(int i=0;i<strlen(s);++i)
	{
		yyt=1;
		for(int j=0;j<strlen(t);++j)
		{
			if(s[i]==t[j])
			{
				yyt=0;
				break;
			}
		}
		if(yyt)
		{
			u[p++]=s[i];
		}
	}
	printf("%s",u);
	printf("\n");
	return 0;
}