#include<stdio.h>
#include<string.h>

int main(){
	int n,num,a[101][3]={},k=0;
	float b[200000]={},max=0,area=0;
	scanf("%d",&n);
	for(int i=0;i<n;++i)
	{
		k=0;
		scanf("%d",&num);
		for(int j=0;j<num;++j)
		{
			scanf("%d %d",&a[j][0],&a[j][1]);
		}
		for(int o=0;o<n-2;++o)
		{
			for(int p=o+1;p<n-1;++p)
			{
				for(int q=p+1;q<n;++q)
				{
					area=a[o][0]*a[p][1]+a[p][0]*a[q][1]+a[q][0]*a[o][1]-a[o][0]*a[q][1]-a[p][0]*a[o][1]-a[q][0]*a[p][1];
					b[k++]=0.5*area;
				}
			}
		}
		max=b[0];
		for(int r=1;r<num*(num-1)*(num-2)/6;++r)
		{
			if(max<b[r])
			{
				max=b[r];
			}
		}
		printf("%.1f\n",max);
	}
	return 0;
} 
