#include<stdio.h>

int sduck(int n,int m)
{
	if(n == 0)
	{
		return m;
	}
	else
	{
		static int sum = 0;
		m = (m+1)*2;
		return sduck(n-1,m);
	}
}

void sell(int sum,int n){
	int s = sum;
	s=s/2+1;
	for(int i=0;i<n;++i)
	{
		printf("sell=%d,",s);
		s = s/2;
	}
	printf("\n");
	return;
}

int main(){
	printf("sum=%d\n",sduck(7,2));
	sell(sduck(7,2),7);
	return 0;
}