#include<stdio.h>

int main(){
	int n,i=0,j=0,d=0,r=0;
	char c;
	char a[200][200]={'0'};
	scanf("%d %c", &n,&c);
	if(c>='a' && c<='z')
	{
		c-=32;
	}
	else if(c>='A' && c<='Z'){
	}
	else{
		printf("input error!\n");
		return 0;
	}
	if(n%2 == 0)
	{
		printf("input error!\n");
		return 0;
	}
	int num = n;
	while(num)
	{
		a[i][j++] = c;
		a[d++][r] = c;
		c++;
		if(c>'Z')
		{
			c = 'A';
		}
		--num;
	}
	--j;
	++i;
	--d;
	++r;
	while(i<n)
	{
		a[i++][j] = c;
		a[d][r++] = c;
		c++;
		if(c>'Z')
		{
			c = 'A';
		}
		++num;
	}
	i=1;
	while(i<n)
	{
		r = i;
		d = 1;
		c = a[i][0];
		++c;
		if(c>'Z')
		{
			c = 'A';
		}
		while(d<n)
		{
			if(i%2==1)
			{
				a[d++][r] = '0';
				if(d == n-1)
				{
					break;
				}
			}
			else
			{
				a[d++][r]=c;
				c++;
				if(c>'Z')
				{
					c = 'A';
				}
			}
			
		}
		i+=1;
	}
	for(int i=0;i<n;++i)
	{
		for(int j=0;j<n;++j)
		{
			if(a[i][j] == '0')
			{
				printf(" ");
				continue;
			}
			printf("%c", a[i][j]);
		}
		printf("\n");
	}

	
	return 0;
}