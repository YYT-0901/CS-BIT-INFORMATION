#include<stdio.h>
#include<string.h>
int main(){
	char a[100];
	//fgets(a,sizeof(a),stdin);//??enter?
	//gets(a);
	scanf("%[^\n]",a);
	printf("Hi,there,");
	for(int i=0;i<strlen(a);++i)
	{
		printf("%c",a[i]);
	}
	printf("!\n");
	return 0;
}