#include<stdio.h>

int main(){
	int n;
	int a[1050],b[1050];
	while(~scanf("%d",&n))
	{
		int k=n-1;
		int sum=0;
		for(int i=0;i<n;++i)
		{
			scanf("%d",&a[i]);
		}
		if(n==1)
		{
			printf("%d\n",a[0]);
		}
		for(int i=0;i<n;++i)
		{
			for(int j=i+1;j<n;++j)
			{
				if(a[i]>a[j])
				{
					int swap=a[j];
					a[j]=a[i];
					a[i]=swap;
				}
			
			}
		}
		while(k>2)
		{
			sum+=a[1]+a[1]+a[0]+a[k];
			k-=2;
		}
		if(n!=1)
		{
			if(n%2==0)
			{
				sum+=a[1];
				printf("%d\n",sum);
			}
			else
			{
				sum+=a[0]+a[1]+a[2];
				printf("%d\n",sum);
			}
		}
		
		
	}
	return 0;
}