#include<graphic.h>
#include<stdio.h>
#include<math.h>
#include<conio.h>
#include<stdlib.h>

double A_und(int n, double* a, double ave);
double B_und(double und);
double S_und(double a, double b);
int cul(void);
int phy(void);

int main(){
	char a=0;
	while(1)
	{
		printf("威威\n");
		a=getch();
		printf("\n");
		switch(a){
		case '1':cul();break;
		case '2':phy();break;
		case '3':break;
		default:printf("Error input,1,2,3only\n");continue;
		}
		if(a=='3')
		{
			break;
		}
		printf("renyijianjixu Njiantuichu");
		a=getche();
		if(a=='N' || a=='n')
		{
			break;
		}
		system("cls");
	}
	return 0;
}

double A_und(int n, double* a, double ave)
{
	double ua=0.0;
	double record = 0.0;
	for (int i = 0;i < n;i++)
	{
		record += pow((a[i] - ave), 2);
	}
	ua = sqrt(record / (n * (n - 1)));
	return ua;
}

double B_und(double und)
{
	double ub=0.0;
	ub = und / sqrt(3);
	return ub;
}

double S_und(double a, double b)
{
	double u=0.0;
	u = sqrt(a * a + b * b);
	return u;
}

int cul(void)
{
	printf("input num operator num:\n");
}

int phy(void)
{
	int n=0;
	double *p=0;
	double a[50] = {0};
	double sum = 0.0, srms = 0.0, und=0.0;
	printf("wulishiyanshujuchuliqi\n");
	printf("youjigeshuju(lingfanhui):");
	scanf("%d", &n);
	printf("qingshurushuju:");
	for (int i = 0;i < n;++i)
	{
		scanf("%lf", &a[i]);
		sum += a[i];
		srms += pow(a[i], 2);
	}
	printf("qingshuruyiqibuquedingdu(ruowushuru0)");
	scanf("%lf", &und);
	printf("\n");
	printf("--------------------\n");
	printf("average:%10.6lf\n", sum / n);
	printf("--------------------\n");
	printf("vrms   :%10.6lf\n", sqrt(srms / n));
	printf("--------------------\n");
	printf("A_und  :%10.6lf\n", A_und(n, a, sum / n));
	printf("--------------------\n");
	printf("B_und  :%10.6lf\n", B_und(und));
	printf("--------------------\n");
	printf("average:%10.6lf\n", S_und(A_und(n, a, sum / n), B_und(und)));
}
