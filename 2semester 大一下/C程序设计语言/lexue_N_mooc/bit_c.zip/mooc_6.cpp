#include<stdio.h>

int main(){
	int mark[5][5]={{78,90,87,92},{88,91,89,78},{84,76,83,75},{88,90,71,83}};
	char stu[5][10]={"wanglei","lihong","zhangli","liuming"};
	float ave[5]={0};
	float ave2[5]={0};
	for(int i=0;i<4;++i)
	{
		for(int j=0;j<4;++j)
		{
			ave[i] += mark[i][j];
		}
		ave[i] /= 4;
	}
	for(int i=0;i<4;++i)
	{
		if(i == 3)
		{
			printf("%s,%.f\n",stu[i],ave[i]);
			break;
		}
		printf("%s,%.2f\n",stu[i],ave[i]);
	}
	for(int i=0;i<4;++i)
	{
		for(int j=0;j<4;++j)
		{
			ave2[i] += mark[j][i];
		}
		ave2[i] /= 4;
	}
	printf("AVERAGE:");
	for(int i=0;i<4;++i)
	{
		if(i == 3)
		{
			printf("%.f\n",ave2[i]);
			break;
		}
		printf("%.2f,",ave2[i]);
	}
	return 0;
}