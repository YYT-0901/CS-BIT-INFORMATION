#include<stdio.h>
 long long int dp[105];
int main()
{
	long long int i,n,m,a,b;
	dp[0] = 0;
    dp[1] = 0;
    dp[2] = 1;
    dp[3] = 2;
    for(i = 4; i <= 105; i++)
	{
        dp[i] = dp[i-1] + dp[i-2];
    }
		scanf("%lld%lld",&a,&b);
		printf("%lld\n",dp[b-a+1]); 
	return 0;
 } 
