#include<stdio.h>

int main(){
	int n;
	int sum=1,k=1,m=0;
	scanf("%d",&n);
	for(int i=n-1;i>0;--i)
	{
		k=(k+i)*2;
	}
	if(k==1)
	{
		printf("The monkey got 1 peach in first day.\n");
	}
	else
	{
		printf("The monkey got %d peaches in first day.\n",k);
	}
	return 0;
}