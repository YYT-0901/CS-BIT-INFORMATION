#include<stdio.h>
#include<string.h>

int main(){
    int n;
    char s[1005] = {0};
    char a[10] = {0};
    scanf("%s", s);
    n = strlen(s);
    for(int i = 0; i < n; ++i)
    {
//        a[(int)s[i]]++;
printf("%d",s[i] - '0');
    }
    for(int i = 0; i < 9; ++i)
    {
        if(a[i])
        {
            printf("%d:%d\n", i, a[i]);
        }
    }
    return 0;
}