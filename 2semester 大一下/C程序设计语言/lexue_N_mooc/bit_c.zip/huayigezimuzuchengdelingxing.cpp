#include<stdio.h>

int main(){
	int n;
	char c;
	while(~scanf("%c,%d",&c,&n))
	{
		int k=1,d=0;
		getchar();
		for(int i=0;i<n;++i)
		{
			for(int j=k;j<n;++j)
			{
				printf(" ");
			}
			printf("%c",c);
			for(int j=1;j<d;++j)
			{
				printf(" ");
			}
			++k;
			d+=2;
			if(i>0)
			{
				printf("%c",c);
			}
			printf("\n");
			++c;
			if(c>'Z') c='A';
		}
		k=1;
		d-=5;
		--c;
		if(c<'A') c='Z';
		--c;
		if(c<'A') c='Z';
		for(int i=0;i<n-1;++i)
		{
			for(int j=0;j<k;++j)
			{
				printf(" ");
			}
			++k;
			printf("%c",c);
			for(int j=0;j<d;++j)
			{
				printf(" ");
			}
			d-=2;
			if(i!=n-2)
			{
				printf("%c",c);
			}
			--c;
			if(c<'A') c='Z';
			printf("\n");
		}
	}
	return 0;
}