#include<stdio.h>

int main(){
	int n,k;
	scanf("%d",&n);
	if(n%8==0)
	{
		k=n/8;
		printf("%d,%d,%d\n",50*k,60*k,45*k);
	}
	else
	{
		printf("No change.\n");
	}
	return 0;
}