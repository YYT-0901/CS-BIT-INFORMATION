#include<stdio.h>
int main(){char c;while(~scanf("%c",&c)){getchar();if(c>64 && c<91){c+=32;}else if(c>96 && c<123){c-=32;}printf("%c\n",c);}return 0;}