#include<stdio.h>
long findf(int n){
	if(n<=0)
	{
		return 1;
	}
	else
	{
		return n*findf(n-1)+findf(n-2);
	}
}

int main(){
	int n,ans;
	scanf("%d",&n);
	ans = findf(n);
	printf("%d\n", ans);
	
	
	return 0;
}
