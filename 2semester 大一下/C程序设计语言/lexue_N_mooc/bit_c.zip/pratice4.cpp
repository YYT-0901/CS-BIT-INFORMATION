#include<stdio.h>

int main(){
	unsigned int a,b,c,d;
	int num,i=0;
	int n[1000];
	scanf("%d%d%d",&a,&b,&c);
	d=a+b;
	while(d>=c)
	{
		d/=c;
		n[i]=d%c;
		++i;
	}
	--i;
	for(int j=i;j>=0;++j)
	{
		printf("%d",n[i]);
	}
	return 0;
}