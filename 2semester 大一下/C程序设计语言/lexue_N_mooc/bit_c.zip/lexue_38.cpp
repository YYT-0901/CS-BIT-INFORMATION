#include<stdio.h>

int sum(int a,int b){
	int ans=0;
	if(a>=b)
	{
		ans=a+sum(++a,b);
	}
	return ans;
}
int main(){
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%d\n",sum(a,b));
	return 0;
}
