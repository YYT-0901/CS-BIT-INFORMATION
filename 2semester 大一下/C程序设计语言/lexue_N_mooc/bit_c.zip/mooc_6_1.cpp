#include<stdio.h>
#include<string.h>

int cpr_s(char* a,char* b){
	char *p = b;
	int n=strlen(b);
	int m=strlen(a);
	int num = 0;
	for(int j=0;j<m;++j)
	{
		if(*a == *p)
		{
			for(int i=1;i<n;++i){
				if(*(p+i) != *(a+i))
				{
					a+=i;
					p = b;
					break;
				}
				if(i == n-1)
				{
					num++;
				}
			}
		}
		++a;
	}
	return num;
}

int main(){
	char str1[100]={0};
	char str2[100]={0};
	gets(str1);
	gets(str2);
	if(cpr_s(str1,str2))
	{
		printf("%d\n",cpr_s(str1,str2));
	}
	else
	{
		printf("No\n");
	}
	return 0;
}