#include<stdio.h>
#include<math.h>

int main(){
	int a;
	while(~scanf("%d",&a))
	{
		int k=pow(10,a-1);
		int n=pow(10,a);
		int l=999999 % n;
		int yyt=0;
		for(int i=k;i<=l;++i)
		{
			int m=i;
			int ans=0;
			while(m!=0)
			{
				int p=m%10;
				ans+=pow(p,a);
				m/=10;
			}
			if(ans==i)
			{
				printf("%d\n",i);
				yyt=1;
			}
		}
		if(yyt!=1)
		{
			printf("No output.\n");
		}
	}
	return 0;
}