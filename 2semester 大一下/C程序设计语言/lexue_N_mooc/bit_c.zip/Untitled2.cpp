#include<stdio.h>
#include<math.h>

int main(){
	double a,b,c,pbs=0;
	while(~scanf("%lf%lf%lf",&a,&b,&c))
	{
		if(a==0 && b==0)
		{
			printf("Input error!\n");
			continue;
		}

		else if(a!=0)
		{
			pbs=b*b-4*a*c;
			if(pbs>0)
			{
				printf("x1=%lf\nx2=%lf\n",(-b+sqrt(pbs))/2/a,(-b-sqrt(pbs))/2/a);
			}
			else if(pbs==0){
				if(b==0)
				{
					printf("x1=x2=%lf\n",b/2/a);
				}
				else
				{
					printf("x1=x2=%lf\n",-b/2/a);
				}
			}
			else{
				pbs=-pbs;
				if(b==0)
				{
					printf("x1=%lfi\nx2=%lfi\n",sqrt(pbs)/2/a,-sqrt(pbs)/2/a);
				}
				else{
					printf("x1=%lf+%lfi\nx2=%lf%lfi\n",-b/2/a,sqrt(pbs)/2/a,-b/2/a,-sqrt(pbs)/2/a);
				}
				
			}
		}
		else{
			if(c==0)
			{
				printf("x=%lf\n",c/b);	
			}
			else
			{
				printf("x=%lf\n",-c/b);
			}
			
		}
	}
	
	return 0;
}
