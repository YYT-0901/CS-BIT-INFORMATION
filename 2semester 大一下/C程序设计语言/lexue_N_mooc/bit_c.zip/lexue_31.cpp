#include<stdio.h>
#include<string.h>

int main(){
	char a[100];
	char swap;
	scanf("%s",&a);
	for(int i=0;i<strlen(a);++i)
	{
		for(int j=i+1;j<strlen(a);++j)
		{
			if(a[i]<a[j])
			{
				swap=a[j];
				a[j]=a[i];
				a[i]=swap;
			}
		}
	}
	for(int i=0;i<strlen(a);++i)
	{
		printf("%c",a[i]);
	}
	printf("\n");
	return 0;
}