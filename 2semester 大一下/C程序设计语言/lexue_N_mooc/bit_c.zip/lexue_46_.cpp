#include<stdio.h>
#include<string.h>

int main()
{
	char a[10];
	int len,n=0,flag=0;
	scanf("%s",&a);
	len=strlen(a);
	if(len!=5)
	{
		printf("no.\n");
	}
	else{

	if(a[len-1]>='0' && a[len-1]<='9')
	{
		for(int i=0;i<4;++i)
		{	
			if(a[i]>='A' && a[i]<='Z' && a[i]!='I' && a[i]!='O')
			{
				++n;
			}
			else if(a[i]>='0' && a[i]<='9'){
				++flag;
			}
		}
		if(n==2 && n+flag==4)
		{
			printf("ok.\n");
		}
		else
		{
			printf("no.\n");
		}
	}
	else{
		printf("no.\n");
	}
	
	}
	return 0;
}
