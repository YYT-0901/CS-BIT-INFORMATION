#include<stdio.h>
#include<stdlib.h>

typedef struct node{
		char x;
		struct node *next;
	}Node;

Node* CreateList(char* a){
	Node *head = (Node*)malloc(sizeof(Node));
	Node *p = head;
	for(int i=0;i<7;++i)
	{
		p->next = (Node*)malloc(sizeof(Node));
		p = p->next;
		p->x = a[i];
	}
	p->next = NULL;
	return head;
}

int main(){
	char a[7] = {'a','b','c','d','c','b','a'};
	Node* head;
	head = CreateList(a);
	scanf("%d",&n);
	return 0;
}