#include<stdio.h>

int main(){
	int n;
	int a[200]={0};
	while(~scanf("%d",&n))
	{
		int k=0,l=1,yyt=0;
		for(int i=0;i<n;++i)
		{
			a[i]=i+1;
		}
		for(int j=0;j<2*n;++j)
		{
			a[k]=0;
			k+=++l;
			k%=n;
//			k%=n;
		}
		for(int i=0;i<n;++i)
		{
			if(a[i]!=0 && yyt==1)
			{
				printf(" %d",a[i]);
			}
			else if(a[i]!=0)
			{
				printf("%d",a[i]);
				yyt=1;
			}
		}
		printf("\n");
	}
	return 0;
}