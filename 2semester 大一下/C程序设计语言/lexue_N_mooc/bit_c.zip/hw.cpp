#include<stdio.h>

int main(){
	char c,a;
	int n,l=1;
	int k=-1;
	scanf("%c %d",&c,&n);
	a=c;
	
	for(int i=0;i<n;++i)
	{
		for(int i=0;i<n-l;++i)
		{
			printf(" ");
		}
		++l;
		printf("%c",c);
		for(int i=0;i<k;++i)
		{
			printf(" ");
		}
		k+=2;
		if(c!=a)
		{
			printf("%c",c);
		}
		c++;
		printf("\n");
	}
	
	l=1;
	k-=4;
	c--;
	c--;
	for(int i=0;i<n-1;++i)
	{
		for(int i=0;i<l;++i)
		{
			printf(" ");
		}
		++l;
		printf("%c",c);
		for(int i=0;i<k;++i)
		{
			printf(" ");
		}
		k-=2;
		if(c!=a)
		{
			printf("%c",c);
		}
		c--;
		printf("\n");
	}
	
	return 0;
}