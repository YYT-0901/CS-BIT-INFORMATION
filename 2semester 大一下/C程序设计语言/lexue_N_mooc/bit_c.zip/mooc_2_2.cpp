#include<stdio.h>

int sum(int n){
	if(n == 1)
	{
		return 1;
	}
	else{
		return (2*n-1 + sum(n-1));
	}
}

int main(){
	int n;
	scanf("%d",&n);
	printf("%d\n",sum(n));
	return 0;
}