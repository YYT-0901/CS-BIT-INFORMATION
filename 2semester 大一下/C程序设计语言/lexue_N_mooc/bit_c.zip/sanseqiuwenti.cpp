#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
#include<queue>
#include<unordered_map>

using namespace std;

queue<string> q;
unordered_map<string, int> dist;
string start;
int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};

int bfs(string s){
	string end1 = "123804765";
	dist[s] = 0; // 哈希表 存到达end1要需要几步
	q.push(s);
	
	while(q.size()){
		auto t = q.front();
		q.pop();
		
		if(t == end1){
			return dist[t];
		}
		
		int distance = dist[t];
		
		int a = t.find('0');
		int x1 = a / 3, y1 = a % 3;
		
		for(int i = 0; i < 4; ++ i){
			int x2 = x1 + dx[i], y2 = y1 + dy[i];
			
			if(x2 < 0 || x2 >= 3 || y2 < 0 || y2 >=3) continue;
			
			int swap_index = x2 * 3 + y2;
			swap(t[a], t[swap_index]);
			
			if(!dist.count(t)){
				dist[t] = distance + 1;
				q.push(t);
			}
			
			swap(t[a], t[swap_index]);
		}
	}
	return -1;
}

int main(){
	cin >> start;
	int res = bfs(start);
	printf("%d", res);
	return 0;
}