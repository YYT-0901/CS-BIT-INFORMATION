#include<stdio.h>
#include<string.h>

int main(){
	char a[100]={0};
	
	struct s{
		char x;
		char y;
	};
	
	struct s t[9]={{'a','d'},{'b','w'},{'c','k'},{'d',';'},{'e','i'},{'i','a'},{'k','c'},{';','c'},{'w','e'}};
	scanf("%s",a);
	for(int i=0;i<strlen(a);++i)
	{
		for(int j=0;j<9;++j)
		{
			if(a[i] == t[j].x)
			{
				printf("%c",t[j].y);
				break;
			}
			if(j == 8)
			{
				printf("%c",a[i]);
			}
		}
	}
	printf("\n");
	return 0;
}