#include<stdio.h>

int main(){
	double f(int n);
	int n;
	scanf("%d",&n); 
	printf("sum=%.6lf\n",f(n));
	return 0;
}

double f(int n){
	if(n==1)
	{
		return 1;
	}
	else
	{
		return 1.0/n + f(n-1);
	}
}
