#include<stdio.h>

int main(){
	char a[100]={0};
	while(~scanf("%s",&a))
	{
		int yyt=0,yty=0;
		int max,min,ans=0;
		int k=0;
		for(int i=0;i<100;++i)
		{
			if(a[i]=='=')
			{
				break;
			}
			else{
				++k;
			}
		}
		for(int i=0;i<k-3;++i)
		{
			if(a[i]==',') continue;
			if(yyt==0)
			{
				yyt=1;
				min=a[i]-'0';
			}
			if(a[i]-'0'<min)
			{
				min=a[i]-'0';
			}
		}
		if(a[k-2]=='/' && min==0)
		{
			printf("Error!\n");
			yty=1;
		}
		else if(a[k-2]=='%' && min==0)
		{
			printf("Error!\n");
			yty=1;
		}
		else
		{
			yyt=0;
			for(int i=0;i<k-3;++i)
			{
				if(a[i]==',') continue;
				if(yyt==0)
				{
					yyt=1;
					max=a[i]-'0';
				}
				if(a[i]-'0'>max)
				{
					max=a[i]-'0';
				}
			}
		}
		if(yty==0)
		{
			if(a[k-2]=='+')
			{
				ans=max+min;
			}
			else if(a[k-2]=='-')
			{
				ans=max-min;
			}
			else if(a[k-2]=='*')
			{
				ans=max*min;
			}
			else if(a[k-2]=='/')
			{
				ans=max/min;
			}
			else if(a[k-2]=='%')
			{
				ans=max%min;
			}
			printf("%d%c%d=%d\n",max,a[k-2],min,ans);
		}
	}
	return 0;
}