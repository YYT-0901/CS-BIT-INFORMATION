#include<stdio.h>

int main(){
	char n;
		double a,b,ans=0; 
		scanf("%lf", &a);
		printf("%c ",a);
		if(a=='\0')
		{
			printf("in");
		}
		else{
			printf("nooooooo");
		}
	
	return 0;
}
