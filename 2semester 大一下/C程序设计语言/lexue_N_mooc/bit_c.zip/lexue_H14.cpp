#include<stdio.h>
#include<string.h>

int main(){
	char a[100];
	int n;
	scanf("%d",&n);
	getchar();
	for(int i=0;i<n;++i)
	{
		int xzm=0,dzm=0,sz=0,qt=0;
		gets(a);
		int b=strlen(a);
		if(b<6)
		{
			printf("Not Safe\n");
		}
		else{
			for(int j=0;j<b;++j)
			{
				if(a[j]>='a' && a[j]<='z')
				{
					xzm=1;
				}
				else if(a[j]>='A' && a[j]<='Z')
				{
					dzm=1;
				}
				else if(a[j]>='0' && a[j]<='9')
				{
					sz=1;
				}
				else
				{
					qt=1;
				}
			}
			if(xzm+dzm+sz+qt<2)
			{
				printf("Not Safe\n");
			}
			else if(xzm+dzm+sz+qt==2)
			{
				printf("Medium Safe\n");
			}
			else
			{
				printf("Safe\n");
			}
		}
	}
	return 0;
}
