#include<stdio.h>

int f(int n,int m);
int main(){
	int n,m,a;
	scanf("%d%d",&n,&m);
	a=f(n,m);
	printf("The sum from %d to %d is %d.\n",n,m,a);
	return 0;
} 

int f(int m)
{
	if(m==1)
	{
		return 1;
	}
	else
	{
		return f(m)+f(m-1);
	}
}
