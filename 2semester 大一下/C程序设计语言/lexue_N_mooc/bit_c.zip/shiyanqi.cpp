#include <stdio.h>
#include<stdlib.h>
 
void revstr(char *s)
{
    char *p;
    char c;
    p = s;
 
    while (*p != NULL)
        p++;
    p--;
    if (s < p){
        c = *s;
        *s = *p;
        *p  = '\0';
        revstr(s+1);
        *p = c;
    }
}
 
int main(void)
{
    char a[10]={0};
    scanf("%s", &a);
    revstr(a);
    printf("%s", a);
    return 0;
}