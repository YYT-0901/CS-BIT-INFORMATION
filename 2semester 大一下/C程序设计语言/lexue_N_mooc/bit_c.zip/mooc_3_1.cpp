#include<stdio.h>

int main(){
	int n,num=0;
	scanf("%d",&n);
	printf("%d,",n);
	while(n!=1)
	{
		if(n%2 == 0)
		{
			n/=2;
			if(n == 1)
			{
				printf("%d\n",n);
			}
			else{
				printf("%d,",n);
			}
			
		}
		else
		{
			n = n*3+1;
			printf("%d,",n);
		}
		num++;
	}
	printf("step=%d\n",num+1);
	return 0;
}