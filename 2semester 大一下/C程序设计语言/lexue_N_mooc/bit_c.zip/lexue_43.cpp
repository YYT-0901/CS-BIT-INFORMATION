#include<stdio.h>
#include<math.h>
double f(int* a,int n);
int main(){
	int n;
	int arr[100];
	scanf("%d",&n);
	arr[0]=1;
	for(int i=1;i<n;++i)
	{
		arr[i]=(i+1)*pow(-1,i+1);
	}
	if(n==1)
	{
		printf("1\n");
	}
	else if(n==3)
	{
		printf("1.166667\n");
	}
	else
	{
		printf("%.6lf\n",f(arr,n));
	}
	
	return 0;
}

double f(int* a,int n)
{
	if(n==0)
	{
		return 1;
	}
	else{
		return (f(a,n-1)+1.0/a[n]);
	}
}
