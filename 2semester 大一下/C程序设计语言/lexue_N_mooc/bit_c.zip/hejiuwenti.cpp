#include<stdio.h>

int main(){
	int n;
	while(~scanf("%d",&n))
	{
		int flag=0;
		int i=2;
		for(int j=i+1;j<=n;++j){
			for(int k=j+1;k<=n;++k){
				if(i*k+i*j+j*k==i*j*k && (i+j+k-2)>=n && i+j+k-2<=2*n)
				{
					printf("%d %d %d\n",i,j,k);
					flag=1;
				}
			}
		}
		if(!flag){
			printf("No solution\n");
		}
	}
	return 0;
}