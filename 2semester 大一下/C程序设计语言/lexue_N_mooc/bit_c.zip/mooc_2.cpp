#include<stdio.h>

void Arr(int* a){
	int swap;
	for(int i=0;i<10;++i)
	{
		for(int j=i+1;j<10;++j)
		{
			if(*(a+i) > *(a+j))
			{
				swap = *(a+i);
				*(a+i) = *(a+j);
				*(a+j) = swap;
			}
		}
	}
	return;
}

int main(){
	int a[10]={0};
	for(int i=0;i<10;++i)
	{
		scanf("%d",&a[i]);
	}
	Arr(a);
	for(int i=0;i<10;++i)
	{
		if(i == 9)
		{
			printf("%d\n",a[i]);
		}
		else{
			printf("%d,",a[i]);
		}
	}
	return 0;
}