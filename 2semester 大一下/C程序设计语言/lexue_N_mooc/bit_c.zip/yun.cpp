#include<stdio.h>

int main(){
	int n,k;
	int a[100][100]={0};
	while(~scanf("%d",&n))
	{
		k=n;
		int yyt=0;
		int i=0;
		int j=1;
		int num=1;
		while(num<=n*n)
		{
			while(i<k)
			{
				a[j][++i]=num++;
			}
			while(j<k)
			{
				a[++j][i]=num++;
			}
			--k;
			while(i>n-k)
			{
				a[j][--i]=num++;
			}
			--k;
			while(j>n-k)
			{
				a[--j][i]=num++;
			}
			++k;
		}
		
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=n;++j)
			{
				if(yyt=0)
				{
					printf(" %2d",a[i][j]);
					yyt=1;
				}
				else if(yyt=1)
				{
					printf(" %2d",a[i][j]);
				}
			}
			yyt=0;
			printf("\n");
		}
	}
	return 0;
}