#include<stdio.h>
int main(){
	int n;
	int x,y,z;
	int yyt=0;
	scanf("%d",&n);
	for(z=1;z<n*10;++z)
	{
		x=z*20/18;
		y=z*20/15;
		if(100*n==x+5*y+10*z)
		{
			printf("%d,%d,%d\n",x,y,z);
			yyt=1;
		}
	}
	if(yyt==0)
	{
		printf("No change.\n");
	}
	return 0;
}