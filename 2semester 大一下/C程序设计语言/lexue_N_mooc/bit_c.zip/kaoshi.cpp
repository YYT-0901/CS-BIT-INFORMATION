#include<stdio.h>

int main(){
	int n;
	char c;
	scanf("%d,%c",&n,&c);
	
	for(int j=0;j<n;++j)
		{
			printf("%c",c);
			c++;
			if(c > 'z')
			{
				c = 'a';
			}
		}
	printf("\n");
	for(int i=0;i<n-2;++i)
	{
		for(int j=0;j<n-i-2;j++)
		{
			printf(" ");
		}
		printf("%c\n",c++);
		if(c > 'z')
		{
			c = 'a';
		}
	}
	for(int j=0;j<n;++j)
		{
			printf("%c",c);
			c++;
			if(c > 'z')
			{
				c = 'a';
			}
		}
	printf("\n");
	return 0;
}