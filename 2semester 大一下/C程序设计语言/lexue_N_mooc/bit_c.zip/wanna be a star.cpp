#include<stdio.h>

int main(){
	int a[20];
	int max=0,min=0,sum=0;
	for(int i=0;i<10;++i)
	scanf("%d",&a[i]);
	max=a[0];
	min=a[0];
	for(int i=0;i<10;++i)
	{
		sum+=a[i];
		if(max<a[i])
		{
			max=a[i];
		}
		if(min>a[i])
		{
			min=a[i];
		}
	}
	sum-=max;
	sum-=min;
	printf("Canceled Max Score:%d\nCanceled Min Score:%d\nAverage Score:%d\n",max,min,sum/8);
	
	return 0;
}
