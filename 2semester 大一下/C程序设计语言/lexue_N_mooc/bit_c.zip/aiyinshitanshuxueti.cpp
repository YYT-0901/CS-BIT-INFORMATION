#include<stdio.h>

int check(int x){
	if(x % 2 == 1){
		if(x % 3 == 2){
			if(x % 5 == 4){
				if(x % 6 == 5){
					if(x % 7 == 0){
						return 1;
					}
				}
			}
		}
	}
	return 0;
}

int main(){
	int n;
	int cnt;
	while(~scanf("%d", &n)){
		cnt = 0;
		for(int i = 1; i <= n; ++i){
			if(check(i)){
				cnt++;
			}
		}
		printf("%d\n", cnt);
	}
	
	return 0;
}