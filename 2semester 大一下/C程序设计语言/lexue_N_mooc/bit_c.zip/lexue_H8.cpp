#include<stdio.h>

long long fac(int a)
{
	long long ans=1;
	for(int i=a;i>1;--i)
	{
		ans*=i;
	}
	return ans;
}

int main(){
	int a,b;
	scanf("%d%d",&a,&b);
	int sum=b-a;
	long long ans=0;
	for(int i=0;i<=(b-a)/2;++i)
	{
		ans+=fac(sum)/fac(i)/fac((sum-i));
		printf("%lld %d\n",fac(sum),fac(i)); 
		sum--;
		
	}
	printf("%lld\n",ans);
	return 0;
}
