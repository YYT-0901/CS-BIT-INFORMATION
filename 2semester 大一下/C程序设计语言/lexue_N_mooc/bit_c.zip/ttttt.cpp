#include<stdio.h>
#include<string.h>

int main(){
    char a[100] = {0};
    char b[100] = {0};
    int index, j = 0;
    gets(a);
    gets(b);
    for(int i=0; i<strlen(a); ++i)
    {
        index = strcspn(a, b);
        a[index] = '1';
    }
   	while(a[j] != '\0'){
    	if(a[j] != '1'){
    		printf("%c", a[j]);
		}
		++j;
	}
    return 0;
}