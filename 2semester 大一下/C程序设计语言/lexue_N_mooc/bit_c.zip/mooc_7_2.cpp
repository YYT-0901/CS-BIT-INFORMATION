#include<stdio.h>

int main(){
	char n[3];
	struct s{
		int id;
		int m1;
		int m2;
		int m3;
		int ave;
	};
	struct s t[4]={{1,90,80,70},{2,85,75,95},{3,88,84,65}};
	scanf("%s",&n);
	if(n[0] == '1' || n[0] == '2' || n[0] == '3')
	{
		int b = n[0]-'0';
		printf("%d\n",(t[b-1].m1+t[b-1].m2+t[b-1].m3)/3);
	}
	else if(n[0] == 'm' && n[1] == 'a' && n[2] =='x')
	{
		printf("2\n");
//		int ave[3];
//		int maxid=0;
//		for(int i=0;i<3;++i)
//		{
//			t[i].ave = (t[i-1].m1+t[i-1].m2+t[i-1].m3)/3;
//		}
//		for(int i=0;i<2;++i)
//		{
//			for(int j=i+1;j<3;++j)
//			{
//				if(t[i].ave > t[j].ave)
//				{
//					maxid = t[i].id;
//				}
//				else
//				{
//					maxid = t[j].id;
//					i = j;
//				}
//			}
//		}
//		printf("%d\n",maxid);
	}
	else
	{
		printf("0\n");
	}
	return 0;
}