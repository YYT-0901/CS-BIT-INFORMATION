#include<stdio.h>

int main(){
	int num1,num2,num3,num4,fenzi=0,fenmu=0,swap=0;
	char a;
	scanf("%d/%d ",&num1,&num2);
	scanf("%c",&a);
	scanf(" %d/%d",&num3,&num4);
	if(a=='*')
	{
		fenzi=num1*num3;
		fenmu=num2*num4;
	}
	else if(a=='/')
	{
		fenzi=num1*num4;
		fenmu=num2*num3;
	}
	else if(a=='+')
	{
		fenzi=num1*num4+num3*num2;
		if(num4>num2)
		{
			swap=num4;
			num4=num2;
			num2=swap;
		}
		if(num2%num4==0)
		{
			fenmu=num2;
			fenzi=
		}
		fenmu=num2*num4/(num2%num4);
		
	}
	else if(a=='-')
	{
		fenmu=num2*num4;
		fenzi=num1*num4-num3*num2;
	}
	printf("%d/%d %c %d/%d = %d/%d\n",num1,num2,a,num3,num4,fenzi,fenmu);

	return 0;
}