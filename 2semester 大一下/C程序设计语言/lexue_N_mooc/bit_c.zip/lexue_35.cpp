#include<stdio.h>
#include<string.h>

int main(){
	char a[150]={0};
	char b[150]={0};
	int yyt=1,k=0;
	gets(a);
	for(int i=0;i<strlen(a);++i)
	{
		for(int j=i-1;j>=0;--j)
		{
			if(a[i]==a[j]){
				yyt=0;
				break;
			}
		}
		if(yyt)
		{
			b[k++]=a[i];
		}
		yyt=1;
	}
	printf("%s\n",b);
	return 0;
}