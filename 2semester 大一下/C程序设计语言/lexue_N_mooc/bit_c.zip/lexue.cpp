#include<stdio.h>
#include<string.h>

int main(){
	char a[100][100]={0};
	char swap;
	int k=0;
	for(int i=0;i<5;++i)
	{
		scanf("%s",&a[i]);
	}
	for(int i=0;i<5;++i)
	{
		for(int j=i+1;j<5;++j)
		{
			if(a[i][k]>a[j][k])
			{
				if(strlen(a[i])>strlen(a[j])){
					for(int l=0;l<strlen(a[i]);++l)
					{
						swap=a[i][l];
						a[i][l]=a[j][l];
						a[j][l]=swap;
					}
					break;
				}
				else{
					for(int l=0;l<strlen(a[j]);++l)
					{
						swap=a[i][l];
						a[i][l]=a[j][l];
						a[j][l]=swap;
					}
					break;
				}
			}
			else if(a[i][k]==a[j][k])
			{
				while(1)
				{
					++k;
					if(a[i][k]>a[j][k])
					{
						if(strlen(a[i])>strlen(a[j])){
							for(int l=0;l<strlen(a[i]);++l)
							{
								swap=a[i][l];
								a[i][l]=a[j][l];
								a[j][l]=swap;
							}
						}
						else{
							for(int l=0;l<strlen(a[j]);++l)
							{
								swap=a[i][l];
								a[i][l]=a[j][l];
								a[j][l]=swap;
							}
						}
						break;
					}
					else if(a[i][k]<a[j][k])
					{
						break;
					}
				}
			}
		}
	}
	for(int i=0;i<5;++i)
	{
		printf("%s\n",a[i]);
	}

	return 0;
}