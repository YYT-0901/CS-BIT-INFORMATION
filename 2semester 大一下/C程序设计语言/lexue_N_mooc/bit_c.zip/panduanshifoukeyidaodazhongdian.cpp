#include<stdio.h>

int panduan(int a,int b,int c,int d)
{
	if(a == c && b == d) return 1;
	else if(a>c || b>d) return 0;
	else return panduan(a,b+a,c,d)+panduan(a+b,b,c,d);
}
int main(){
	int x1,x2,y1,y2;
	scanf("%d,%d", &x1,&y1);
	scanf("%d,%d", &x2,&y2);
	if(panduan(x1,y1,x2,y2)) printf("Yes.\n");
	else printf("No.\n");
	return 0;
}