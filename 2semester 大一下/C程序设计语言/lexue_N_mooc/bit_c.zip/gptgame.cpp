#include <stdio.h>

int main(){
	printf("I want to go home");
	return 0;
}