#include <stdio.h>  
  
int countsub( char *str, char *ss );  
  
main( )  
{  
    char s1[1000] = {'a','b','c','d'}, s2[100] = {'e','f','g','h'};  
    printf("%d\n", countsub( s1, s2 ) );  
}  

int countsub(char *str,char *ss){
	int i=0,j=0;
	char *p=str,*q=ss;
	q=ss;
	p=str;
	*p++;
	q++;
	printf("%c\n",*q);
printf("%c\n",*p);
//	while(*p!='\0')
//	{
//		if(*q==*p)
//		{
//			while(*q++==*p++)
//			{
//				if(*q=='\0')
//				{
//					++i;
//					q=ss;
//				}
//			}
//			if(i>j)
//			{
//				j=i;
//				i=0;
//			}
//		}
//		else
//		{
//			p++;
//		}
//	}
//	return j;
}
