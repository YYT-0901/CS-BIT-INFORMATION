#include<stdio.h>

int main(){
	int n,flag=0;
	scanf("%d",&n);
	for(int i=n*100;i<(n+1)*100;++i)
	{
		if(i/100==i/10%10 || i/100==i%10 || i/10%10==i%10)
		{
			continue;
		}
		else if(2*i/100==2*i/10%10 || 2*i/100==2*i%10 || 2*i/10%10==2*i%10 || 2*i/1000!=0)
		{
			continue;
		}
		else if(3*i/100==3*i/10%10 || 3*i/100==3*i%10 || 3*i/10%10==3*i%10)
		{
			continue;
		}
		else{
			
			flag=1;
			printf("%d,%d,%d\n",i,2*i,3*i);
		}
	}
	if(flag==0)
	{
		printf("0,0,0\n");
	}
	return 0;
}
