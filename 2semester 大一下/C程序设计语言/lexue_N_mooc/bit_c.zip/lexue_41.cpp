#include<stdio.h>

int leap_year( int );     
int year_days( int );     
int days(int,int,int);    
  
int leap_year( int year )   // ???????  
{   return ( (year%4==0 && year%100!=0) || year%400==0 ) ? 1 : 0;  
}  
  
int year_days(int year)     // ????????  
{   return leap_year( year ) ? 366 : 365;  
}  
  
int days( int year, int month, int day ) // ????month,day ???year????  
{   int months[13] = {0,31,28,31,30,31,30,31,31,30,31,30,31}, i;  
      
    if  ( leap_year( year ) && month >2 )  
        day++;  
      
    for ( i=1; i<month; i++ )  
        day += months[i];  
  
    return day;  
}  

int main()
{
	int d,m,y,d1,m1,y1,sumd=0;
	scanf("%d%d%d",&y,&m,&d);
	scanf("%d%d%d",&y1,&m1,&d1);
	for(int i=y;i<y1;++i)
	{
		sumd+=year_days(i);
	}
	sumd+=days(y1,m1,d1)-days(y,m,d);
	if(sumd==1 || sumd==0)
	{
		printf("%d day\n",sumd);
	}
	else
	{
		printf("%d days\n",sumd);
	}
	return 0;
}
