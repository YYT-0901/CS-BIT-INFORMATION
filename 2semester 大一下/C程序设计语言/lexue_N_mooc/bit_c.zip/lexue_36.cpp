#include<stdio.h>

int main(){
	int n,m,swap,sum=0,yyt=0;
	int a[105]={0},b[105]={0};
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;++i)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<m;++i)
	{
		scanf("%d",&b[i]);
	}
	if(m<n)
	{
		printf("bit is doomed!\n");
	}
	else
	{
		for(int i=0;i<m;++i){
			for(int j=i+i;j<m;++j){
				if(b[i]>b[j])
				{
					swap=b[i];
					b[i]=b[j];
					b[j]=swap;
				}
			}
		}
		for(int i=0;i<n;++i){
			for(int j=0;j<m;++j){
				if(b[j]>=a[i])
				{
					sum+=b[j];
					b[j]=0;
					yyt=1;
					break;
				}
				yyt=0;
			}
			if(yyt==0)
			{
				printf("bit is doomed!\n");
				break;
			}
		}
		if(yyt==1) printf("%d\n",sum);
	}
	return 0;
}