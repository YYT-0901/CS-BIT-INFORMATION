#include<stdio.h>

int main(){
//	F=9/5c+32,C=5/9(F-32)
	int n;
	float num,ans=0;
	for(int i=0;i<3;++i)
	{
		scanf("%d %f",&n,&num);
		if(n==1)
		{
			ans=5.0/9*(num-32);
			printf("The Centigrade is %.2f\n",ans);
		}
		else if(n==2)
		{
			ans=9.0/5*num+32;
			printf("The Fahrenheit is %.2f\n",ans);
		}
		else
		{
			printf("Wrong input!\n");
		}
	}
	
	return 0;
}