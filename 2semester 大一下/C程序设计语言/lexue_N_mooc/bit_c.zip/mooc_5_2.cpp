#include<stdio.h>

void Arr(int (*a)[5],int* b){
	int sum[5];
	int temp;
	for(int i=0;i<3;++i)
	{
		for(int j=0;j<4;++j)
		{
			sum[i]+=a[i][j];
		}
	}
	for(int i=0;i<2;++i)
	{
		for(int j=i+1;j<3;++j)
		{
			if(sum[i]<sum[j])
			{
				temp = b[i];
				b[i] = b[j];
				b[j] = temp;
			}
		}
	}
	return;
}

int main(){
	int a[5][5]={0};
	int order[5]={1,2,0};
	for(int i=0;i<3;++i)
	{
		for(int j=0;j<4;++j)
		{
			scanf("%d",&a[i][j]);
		}
	}
	Arr(a,order);
	for(int i=0;i<3;++i)
	{
		for(int j=0;j<4;++j)
		{
			if(j == 3)
			{
				printf("%d\n",a[order[i]][j]);
				break;
			}
			printf("%d,",a[order[i]][j]);
		}
	}
	return 0;
}