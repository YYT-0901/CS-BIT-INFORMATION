#include<stdio.h>
#include<string.h>

int main(){
	char a[200]={0},b[200];
	int i=0;
	int j=0;
	gets(a);
	gets(b);
	while(i<strlen(a) && j<strlen(b))
	{
		if(a[i]>=b[j])
		{
			printf("%c",b[j++]);
		}
		else
		{
			printf("%c",a[i++]);
		}
	}
	for(i;i<strlen(a);++i)
	{
		printf("%c",a[i]);
	}
	for(j;j<strlen(b);++j)
	{
		printf("%c",b[j]);
	}
	printf("\n");
	return 0;
}