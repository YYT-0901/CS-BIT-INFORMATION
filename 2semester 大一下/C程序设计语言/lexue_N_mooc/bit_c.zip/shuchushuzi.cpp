#include<stdio.h>

int main(){
	int n,k,x,flag=1,j=0;
	int a[15][3]={0};
	scanf("%d %d", &n,&k);
	for(int i=0;i<n;++i)
	{
		scanf("%d", &x);
		while(1)
		{
			if(a[j][0] == 0)
			{
				a[j][0] = x;
				a[j][1]++;
				j=0;
				break;
			}
			else if(a[j][0] == x)
			{
				a[j][1]++;
				j=0;
				break;
			}
			else{
				++j;
			}
		}
	}
		
	int i=0;
	while(a[i][0] != 0)
	{
		if(a[i][1] > k)
		{
			printf("%d\n", a[i][0]);
			flag = 0;
		}
		++i;
	}
	if(flag)
	{
		printf("No such element.\n");
	}
	return 0;
}