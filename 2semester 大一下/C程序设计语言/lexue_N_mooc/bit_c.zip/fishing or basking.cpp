#include<stdio.h>

int main(){
	int n;
	scanf("%d",&n);
	int d,m,y;
	int monthd[15]={31,28,31,30,31,30,31,31,30,31,30,31};
	for(int i=0;i<n;++i)
	{
		int k=0;
		int sumd=0;
		scanf("%d%d%d",&y,&m,&d);
		for(int i=1990;i<=y;++i)
		{
			if(i%4==0 && i%100!=0 || i%400==0)
			{
				++k;
				if(i==y && m<=2)
				{
					--k;
				}
			}
		}
		sumd=(y-1990)*365;
		for(int i=0;i<m-1;++i)
		{
			sumd+=monthd[i];
		}
		sumd+=d+k;
		sumd%=5;
	    if(sumd==0 || sumd==4)
	    {
	    	printf("He was basking on %d.%d.%d\n",y,m,d);
		}
		else
		{
			printf("He was fishing on %d.%d.%d\n",y,m,d);
		}
	}
	return 0;
}