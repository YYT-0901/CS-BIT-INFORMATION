#include<stdio.h>

int main(){
	int n;
	int a[100][100]={0};
	scanf("%d",&n);
	int i=0,j=0;
	int num=1,yyt=0;
	
	while(num<=n*n)
	{	
		while(j>=0){//????????,????
			if(j==0 && i+1<n)//??????,?????,???
			{
				a[j][i++]=num++;
				break;
			}
			else if(i+1==n)//??????????,???
			{
				a[j++][i]=num++;
				break;
			}
			a[j--][i++]=num++;
		}
		while(i>=0)//????????,????
		{
			
			if(i==0 && j+1<n)//??????,?????,???
			{
				a[j++][i]=num++;
				break;
			}
			else if(j+1==n)//???????,???
			{
				a[j][i++]=num++;
				break;
			}
			a[j++][i--]=num++;
		}
	}
	for(int i=0;i<n;++i)
	{
		for(int j=0;j<n;++j)
		{
			if(yyt==0)
			{
				printf("%2d",a[i][j]);
				yyt=1;
			}
			else if(yyt==1)
			{
				printf(" %2d",a[i][j]);
			}
		}
		yyt=0;
		printf("\n");
	}
	return 0;
}
