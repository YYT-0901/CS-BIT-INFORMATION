#include<stdio.h>

int find(int *a,int x){
	while(*a != '\0')
	{
		if(*a == x)
		{
			return 1;
		}
		a++;
	}
	return 0;
}

int main(){
	int a[15]={0};
	int x=0;
	for(int i=0;i<10;++i)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d",&x);
	if(find(a,x))
	{
		printf("%d\n",x);
	}
	else{
		printf("No\n");
	}
	return 0;
}