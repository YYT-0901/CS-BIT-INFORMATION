#include<stdio.h>

int fun1(int a,int b){
	int temp=0;
	while(b){
		temp = a%b;
		a = b;
		b = temp;
	}
	return a;
}

//int fun2(int a,int b,int c){
//	int ans = a*b/c;
//	return ans;
//}

int main(){
	int a,b;
	scanf("%d,%d",&a,&b);
	printf("%d\n",fun1(a,b));
//	printf("最大公约数：%d\n",fun1(a,b));
//	printf("最小公倍数：%d\n",fun2(a,b,fun1(a,b)));
	return 0;
}