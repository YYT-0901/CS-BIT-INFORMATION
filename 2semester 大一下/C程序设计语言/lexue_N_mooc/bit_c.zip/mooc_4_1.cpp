#include<stdio.h>
#include<string.h>

int mirror_s(char* a,int l){
	char *b = a+l-1;
	for(int i=0;i<l;++i)
	{
		if(*(a+i) != *(b-i))
		{
			return 0;
		}
	}
	return 1;
}

int main(){
	char a[100]={0};
	scanf("%s",a);
	int l = strlen(a);
	if(mirror_s(a,l))
	{
		printf("YES\n");
	}
	else{
		printf("NO\n");
	}
	
	return 0;
}