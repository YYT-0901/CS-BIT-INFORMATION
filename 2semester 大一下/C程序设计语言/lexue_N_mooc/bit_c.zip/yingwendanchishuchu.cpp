#include<stdio.h>
#include<string.h> 

int main(){
	int j=0,k=0;
	char t[25]={0};
	char ch[200]={0};
	char save[100][25]={0};
	gets(ch);
	for(int i=0;i<strlen(ch);++i)
	{
		if(ch[i] != ' '){
			save[k][j++] = ch[i];
		}
		else
		{
			j=0;
			k++;
		}
	}
	for(int i=0;i<k+1;++i)
	{
		for(int j=i+1;j<k+1;++j)
		{
			if(strcmp(save[i],save[j]) > 0 )
			{
				strcpy(t,save[i]);
				strcpy(save[i],save[j]);
				strcpy(save[j],t);
			}
		}
	}
	for(int i=0;i<k+1;++i)
	{
		if(i==k)
		{
			printf("%s\n",save[i]);
		}
		else{
			printf("%s ",save[i]);
		}
	}
	
	return 0;
} 
