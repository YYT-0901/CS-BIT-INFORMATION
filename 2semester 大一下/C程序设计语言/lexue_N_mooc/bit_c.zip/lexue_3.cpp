#include<stdio.h>

int main(){
	int y,m,d,n,d31=31,d30=30,d2,mk;
	scanf("%d%d%d%d",&y,&m,&d,&n);
	if((y%4==0 && y%100!=0) || y%400==0 )
	{
		d2=29;
	}
	else
	{
		d2=28;
	}
	int sum=d+n;
	if(m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || m==12)
	{
		mk=d31;
	}
	else if(m==4||m==6||m==9||m==11)
	{
		mk=d30;
	}
	else if(m==2)
	{
		mk=d2;
	}
	while(sum>mk)
	{
		sum-=mk;
		m++;
		if(m>12)
		{
			m-=12;
			++y;
		}
		if((y%4==0 && y%100!=0) || y%400==0 )
		{
			d2=29;
		}
		else
		{
			d2=28;
		}
		if(m==1 || m==3 || m==5 || m==7 || m==8 || m==10 || m==12)
		{
			mk=d31;
		}
		else if(m==4||m==6||m==9||m==11)
		{
			mk=d30;
		}
		else if(m==2)
		{
			mk=d2;
		}
	}
	printf("%d.%d.%d\n",y,m,sum);
	return 0;
}