#include <windows.h>
#include <minwindef.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <Tlhelp32.h>
#include <tchar.h>
#include <shlwapi.h>


#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "kernel32.lib")

using namespace std;

// 打印内存保护状态
void printProtection(DWORD dwTarget)
{
    char as[] = "----------";
    if (dwTarget & PAGE_NOACCESS) as[0] = 'N';
    if (dwTarget & PAGE_READONLY) as[1] = 'R';
    if (dwTarget & PAGE_READWRITE)as[2] = 'W';
    if (dwTarget & PAGE_WRITECOPY)as[3] = 'C';
    if (dwTarget & PAGE_EXECUTE) as[4] = 'X';
    if (dwTarget & PAGE_EXECUTE_READ) as[5] = 'r';
    if (dwTarget & PAGE_EXECUTE_READWRITE) as[6] = 'w';
    if (dwTarget & PAGE_EXECUTE_WRITECOPY) as[7] = 'c';
    if (dwTarget & PAGE_GUARD) as[8] = 'G';
    if (dwTarget & PAGE_NOCACHE) as[9] = 'D';
    if (dwTarget & PAGE_WRITECOMBINE) as[10] = 'B';
    printf("  %s  ", as);
}

// 显示系统内存配置
void showSystemMemoryConfig()
{
    SYSTEM_INFO si;
    memset(&si, 0, sizeof(si));
    GetNativeSystemInfo(&si);

    DWORD page_size = si.dwPageSize;
    DWORD memory_size = (DWORD)si.lpMaximumApplicationAddress - (DWORD)si.lpMinimumApplicationAddress;
    double memory_size_in_gb = static_cast<double>(memory_size) / (1024.0 * 1024.0 * 1024.0);

    TCHAR str_page_size[MAX_PATH];
    StrFormatByteSize(si.dwPageSize, str_page_size, MAX_PATH);

    TCHAR str_memory_size[MAX_PATH];
    StrFormatByteSize(memory_size, str_memory_size, MAX_PATH);

    printf("系统信息\n");
    cout << "--------------------------------------------" << endl;
    cout << "处理器架构                  | " << (si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64 || si.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_INTEL ? "x64" : "x86") << endl;
    cout << "处理器核心数量              | " << si.dwNumberOfProcessors << endl;
    cout << "虚拟内存页大小              | " << str_page_size << " ("  << page_size / 1024 << " KB)" << endl;
    cout << "总虚拟内存                  | " << str_memory_size << " (" << fixed << setprecision(2) << memory_size_in_gb << " GB)" << endl;
    cout << "最小应用程序地址            | 0x" << hex << setfill('0') << setw(8) << (DWORD)si.lpMinimumApplicationAddress << endl;
    cout << "最大应用程序地址            | 0x" << hex << setw(8) << (DWORD)si.lpMaximumApplicationAddress << endl;
    cout << "--------------------------------------------" << endl;
    return;
}

// 显示系统内存使用情况
void showMemoryCondition()
{
    printf("系统内存状态信息\n");
    cout << "--------------------------------------------" << endl;
    MEMORYSTATUSEX statex;
    statex.dwLength = sizeof(statex);
    GlobalMemoryStatusEx(&statex);

    cout << "物理内存使用率: " << statex.dwMemoryLoad << "%" << endl;
    cout << "总物理内存: " << statex.ullTotalPhys / (1024 * 1024) << "MB" << endl;
    cout << "可用物理内存: " << statex.ullAvailPhys / (1024 * 1024) << "MB" << endl;
    cout << "总虚拟内存: " << statex.ullTotalVirtual / (1024 * 1024) << "MB" << endl;
    cout << "可用虚拟内存: " << statex.ullAvailVirtual / (1024 * 1024) << "MB" << endl;
    cout << "总交换文件: " << statex.ullTotalPageFile / (1024 * 1024) << "MB" << endl;
    cout << "可用交换文件: " << statex.ullAvailPageFile / (1024 * 1024) << "MB" << endl;
    cout << "--------------------------------------------" << endl;
}

// 显示进程列表，包括进程名和pid
void getAllProcess()
{
    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(pe32);
    HANDLE hProcessShot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hProcessShot == INVALID_HANDLE_VALUE)
    {
        printf("创建进程快照失败。\n");
        return;
    }

    cout << " |  序号  |  进程ID  |  进程名" << endl;
    cout << "-----------------------------------------" << endl;
    if (Process32First(hProcessShot, &pe32)) {
        for (int i = 0; Process32Next(hProcessShot, &pe32); i++) {
            wprintf(L" |  %4d  |  %5d   |  %s\n", i, pe32.th32ProcessID, pe32.szExeFile);
        }
    }
    cout << "-----------------------------------------" << endl;
    CloseHandle(hProcessShot);
    return;
}

void showMemoryInstruction()
{
    cout << "\033[31m-----------------------------------------------------\033[0m" << endl;
    cout << "\033[31m输入命令：\033[0m" << endl
        << "\"\033[36mconfig\033[0m\"   : 显示系统内存配置。" << endl
        << "\"\033[36mstatus\033[0m\"   : 当前系统内存使用状态。" << endl
        << "\"\033[36mprocess\033[0m\"  : 当前系统正在运行的进程信息。" << endl
        << "\"\033[36mpid\033[0m\"      : 输入processid号，显示该进程的详细内存信息。" << endl
        << "\"\033[36mexit\033[0m\"     : 退出程序" << endl;
    cout << "\033[31m-----------------------------------------------------\033[0m" << endl;
    return;
}

// 显示指定进程的内存分布
void getProcessDetail(int pid)
{
    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, 0, pid);
    if (!hProcess) return;
    cout << " | "
        << "   内存地址    | "
        << "   大小    | "
        << "页状态  | "
        << "    保护    | "
        << "  类型  | "
        << " 模块名"
        << endl;
    SYSTEM_INFO si;                    // 系统信息
    ZeroMemory(&si, sizeof(si));
    GetSystemInfo(&si);

    MEMORY_BASIC_INFORMATION mbi;       // 保存内存信息
    ZeroMemory(&mbi, sizeof(mbi));

    LPCVOID pBlock = (LPVOID)si.lpMinimumApplicationAddress;

    while (pBlock < si.lpMaximumApplicationAddress) {
        if (VirtualQueryEx(hProcess, pBlock, &mbi, sizeof(mbi)) == sizeof(mbi))
        {
            cout << " | ";

            // 内存块的大小
            LPCVOID pEnd = (PBYTE)pBlock + mbi.RegionSize;
            TCHAR szSize[MAX_PATH];
            StrFormatByteSize(mbi.RegionSize, szSize, MAX_PATH); // 内存块大小

            // 地址和大小
            cout.fill('0');
            cout << hex << setw(8) << (DWORD)pBlock
                << "-"
                << hex << setw(8) << (DWORD)pEnd - 1
                << " | ";
            printf("%10ls", szSize);

            // 显示内存块状态
            switch (mbi.State)
            {
            case MEM_COMMIT: cout << " | " << setw(9) << "已提交" << " | "; break;
            case MEM_FREE: cout << " | " << setw(9) << "已释放" << " | "; break;
            case MEM_RESERVE: cout << " | " << setw(9) << "已保留" << " | "; break;
            default: cout << "          | "; break;
            }

            // 保护状态
            if (mbi.Protect == 0 && mbi.State != MEM_FREE)
            {
                mbi.Protect = PAGE_READONLY;
            }
            printProtection(mbi.Protect);

            switch (mbi.Type)
            {
            case MEM_IMAGE: cout << " |  映像  | "; break;
            case MEM_PRIVATE: cout << " | 私有  | "; break;
            case MEM_MAPPED: cout << " | 映射  | "; break;
            default: cout << " |       | "; break;
            }

            // 模块名
            TCHAR str_module_name[MAX_PATH];
            if (GetModuleFileName((HMODULE)pBlock, str_module_name, MAX_PATH) > 0) {
                PathStripPath(str_module_name);
                wprintf(L"%s", str_module_name);
            }
            cout << endl;
            pBlock = pEnd;    // 继续下一个内存块
        }
    }
}

int main()
{
    setlocale(LC_ALL, "CHS");
    cout << endl << "\033[33m*-----------System Memory Manager-----------*\033[0m" << endl << endl;
    string cmd;
    char cmd_charstr[127];
    while (1)
    {
        cout << endl;
        showMemoryInstruction();
        cout << "\033[33mManager> \033[0m";
        cin.getline(cmd_charstr, 127);
        cmd = cmd_charstr;

        if (cmd == "config") {
            cout << endl;
            showSystemMemoryConfig();
        }
        else if (cmd == "status") {
            cout << endl;
            showMemoryCondition();
        }
        else if (cmd == "process") {
            cout << endl;
            getAllProcess();
        }
        else if (cmd == "pid") {
            cout << "PID> ";
            int pid = 0;
            cin >> pid;
            cin.getline(cmd_charstr, 127);
            if (pid <= 0) continue;
            cout << endl;
            getProcessDetail(pid);
        }
        else if (cmd == "exit") {
            break;
        }
        else {
            if (cmd != "") cout << "输入错误，请重新输入！" << endl;
            fflush(stdin);
            cin.clear();
            continue;
        }
        cin.clear();
    }
    return 0;

}
