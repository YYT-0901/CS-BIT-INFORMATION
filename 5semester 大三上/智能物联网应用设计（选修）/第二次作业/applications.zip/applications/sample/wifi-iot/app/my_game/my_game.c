#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
// #include "iot_gpio_ex.h"
#include "iot_watchdog.h"
#include "iot_pwm.h"
#include "iot_i2c.h"
#include "iot_errno.h"

#include "ssd1306.h"
#include "ssd1306_tests.h"
#include "ssd1306_fonts.h"
#include "hi_io.h"
#include "hi_pwm.h"

#define CLK_160M 160000000
#define OLED_I2C_BAUDRATE (400*1000)
#define IOT_GPIO_KEY 8
#define IOT_PWM_BEEP 9
#define IOT_PWM_PORT_PWM0 0
#define     CLK_160M                160000000
#define     IOT_GPIO_IDX_9          9
#define     IOT_GPIO_PWM_FUNCTION   5
#define     IOT_PWM_PORT_PWM0       0
#define gamenum 3
#define but_length 30

typedef struct {
    int id;
    int width;
} RECTANGLE2;

typedef struct {
    int num;
    RECTANGLE2 plate[10];
    bool ischoose;
} PILLAR;

static uint32_t startTime;
static uint32_t endTime;
PILLAR p[3]; //face and ans
PILLAR pi[3]; //play
int length = 40;
int unitwidth = 10;
int unitheight = 4;
bool choose = 1;
int chosen = 1;
int choose_pillar = 1;
int playorans = 0;
bool first = true;
int x_line,y_line;
enum STATE{
    wait,selection,playing,answer,end
};
int choose_mix = 1;
enum STATE state = wait;
static int cnt = 0;
int circle_x = 32;
int circle_y = 5;
int radius = 2;
bool press = 0;
bool press2 = 0;
int movetime = 0;
bool mix_ischoose = false;
int xline = (128-gamenum*but_length)/(gamenum+1)+5;
int yline = (58-but_length)/2+but_length-15;
char s[gamenum][100] = {"Jumping","","Flabby"};
char s2[gamenum][100] = {"Ball","Hanuoi","Bird"};

static void OnButtonPressed1(void *arg)
{
    (void) arg;
    if(state == wait){
        state = selection;
        if(choose){
            playorans = 1;
        }
        else{
            playorans = 2;
        }
        return;
    }
    else if(state == selection && playorans == 2){
        state = answer;
    }
    else if(state == selection && playorans == 1){
        state = playing;
    }
    else if(state == playing){
        press = 1;
    }
}

void get_gpio5_voltage1(void *arg)
{
    (void) arg;
    if(state == wait){
        toggle_choose();
        choose = !choose;
    }
    else if(state == selection){
        ssd1306_DrawLine(x_line,y_line,x_line+16,y_line,Black);
        chosen++;
        if(chosen>6){
            chosen = 1;
        }
        int x,y;
        if(chosen == 1){
            x = 19;
            y = 24;
        }
        else if(chosen == 4){
            x = 19;
            y = 50;
        }
        else{
            x = x_line + 37;
            y = y_line;
        }
        x_line = x;
        y_line = y;
    }
    else if(state == playing){
        press2 = 1;
    }
}

int iseverchoose(PILLAR *pi){
    for(int i=0;i<3;i++){
        if(pi[i].ischoose){
            return i;
        }
    }
    return -1;
}

void showorclear(bool clear){
    SSD1306_COLOR color;
    if(clear){
        color = Black;
    }
    else{
        color = White;
    }
    char str[16];
    sprintf(str,"Movetime: %d",movetime);
    ssd1306_SetCursor(0,10);
    ssd1306_DrawString(str, Font_7x10, color);
    for(int i=0;i<3;i++){
        int w = 32*(i+1);
        ssd1306_DrawLine(w,57-length,w,57,White);
        for(int j=p[i].num-1;j>=0;j--){
            int x1 = w-(p[i].plate[j].width)/2;
            int y1 = 57;
            int x2 = w + (p[i].plate[j].width)/2;
            int y2 = 57-(p[i].num-j)*unitheight;
            ssd1306_DrawRectangle(x1,y1,x2,y2,color);
        }
    }
    ssd1306_UpdateScreen();
}

void showorclear_play(bool clear){
    SSD1306_COLOR color;
    if(clear){
        color = Black;
    }
    else{
        color = White;
    }
    char str[16];
    sprintf(str,"Movetime: %d",movetime);
    ssd1306_SetCursor(0,10);
    ssd1306_DrawString(str, Font_7x10, color);
    for(int i=0;i<3;i++){
        int w = 32*(i+1);
        ssd1306_DrawLine(w,57-length,w,57,White);
        for(int j=pi[i].num-1;j>=0;j--){
            int x1 = w-(pi[i].plate[j].width)/2;
            int y1 = 57;
            int x2 = w + (pi[i].plate[j].width)/2;
            int y2 = 57-(pi[i].num-j)*unitheight;
            ssd1306_DrawRectangle(x1,y1,x2,y2,color);
        }
    }
    ssd1306_UpdateScreen();
}

void interface_showorclear(bool clear){
    //cleardevice
    // ssd1306_Fill(Black);
    // ssd1306_UpdateScreen();
    SSD1306_COLOR color;
    if(clear){
        color = Black;
    }
    else{
        color = White;
    }
    for(int i=0;i<3;i++){
        int w = 32*(i+1);
        ssd1306_DrawLine(w,13,w,28,White);
        for(int j=p[i].num-1;j>=0;j--){
            int x1 = w-(p[i].plate[j].width)/2;
            int y1 = 28;
            int x2 = w + (p[i].plate[j].width)/2;
            int y2 = 28-(p[i].num-j)*2;
            ssd1306_DrawRectangle(x1,y1,x2,y2,color);
        }
    }
    ssd1306_UpdateScreen();
    usleep(100*1000);
}

void startup(){
    interface();
    if(state == selection){
        choose_face();
        usleep(1000*1000);
    }

    if(state == answer){
        ssd1306_Fill(Black);
        hanuoyi(chosen+2,false);
        usleep(4000*1000);
        return;
    }
    else if(state == playing){
        playing_face();
    }
}

void interface(){
    
    ssd1306_Init();
    ssd1306_Fill(Black);
    ssd1306_SetCursor(10, 30);
    ssd1306_DrawString("HANUOYI", Font_7x10, White);
    ssd1306_DrawRectangle(20,40,60,55,White);
    ssd1306_SetCursor(27,44);
    ssd1306_DrawString("PLAY", Font_7x10, White);
    ssd1306_DrawRectangle(70,40,110,55,White);
    ssd1306_SetCursor(80,44);
    ssd1306_DrawString("ANS", Font_7x10, White);
    if(choose){
        ssd1306_DrawRectangle(25,43,55,52,White);
    }
    else{
        ssd1306_DrawRectangle(75,43,105,52,White);
    }
    while (state == wait)
    {   
        interface_showorclear(1);
        hanuoyi(3,true);
    }
}

void choose_face(){
    x_line = 19;
    y_line = 24;
    while(state == selection){
        ssd1306_Fill(Black);
        ssd1306_DrawLine(x_line,y_line,x_line+16,y_line,White);
        for(int i=1;i<=6;i++){
            int x1 = i>=4? 17*(i-3)+20*(i-4):17*i+20*(i-1);
            int y1 = i>=4?32:6;
            ssd1306_DrawRectangle(x1,y1,x1+20,y1+20,White);
            char str[20];
            sprintf(str,"%d",i+2);
            ssd1306_SetCursor(x1+5, y1+3);
            ssd1306_DrawString(str, Font_7x10, White);
        }
        ssd1306_UpdateScreen();
    }
    
}

void playing_face(){
    ssd1306_Fill(Black);
    for(int i=0;i<3;i++){
        for(int j=0;j<chosen+2;j++){
            if(i == 0){
                pi[i].plate[j].id = j;
                pi[i].plate[j].width = unitwidth+3*j;
            }
            else{
                pi[i].plate[j].id = -1;
            }
        }
        pi[i].ischoose = false;
        pi[i].num = i==0?chosen+2:0;
    }
    
    ssd1306_DrawCircle(circle_x,circle_y,radius,White);
    showorclear_play(0);

    while(state == playing){
        if(press2){
            choose_pillar++;
            if (choose_pillar > 3)
            {
                choose_pillar = 1;
            }
            ssd1306_DrawCircle(circle_x, circle_y, radius, Black);
            circle_x = 32 * choose_pillar;
            ssd1306_DrawCircle(circle_x, circle_y, radius, White);
            ssd1306_UpdateScreen();

            press2 = 0;
        }
        if(press){
            int k = iseverchoose(pi);
            if (pi[choose_pillar - 1].ischoose)
            {
                pi[choose_pillar - 1].ischoose = false;
                ssd1306_DrawRectangle(32 * choose_pillar - 6, circle_y-5, 32 * choose_pillar + 6, circle_y+5, Black);
                ssd1306_UpdateScreen();
            }
            else if (k == -1)
            {
                pi[choose_pillar - 1].ischoose = true; 
                ssd1306_DrawRectangle(32 * choose_pillar - 6, circle_y-5, 32 * choose_pillar + 6, circle_y+5, White);
                ssd1306_UpdateScreen();
            }
            else
            {
                ssd1306_DrawRectangle(32 * choose_pillar - 6, circle_y-5, 32 * choose_pillar + 6, circle_y+5, White);
                ssd1306_UpdateScreen();
                PILLAR *b = &pi[choose_pillar - 1];
                PILLAR *a = &pi[k];

                if ((b->num == 0 || a->plate[0].id < b->plate[0].id) && a->num !=0)
                {
                    showorclear_play(1);
                    b->num++;
                    for (int i = b->num - 1; i > 0; i--)
                    {
                        b->plate[i] = b->plate[i - 1];
                    }
                    b->plate[0] = a->plate[0];
                    a->num--;
                    for (int i = 0; i < a->num; i++)
                    {
                        a->plate[i] = a->plate[i + 1];
                    }
                    movetime++;
                    showorclear_play(0);
                }

                for (int i = 0; i < 3; i++)
                {
                    pi[i].ischoose = false;
                    ssd1306_DrawRectangle(32 * (i + 1) - 6, circle_y-5, 32 * (i + 1) + 6, circle_y+5, Black);
                }
                ssd1306_UpdateScreen();
            }
            press = 0;
        }
        usleep(100);
        if(pi[0].num+pi[1].num == 0){
            ssd1306_SetCursor(46, 29);
            ssd1306_DrawString("YOU WIN!", Font_7x10, White);
            ssd1306_UpdateScreen();
            state = end;
        }
    }

}

void toggle_choose(){
    if(choose){
        ssd1306_DrawRectangle(25,43,55,52,Black);
        ssd1306_DrawRectangle(75,43,105,52,White);
    }
    else{
        ssd1306_DrawRectangle(75,43,105,52,Black);
        ssd1306_DrawRectangle(25,43,55,52,White);
    }
}

void isend(){
    if(pi[0].num + pi[1].num == 0){
        return true;
    }
    return false;
}

void hanuoyi(int n,bool inter){
    for(int i=0;i<3;i++){
        for(int j=0;j<n;j++){
            if(i == 0){
                p[i].plate[j].id = j;
                p[i].plate[j].width = unitwidth+3*j;
            }
            else{
                p[i].plate[j].id = -1;
            }
        }
        p[i].num = i==0?n:0;
    }
    if(inter){
        interface_showorclear(0);
    }
    else{
        showorclear(0);
    }
    usleep(1000);
    digui(n,&p[0],&p[1],&p[2],inter);
}

void digui(int n,PILLAR *a,PILLAR *b,PILLAR *c,bool inter){
    if(n == 1){
        move(a,c,inter);
        return;
    }

    digui(n-1,a,c,b,inter);
    move(a,c,inter);
    digui(n-1,b,a,c,inter);

}

void move(PILLAR *a,PILLAR *b,bool inter){ //从a柱子移动去b柱子
    if(inter){
        interface_showorclear(1);
    }
    else{
        showorclear(1);
    }

    b->num++;
    for(int i=b->num-1;i>0;i--){
        b->plate[i] = b->plate[i-1]; 
    }
    b->plate[0] = a->plate[0];
    a->num--;
    for(int i=0;i<a->num;i++){
        a->plate[i] = a->plate[i+1];
    }
    if(inter){
        interface_showorclear(0);
    }
    else{
        movetime++;
        showorclear(0);
    }
    if(inter){
        while(cnt<10000){
            cnt++;
        }
        cnt=0;
    }
    else{
        usleep(500*1000);
    }
}

bool press_mix = false;

void get_gpio5_voltage0(void *arg){
    (void) arg;
    press_mix = true;
}

void OnButtonPressed0(void* arg){
    (void) arg;
    mix_ischoose = true;
}

void Ssd1306TestTask(void* arg)
{
    IoTGpioInit(HI_IO_NAME_GPIO_5);
    hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_5, IOT_GPIO_DIR_IN);
    hi_io_set_pull(HI_IO_NAME_GPIO_5, HI_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(HI_IO_NAME_GPIO_5, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            get_gpio5_voltage0, NULL);

    IoTGpioInit(HI_IO_NAME_GPIO_13);
    IoTGpioInit(HI_IO_NAME_GPIO_14);

    // 交通灯按键初始化
    IoTGpioInit(IOT_GPIO_KEY); 
    hi_io_set_func(IOT_GPIO_KEY, 0);
    IoTGpioSetDir(IOT_GPIO_KEY, IOT_GPIO_DIR_IN);
    hi_io_set_pull(IOT_GPIO_KEY, HI_IO_PULL_UP);
    // 设置按键中断回调函数
    IoTGpioRegisterIsrFunc(IOT_GPIO_KEY, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            OnButtonPressed0, NULL);

    IoTGpioInit(IOT_PWM_BEEP);
    hi_io_set_func(IOT_PWM_BEEP, 5);
    IoTGpioSetDir(IOT_PWM_BEEP, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM0);

    IoTWatchDogDisable();

    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);
    
    IoTI2cInit(0, OLED_I2C_BAUDRATE);

    mix_face();
    
}

void mix_face(){
    ssd1306_Init();
    ssd1306_Fill(Black);

    int delta_x = (128-gamenum*but_length)/(gamenum+1);
    int delta_y = (58-but_length)/2;
    for(int i=1;i<=gamenum;i++){
        int x1 = i*delta_x+(i-1)*but_length;
        ssd1306_DrawRectangle(x1,delta_y-10,x1+but_length,delta_y+but_length-10,White);
        char str[20];
        sprintf(str,"%d",i);
        ssd1306_SetCursor(x1+10,delta_y);
        ssd1306_DrawString(str, Font_7x10, White);

        ssd1306_SetCursor(x1-5,delta_y+but_length-5);
        ssd1306_DrawString(s[i-1], Font_7x10, White);
        if(i==2){
            ssd1306_SetCursor(x1-5,delta_y+but_length+5);
        }
        else{
            ssd1306_SetCursor(x1+1,delta_y+but_length+5);
        }
        ssd1306_DrawString(s2[i-1], Font_7x10, White);
    }
    ssd1306_DrawLine(xline,yline,xline+but_length-10,yline,White);

    ssd1306_UpdateScreen();

    while (!mix_ischoose)
    {
        usleep(100);
        // ssd1306_DrawCircle(0,58,0,White);//前导
        if(press_mix){
            ssd1306_DrawLine(xline,yline,xline+but_length-10,yline,Black);
            ssd1306_UpdateScreen();
            choose_mix++;
            if (choose_mix > gamenum)
            {
                choose_mix = 1;
            }
            xline = (choose_mix)*(128-gamenum*but_length)/(gamenum+1)+5+(choose_mix-1)*but_length;
            ssd1306_DrawLine(xline,yline,xline+but_length-10,yline,White);
            ssd1306_UpdateScreen();

            press_mix = false;
        }
    }

    ssd1306_Fill(Black);
    if(choose_mix == 1){
        Jumping_ball();
    }
    else if(choose_mix == 2){
        Hanuoyi();
    }
    else if(choose_mix == 3){
        Flabby_bird();
    }
}

void Hanuoyi(void *arg){
    (void) arg;
    
    IoTGpioInit(HI_IO_NAME_GPIO_5);
    hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_5, IOT_GPIO_DIR_IN);
    hi_io_set_pull(HI_IO_NAME_GPIO_5, HI_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(HI_IO_NAME_GPIO_5, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            get_gpio5_voltage1, NULL);

    IoTGpioInit(HI_IO_NAME_GPIO_13);
    IoTGpioInit(HI_IO_NAME_GPIO_14);

    // 交通灯按键初始化
    IoTGpioInit(IOT_GPIO_KEY); 
    hi_io_set_func(IOT_GPIO_KEY, 0);
    IoTGpioSetDir(IOT_GPIO_KEY, IOT_GPIO_DIR_IN);
    hi_io_set_pull(IOT_GPIO_KEY, HI_IO_PULL_UP);
    // 设置按键中断回调函数
    IoTGpioRegisterIsrFunc(IOT_GPIO_KEY, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            OnButtonPressed1, NULL);

    IoTGpioInit(IOT_PWM_BEEP);
    hi_io_set_func(IOT_PWM_BEEP, 5);
    IoTGpioSetDir(IOT_PWM_BEEP, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM0);

    IoTWatchDogDisable();

    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);
    
    IoTI2cInit(0, OLED_I2C_BAUDRATE);

    // WatchDogDisable();
    //代码从这里开始写

    startup();
    HAL_Delay(100);
    ssd1306_Fill(Black);
}

#define CLK_160M 160000000
#define OLED_I2C_BAUDRATE (400*1000)
#define IOT_GPIO_KEY 8
#define IOT_PWM_BEEP 9
#define IOT_PWM_PORT_PWM0 0
#define IOT_GPIO_IDX_10 10
#define IOT_GPIO_IDX_11 11
#define IOT_GPIO_IDX_12 12
#define ADC_TEST_LENGTH 64

typedef struct {
    uint8_t x;
    int y;
    uint8_t r;
    uint8_t jump;
    uint8_t g;
} CIRCLE;

typedef struct {
    uint8_t x;
    uint8_t y;
    uint8_t w;
    uint8_t h;
    bool isOver;
} RECTANGLE;

static int g_beepState = 0;
static CIRCLE circle = { 20, 58, 5, 22, 3};
static int g_keyState = 0;
static int score = 0;
static bool levelUp = false;
static bool gameOver = false;
static int doubleJump = 0;
static int smallBall = 0;
static int randScore = 0;
static uint8_t original_y = 58;
static uint32_t startTime;
static uint32_t endTime;
static uint32_t startSmallBallTime;
static uint32_t endSmallBallTime;
static uint32_t startButtonTime = 0;
static uint32_t lstartButtonTime = 0;

unsigned int  pins[3] = {IOT_GPIO_IDX_10, IOT_GPIO_IDX_12, IOT_GPIO_IDX_11};

uint8_t max(uint8_t a, uint8_t b){
    return a > b? a : b;
}

uint32_t min(uint8_t a, uint8_t b){
    return a < b? a : b;
}

//判断球与矩形是否碰撞
bool isTouch(RECTANGLE rect){
    uint8_t h = max(circle.y, rect.y);
    uint32_t distanceX;
    if(rect.x >= circle.x) {
        distanceX = (rect.x - circle.x) * (rect.x - circle.x);
    }
    else if (rect.x + rect.w >= circle.x) {
        distanceX = min((circle.x - rect.x) * (circle.x - rect.x), (rect.x + rect.w - circle.x) * (rect.x + rect.w - circle.x));
    }
    else {
        distanceX = (circle.x - rect.x - rect.w) * (circle.x - rect.x - rect.w);
    }
    uint32_t distanceY = (circle.y - h) * (circle.y - h);;
    return distanceX + distanceY <= circle.r * circle.r;
}

static void OnButtonPressed(void *arg)
{
    (void) arg;
    if (circle.y == original_y){
        startTime = HAL_GetTick();
        g_keyState = 1;
    }
}

void GameOver(){
    while(gameOver){
        ssd1306_SetCursor(50, 10);
        ssd1306_DrawString("GAME OVER!", Font_7x10, White);
        ssd1306_UpdateScreen();
    }
}

// void get_gpio5_voltage2(hi_void *param)
// {
//     hi_u16[128] g_adc_buf;
//     int i;
//     hi_u16 data;
//     hi_u32 ret;
//     hi_u16 vlt;
//     float voltage;
//     float vlt_max = 0;
//     float vlt_min = VLT_MIN;
//     float vlt_val = 0;

//     hi_unref_param(param);
//     memset_s(g_adc_buf, sizeof(g_adc_buf), 0x0, sizeof(g_adc_buf));

//     for (i = 0; i < ADC_TEST_LENGTH; i++) {
//         ret = hi_adc_read((hi_adc_channel_index)HI_ADC_CHANNEL_2, &data, HI_ADC_EQU_MODEL_1, HI_ADC_CUR_BAIS_DEFAULT, 0);
//         if (ret != HI_ERR_SUCCESS) {
//             printf("ADC Read Failn");
//             return;
//         }
//         g_adc_buf[i] = data;
//     }
//     for (i = 0; i < data_len; i++) {
//         vlt = g_adc_buf[i];
//         float voltage = (float)vlt * 1.8 * 4 / 4096.0;  /* vlt * 1.8 * 4 / 4096.0: Convert code into voltage */
//         vlt_max = (voltage > vlt_max) ? voltage : vlt_max;
//         vlt_min = (voltage < vlt_min) ? voltage : vlt_min;
//     }
//     vlt_val = (vlt_min + vlt_max)/2.0;
//     if((vlt_val > 0.4) && (vlt_val < 0.6))
//     {
//         //按键1
//         score += 10;
//     }
//     if((vlt_val > 0.8) && (vlt_val < 1.1))
//     {
//         //按键2
//         score -= 10;
//     }
//     if((vlt_val > 0.01) && (vlt_val < 0.3))
//     {
//         //user按键
//         score = 0;
//     }
    
// }

void get_gpio5_voltage(void *arg)
{
    (void) arg;
    if(gameOver){
        gameOver = false;
    }
    else if(doubleJump == 1 && circle.y != original_y){
        IoTGpioSetOutputVal(pins[0], IOT_GPIO_VALUE0);
        if(circle.y - 30 <= 0){
            circle.jump = 1;
        }
        else {
            circle.jump = circle.y - 30 < 22 ? circle.y - 30 : 22;
        }
        g_keyState = 1;
        doubleJump = 2;
    }
    else if(smallBall == 1){
        ssd1306_DrawCircle(circle.x, circle.y, circle.r, Black);
        smallBall = 2;
        circle.r = 3;
        original_y = 60;
    }
    else if(randScore) {
        IoTGpioSetOutputVal(pins[2], IOT_GPIO_VALUE0);
        randScore = 0;
        score += rand() % 10 - 3;
        char str[16];
        sprintf(str, "Score: %d", score);
        ssd1306_SetCursor(50, 10);
        ssd1306_DrawString(str, Font_7x10, White);
    }
}

void Jumping_ball(void* arg)
{
    (void) arg;
    IoTGpioInit(HI_IO_NAME_GPIO_5);
    hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_5, IOT_GPIO_DIR_IN);
    hi_io_set_pull(HI_IO_NAME_GPIO_5, HI_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(HI_IO_NAME_GPIO_5, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            get_gpio5_voltage, NULL);

    IoTGpioInit(HI_IO_NAME_GPIO_13);
    IoTGpioInit(HI_IO_NAME_GPIO_14);
    
    // 交通灯按键初始化
    IoTGpioInit(IOT_GPIO_KEY); 
    hi_io_set_func(IOT_GPIO_KEY, 0);
    IoTGpioSetDir(IOT_GPIO_KEY, IOT_GPIO_DIR_IN);
    hi_io_set_pull(IOT_GPIO_KEY, HI_IO_PULL_UP);

    // 设置按键中断回调函数
    IoTGpioRegisterIsrFunc(IOT_GPIO_KEY, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            OnButtonPressed, NULL);
    IoTGpioInit(IOT_PWM_BEEP);
    hi_io_set_func(IOT_PWM_BEEP, 5);
    IoTGpioSetDir(IOT_PWM_BEEP, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM0);

    IoTWatchDogDisable();

    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);

    IoTGpioInit(IOT_GPIO_IDX_10);
    IoTGpioSetDir(IOT_GPIO_IDX_10, IOT_GPIO_DIR_OUT);

    IoTGpioInit(IOT_GPIO_IDX_11);
    IoTGpioSetDir(IOT_GPIO_IDX_11, IOT_GPIO_DIR_OUT);

    IoTGpioInit(IOT_GPIO_IDX_12);
    IoTGpioSetDir(IOT_GPIO_IDX_12, IOT_GPIO_DIR_OUT);

    IoTI2cInit(0, OLED_I2C_BAUDRATE);


    usleep(20*1000);
    ssd1306_Init();
    ssd1306_Fill(Black);
    ssd1306_SetCursor(0, 0);
    ssd1306_DrawString("READY!", Font_7x10, White);
    ssd1306_UpdateScreen();
    HAL_Delay(1000);

    A: ssd1306_Fill(Black);

    RECTANGLE rect[2] = {{126, 43, 6, 20, false}, {196, 43, 6, 20, false}};
    uint8_t x = 126;
    uint8_t y_max = 63;
    rect[0].y = rand() % 20 + 43;
    rect[1].y = rand() % 20 + 43;
    ssd1306_SetCursor(50, 10);
    ssd1306_DrawString("Score: 0", Font_7x10, White);

    while(1) {
        for (int i = 0; i < 2; i++) {
            ssd1306_DrawRectangle(rect[i].x, y_max, rect[i].x + rect[i].w, rect[i].y, Black);
        }
        ssd1306_DrawCircle(circle.x, circle.y, circle.r, Black);

        if(circle.y > original_y){
            circle.y = original_y;
        }

        if(doubleJump || smallBall || randScore){
            endTime = HAL_GetTick();
            if(endTime - startTime > 100){
                IoTPwmStop(IOT_PWM_PORT_PWM0);
            }
        }

        if(smallBall == 2){
            startSmallBallTime = HAL_GetTick();
            smallBall = 3;
        }
        else if(smallBall == 3){
            endSmallBallTime = HAL_GetTick();
            if(endSmallBallTime - startSmallBallTime > 5*1000){
                original_y = 58;
                circle.r = 5;
                IoTGpioSetOutputVal(pins[1], IOT_GPIO_VALUE0);
                smallBall = 0;
            }
        }

        if(g_keyState == 1){
            circle.y -= circle.g;
            if (circle.y <= circle.jump){
                g_keyState = 0;
            }
            if(endTime - startTime > 1000){
                IoTPwmStop(IOT_PWM_PORT_PWM0);
            }
        }
        else if(circle.y < original_y){
            circle.y += circle.g;
            if(circle.y >= original_y && doubleJump == 2){
                circle.jump = 22;
                doubleJump = 0;
            }
        }
        ssd1306_DrawCircle(circle.x, circle.y, circle.r, White);
        for (int i = 0; i < 2; i++) {
            if(rect[i].x <= 0) {
                rect[i].x = 126;
                rect[i].y = rand() % 20 + 43;
                rect[i].isOver = false;
                if (levelUp){
                    rect[i].w++;
                    if(i == 1){
                        levelUp = false;
                    }
                }
            }
            else {
                rect[i].x -= 2;
            }
            ssd1306_DrawRectangle(rect[i].x, y_max, rect[i].x + rect[i].w, rect[i].y, White);
            if(isTouch(rect[i])) {
                IoTGpioSetOutputVal(pins[0], IOT_GPIO_VALUE0);
                IoTGpioSetOutputVal(pins[1], IOT_GPIO_VALUE0);
                IoTGpioSetOutputVal(pins[2], IOT_GPIO_VALUE0);
                score = 0;
                doubleJump = 0;
                smallBall = 0;
                randScore = 0;
                g_keyState = 0;
                circle.r = 5;
                circle.y = original_y;
                circle.jump = 22;
                gameOver = true;
                GameOver();
                goto A;
            }
            else if(circle.x + circle.r > rect[i].x + rect[i].w && !rect[i].isOver){
                score++;
                if(score % 5 == 0 && score < 35){
                    levelUp = true;
                }
                if(score % 5 == 0) {
                    int randNum = rand() % 3;
                    if(randNum == 0){        
                        startTime = HAL_GetTick();
                        IoTPwmStart(IOT_PWM_PORT_PWM0, 50,  CLK_160M/51021);
                        doubleJump = 1;
                        if (smallBall != 3) smallBall = 0;
                        randScore = 0;
                        IoTGpioSetOutputVal(pins[1], IOT_GPIO_VALUE0);
                        IoTGpioSetOutputVal(pins[2], IOT_GPIO_VALUE0);
                        IoTGpioSetOutputVal(pins[0], IOT_GPIO_VALUE1);
                    }
                    else if(randNum == 1 && smallBall != 3){
                        startTime = HAL_GetTick();
                        IoTPwmStart(IOT_PWM_PORT_PWM0, 50,  CLK_160M/51021);
                        smallBall = 1;
                        doubleJump = 0;
                        randScore = 0;
                        IoTGpioSetOutputVal(pins[0], IOT_GPIO_VALUE0);
                        IoTGpioSetOutputVal(pins[2], IOT_GPIO_VALUE0);
                        IoTGpioSetOutputVal(pins[1], IOT_GPIO_VALUE1);
                    }
                    else if(randNum == 2){
                        startTime = HAL_GetTick();
                        IoTPwmStart(IOT_PWM_PORT_PWM0, 50,  CLK_160M/51021);
                        randScore = 1;
                        doubleJump = 0;
                        if(smallBall != 3) smallBall = 0;
                        IoTGpioSetOutputVal(pins[0], IOT_GPIO_VALUE0);
                        IoTGpioSetOutputVal(pins[1], IOT_GPIO_VALUE0);
                        IoTGpioSetOutputVal(pins[2], IOT_GPIO_VALUE1);
                    }
                }
                rect[i].isOver = true;
                char str[16];
                sprintf(str, "Score: %d", score);
                ssd1306_SetCursor(50, 10);
                ssd1306_DrawString(str, Font_7x10, White);
            }
        }
        // ssd1306_DrawRectangle(x, y, x + 6, y2, White);
        // ssd1306_DrawLine(circle.x, circle.y, circle.x, circle.y + circle.r, White);
        ssd1306_UpdateScreen();
    }
}

#define wallnum 4

typedef struct {
    int x;
    int y;
    int vy;
    int r;
    float g;
    int score;
} CIRCLE1;

typedef struct {
    int x;
    int y;
    int w;
} RECTANGLE1;

static CIRCLE1 Circle = { 20, 28, 0,3, 1,0};
static RECTANGLE1 rect[wallnum] = {{126, 43, 6}};
static RECTANGLE1 rectup[wallnum] = {{126,43,6}};
static int vx = 2;
static uint32_t startTime;
static uint32_t endTime;
int gapheight = 35;
int y_max1 = 63;
int startgame = 2;
bool start = 1;
bool chooses = true;

bool isTouch1(RECTANGLE1 rectt,bool up){
    if(Circle.x + Circle.r >= rectt.x && Circle.x-Circle.r <= rectt.x+rectt.w){
        if(up){
            if(Circle.y-Circle.r <= rectt.y){
                return true;
            }
        }
        else{
            if(Circle.y+Circle.r>=rectt.y){
                return true;
            }
        }
    }
    return false;
}

static void OnButtonPressed2(void *arg)
{
    (void) arg;
    if(start){
        ssd1306_DrawLine(0,0,127,0,White);
        if(chooses){
            startgame = 1;
        }
        else{
            startgame = 0;
        }
        start = 0;
    }
    else{
        Circle.vy = -4;
    }
    // printf("Button pressed, g_beepState = %d\r\n", g_beepState);
    // ssd1306_DrawLine(0, 0, 127, 0, White);
}

void get_gpio5_voltage2(void *arg)
{
    (void) arg;
    toggle_choose1();
    chooses = !chooses;
}

void showorclear1(bool clear){
    SSD1306_COLOR color;
    if(clear){
        color = Black;
    }
    else{
        color = White;
    }
    ssd1306_DrawCircle(Circle.x,Circle.y,Circle.r,color);
    for(int i=0;i<wallnum;i++){
        ssd1306_DrawRectangle(rect[i].x, 0, rect[i].x + rect[i].w, rectup[i].y, color);
        ssd1306_DrawRectangle(rect[i].x, rect[i].y, rect[i].x + rect[i].w, y_max1, color);
    }
    ssd1306_DrawCircle(Circle.x, Circle.y, Circle.r, color);
    char str[16];
    sprintf(str,"Score: %d",Circle.score);
    ssd1306_SetCursor(0,10);
    ssd1306_DrawString(str, Font_7x10, color);
}

void deleteStr(){
    char str[16];
    sprintf(str,"Score: %d",Circle.score);
    ssd1306_SetCursor(0,10);
    ssd1306_DrawString(str, Font_7x10, Black);
}

void toggle_choose1(){
    if(chooses){
        ssd1306_DrawRectangle(25,43,55,52,Black);
    }
    else{
        ssd1306_DrawRectangle(75,43,105,52,Black);
    }
}

void show_clear(bool clear,RECTANGLE1 *rect,RECTANGLE1 *rectup,CIRCLE1 ball,bool choose){
    SSD1306_COLOR color;
    if(clear){
        color = Black;
    }
    else{
        color = White;
    }
    for(int i=0;i<2;i++){
        ssd1306_DrawRectangle(rect[i].x, 0, rect[i].x + rect[i].w, rectup[i].y, color);
        ssd1306_DrawRectangle(rect[i].x, rect[i].y, rect[i].x + rect[i].w, 28, color);
    }
    ssd1306_DrawCircle(ball.x,ball.y,ball.r,color);
    ssd1306_DrawRectangle(20,40,60,55,color);
    ssd1306_SetCursor(30,44);
    ssd1306_DrawString("YES", Font_7x10, color);
    ssd1306_DrawRectangle(70,40,110,55,color);
    ssd1306_SetCursor(80,44);
    ssd1306_DrawString("NO", Font_7x10, color);
    if(chooses){
        ssd1306_DrawRectangle(25,43,55,52,color);
    }
    else{
        ssd1306_DrawRectangle(75,43,105,52,color);
    }
}

void updatewithoutinput1(){
    Circle.y += Circle.vy;
    Circle.vy += Circle.g;
    if(Circle.y - Circle.r>=70){
        Circle.y = 28;
        Circle.vy = 0;
        Circle.score = 0;
    }
    for(int i=0;i<wallnum;i++){
        if(rect[i].x <= 0) {
            Circle.score++;
            if(Circle.score%5 == 0 && Circle.score != 0 && Circle.score < 20){
                vx += 2;
                gapheight -= 2;
            }
            rect[i].x = 126;
            rect[i].y = rand() % 15 + 40;
            rectup[i].x = rect[i].x;
            rectup[i].y = rect[i].y - gapheight;
        }
        else{
            rect[i].x -= vx;
            rectup[i].x -= vx;
        }

        if(isTouch1(rectup[i],1)){
            deleteStr();
            Circle.score = 0;
            vx = 2;
            gapheight = 35;
            usleep(20000);
        }
        if(isTouch1(rect[i],0)){
            deleteStr();
            Circle.score = 0;
            vx = 2;
            gapheight = 35;
            usleep(20000);
        }
    }

}

void startup1(){
    for(int i=1;i<wallnum;i++){
        rect[i].w = rect[0].w;
        rectup[i].w = rectup[0].w;
        rect[i].x = rect[i-1].x + (128-rect[0].w*wallnum)/wallnum;
        rectup[i].x = rectup[i-1].x + (128-rectup[0].w*wallnum)/(wallnum-1);
        rect[i].y = rand() % 15 + 40;
        rectup[i].y = rect[i].y-gapheight;
    }
    usleep(20*1000);
    ssd1306_Init();
    ssd1306_Fill(Black);
    ssd1306_SetCursor(0, 30);
    ssd1306_DrawString("PLAY?", Font_7x10, White);
    RECTANGLE1 ex[2] = {{80,20,2},{150,25,2}};
    RECTANGLE1 exup[2] = {{80,5,2},{150,10,2}};
    CIRCLE1 exball = {10,10,0,2,1};
    while(1){
        usleep(2000);
        show_clear(1,ex,exup,exball,choose);
        if(exball.y >= 23){
            exball.vy = -3;
        }
        exball.y+=exball.vy;
        exball.vy += exball.g;
        for(int i=0;i<2;i++){
            if(ex[i].x+ex[i].w <=-3){
                ex[i].x = 127;
            }
            else{
                ex[i].x -= 5;
            }
        }
        for(int i=0;i<2;i++){
            if(exup[i].x+exup[i].w <=0){
                exup[i].x = 127;
            }
            else{
                exup[i].x -= 5;
            }
        }
        show_clear(0,ex,exup,exball,choose);

        if(startgame == 1){
            show_clear(1,ex,exup,exball,choose);
            break;
        }
        else if(startgame == 0){
            show_clear(1,ex,exup,exball,choose);
            ssd1306_SetCursor(65, 24);
            ssd1306_DrawString("BYE!", Font_7x10, White);
            usleep(50000*1000);
            return;
        }

        ssd1306_UpdateScreen();
    }
}

void Flabby_bird(){
    IoTGpioInit(HI_IO_NAME_GPIO_5);
    hi_io_set_func(HI_IO_NAME_GPIO_5, HI_IO_FUNC_GPIO_5_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_5, IOT_GPIO_DIR_IN);
    hi_io_set_pull(HI_IO_NAME_GPIO_5, HI_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(HI_IO_NAME_GPIO_5, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            get_gpio5_voltage2, NULL);

    IoTGpioInit(HI_IO_NAME_GPIO_13);
    IoTGpioInit(HI_IO_NAME_GPIO_14);

    // 交通灯按键初始化
    IoTGpioInit(IOT_GPIO_KEY); 
    hi_io_set_func(IOT_GPIO_KEY, 0);
    IoTGpioSetDir(IOT_GPIO_KEY, IOT_GPIO_DIR_IN);
    hi_io_set_pull(IOT_GPIO_KEY, HI_IO_PULL_UP);
    // 设置按键中断回调函数
    IoTGpioRegisterIsrFunc(IOT_GPIO_KEY, IOT_INT_TYPE_EDGE, IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                            OnButtonPressed2, NULL);

    IoTGpioInit(IOT_PWM_BEEP);
    hi_io_set_func(IOT_PWM_BEEP, 5);
    IoTGpioSetDir(IOT_PWM_BEEP, IOT_GPIO_DIR_OUT);
    IoTPwmInit(IOT_PWM_PORT_PWM0);

    IoTWatchDogDisable();

    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);
    
    IoTI2cInit(0, OLED_I2C_BAUDRATE);

    // WatchDogDisable();

    startup1();
    HAL_Delay(100);

    int x = 126;
    int y2 = 43;
    rect[0].y = rand() % 20 + 30;
    rect[1].y = rand()%20 + 30;
    rectup[0].y = rect[0].y - gapheight;
    rectup[1].y = rect[1].y-gapheight;
    ssd1306_SetCursor(0, 10);
    ssd1306_DrawString("Score: 0", Font_7x10, White);

    while(1){
        showorclear1(1);
        updatewithoutinput1();
        showorclear1(0);

        ssd1306_UpdateScreen();
    }
}


void Ssd1306TestDemo(void)
{
    osThreadAttr_t attr;

    attr.name = "Ssd1306Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 10240;
    attr.priority = osPriorityNormal;

    if (osThreadNew(Ssd1306TestTask, NULL, &attr) == NULL) {
        printf("[Ssd1306TestDemo] Falied to create Ssd1306TestTask!\n");
    }
}


APP_FEATURE_INIT(Ssd1306TestDemo);




