# WIFI\_IOT\_APP组件<a name="ZH-CN_TOPIC_0000001132694217"></a>

-   [简介](#section11660541593)
-   [目录](#section1464106163817)
-   [涉及仓](#section1718733212019)

## 简介<a name="section11660541593"></a>

WIFI\_IOT\_APP组件，提供了iothardware、demolink、samgr等示例代码。

## 目录<a name="section1464106163817"></a>

```
applications/sample/wifi-iot/         # sample模块目录
└── app
    ├── BUILD.gn                   # 模块构建脚本
    ├── demolink                   # demolink集成示例代码
    ├── iothardware                # LED操作示例代码
    ├── samgr                      # 服务框架示例代码
    └── startup
```

## 涉及仓<a name="section1718733212019"></a>

applications\_sample\_wifi-iot

