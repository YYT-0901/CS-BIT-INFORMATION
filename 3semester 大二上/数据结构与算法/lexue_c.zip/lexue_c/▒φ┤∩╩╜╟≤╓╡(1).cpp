#include<iostream>
#include<stack>
#include<string>
#include<cmath>

using namespace std;

stack<int> st1;
stack<char> st2;
string a;
int n;
int pos = 0;
int ans = 0;
int flag = 0;

int doit(char op){
	if(op == '('){
		printf("error.\n");
		flag = 3;
		return 0;
	}
	else if(op == ')'){
		printf("error.\n");
		flag = 3;
		return 0;
	}
	if(st1.empty()){
		printf("error.\n");
		flag = 1;
		return 0;
	}
	int b = st1.top();
	st1.pop();
	if(st1.empty()){
		printf("error.\n");
		flag = 1;
		return 0;
	}
	int a = st1.top();
	st1.pop();
	switch(op){
		case '+':return a + b;break;
		case '-':return a - b;break;
		case '*':return a * b;break;
		case '/':
				if(b == 0){
					printf("Divide 0.\n");
					flag = 2;
				}
				else{
					return a / b;	
				}
				;break;
		case '%':return a % b;break;
		case '^':
			if(b < 0){
				printf("error.\n");
				flag = 4;
			}
			else{
				return pow(a, b);
			}
		;break;
	}
	return 0;
}

int main(){
	scanf("%d", &n);
	while(n--){
		while(st1.size()){
			st1.pop();
		}
		while(st2.size()){
			st2.pop();
		}
		a = "";
		flag = 0;
		ans = 0;
		pos = 0;
		cin >> a;
		while(a[pos] != '\0'){
			if(a[pos] >= '0' && a[pos] <= '9'){
				ans = a[pos] - '0';
				pos++;
				while(a[pos] != '\0' && a[pos] >= '0' && a[pos] <= '9'){
					ans *= 10;
					ans += a[pos] - '0';
					pos++;
				}
				st1.push(ans);
				pos--;
			}
			else if(a[pos] == '(' || a[pos] == '^'){
				if(a[pos] == '('){
					if(pos - 1 > 0 && (a[pos - 1] >= '0' && a[pos - 1] <= '9') || a[pos + 1] == '+' || a[pos + 1] == '*' || a[pos + 1] == '/' || a[pos + 1] == '%' || a[pos + 1] == '^'){
						printf("error.\n");
						flag = 3;
					}
				}
				if(flag){
					break;
				}
				st2.push(a[pos]);
			}
			else if(a[pos] == '*' || a[pos] == '/' || a[pos] == '%'){
				if(st2.size() && (st2.top() == '*' || st2.top() == '/' || st2.top() == '%')){
					st1.push(doit(st2.top()));//
					st2.pop();
					st2.push(a[pos]);
				}
				else if(st2.empty() || st2.top() != '^'){
					st2.push(a[pos]);
				}
				else{
					while(st2.size() && (st2.top() != '(' && st2.top() != '+' && st2.top() != '-')){
						st1.push(doit(st2.top()));
						st2.pop();
						if(flag){
							break;
						}
					}
					if(flag){
						break;
					}
					st2.push(a[pos]);
				}
			}
			else if(a[pos] == '+' || a[pos] == '-'){
				if(a[pos] == '-' && (pos - 1 < 0 || (a[pos - 1] == '+' || a[pos - 1] == '-' || a[pos - 1] == '*' || a[pos - 1] == '/' || a[pos - 1] == '%' || a[pos - 1] == '^' || a[pos - 1] == '('))){
					pos++;
					ans = a[pos] - '0';
					pos++;
					while(a[pos] != '\0' && a[pos] >= '0' && a[pos] <= '9'){
						ans *= 10;
						ans += a[pos] - '0';
						pos++;
					}
					st1.push(-ans);
					pos--;
				}
				else if(st2.size() && (st2.top() == '+' || st2.top() == '-')){
					st1.push(doit(st2.top()));
					st2.pop();
					if(flag){
						break;
					}
					st2.push(a[pos]);
				}
				else if(st2.empty() || (st2.top() != '^' && st2.top() != '*' && st2.top() != '/' && st2.top() != '%')){
					st2.push(a[pos]);
				}
				else{
					while(st2.size() && st2.top() != '('){
						st1.push(doit(st2.top()));
						st2.pop();
						if(flag){
							break;
						}
					}
					if(flag){
						break;
					}
					st2.push(a[pos]);
				}
			}
			else if(a[pos] == ')'){
				// if(pos - 1 > 0 && (a[pos + 1] >= '0' && a[pos + 1] <= '9') || a[pos - 1] == '+' || a[pos - 1] == '-' || a[pos - 1] == '*' || a[pos - 1] == '/' || a[pos - 1] == '%' || a[pos - 1] == '^'){
					// printf("error.\n");
					// flag = 3;
					// break;
				// }
				while(st2.size() && st2.top() != '('){
					st1.push(doit(st2.top()));
					st2.pop();
					if(flag){
						break;
					}
				}
				
				if(flag){
					break;
				}
				
				if(st2.empty()){
					printf("error.\n");
					flag = 2;
					break;
				}
				st2.pop();
			}
			pos++;
		}
		if(flag){
			continue;
		}
		while(st2.size()){
			st1.push(doit(st2.top()));
			st2.pop();
			if(flag){
				break;
			}
		}
		if(flag){
			continue;
		}
		if(st1.size() == 1){
			printf("%d", st1.top());
		}
		else{
			printf("error.");
		}
		printf("\n");
	}
	return 0;
}