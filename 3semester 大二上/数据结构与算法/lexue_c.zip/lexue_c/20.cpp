#include<iostream>
#include<queue>

using namespace std;

int main(){
	int n;
	int d = 0, x = 0, a;
	int D = 0, X = 0;
	queue<char> q;
	queue<char> q2;
	scanf("%d", &n);
	getchar();
	for(int i = 0; i < n; ++i){
		a = getchar();
		if(a == 'D'){
			if(x > 0){
				x--;
			}
			else{
				q.push('D');
				D++;
				if(X > 0){
					X--;
					q.pop();
				}
				else{
					d++;
				}
			}
		}
		else if(a == 'X'){
			if(d > 0){
				d--;
			}
			else{
				q.push('X');
				X++;
				if(D > 0){
					D--;
					q.pop();
				}
				else{
					x++;
				}
			}
		}
	}
	
	while(X != 0 && D != 0){
		x = 0;
		X = 0;
		d = 0;
		D = 0;
		while(q2.size()){
			q.push(q2.front());
			q2.pop();
		}
		while(q.size()){
			a = q.front();
			q.pop();
			if(a == 'D'){
				if(x > 0){
					x--;
				}
				else{
					q2.push('D');
					D++;
					if(X > 0){
						X--;
						q2.pop();
					}
					else{
						d++;
					}
				}
			}
			else if(a == 'X'){
				if(d > 0){
					d--;
				}
				else{
					q2.push('X');
					X++;
					if(D > 0){
						D--;
						q2.pop();
					}
					else{
						x++;
					}
				}
			}
		}
	}
	if(X) printf("X\n");
	else printf("D\n");

	return 0;
}