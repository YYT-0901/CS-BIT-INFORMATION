#include<iostream>
#include<algorithm>
#include<cmath>

using namespace std;
const int N = 100010;

int main(){
	int n;
	int x[N], y[N];
	int xy[N];
	long long cnt = 0;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d %d", &x[i], &y[i]);
	}
	sort(y, y + n);
	sort(x, x + n);
	for(int i = 0; i < n; ++i){
		xy[i] = x[i] - i;
	}
	sort(xy, xy + n);
	int mx = xy[n / 2];
	int my = y[n / 2];
	for(int i = 0; i < n; ++i){
		cnt += abs(x[i] - mx - i);
		cnt += abs(y[i] - my);
	}
	printf("%lld\n", cnt);
	return 0;
}