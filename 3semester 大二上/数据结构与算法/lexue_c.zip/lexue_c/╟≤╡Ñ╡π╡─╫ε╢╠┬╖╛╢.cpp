#include<iostream>
#include<vector>
#include<queue>

using namespace std;

int g[1010][1010];

struct ComparePair {
    bool operator()(const pair<int, int>& p1, const pair<int, int>& p2) {
        return p1.second > p2.second;
    }
};

int main(){
	int n, m, w;
	char c, x, y;
	scanf("%d,%d,%c", &n, &m, &c);
	getchar();
	
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			g[i][j] = 0x3f3f3f3f;
		}
	}
	
	for(int i = 0; i < m; ++i){
		scanf("<%c,%c,%d>", &x, &y, &w);
		getchar();
		int a = x - 'a';
		int b = y - 'a';
		g[a][b] = g[a][b] > w ? w : g[a][b];
	}
	
	vector<int> dist(n, 0x3f3f3f3f);
	vector<bool> vis(n, false);
	
	int start = c - 'a';
	dist[start] = 0;
	priority_queue<pair<int, int>, vector<pair<int, int>>, ComparePair> pq;
	pq.push({start, dist[start]});
	while(pq.size()){
		auto t = pq.top();
		vis[t.first] = true;
		pq.pop();
		for(int i = 0; i < n; ++i){
			if(!vis[i] && g[t.first][i] != 0x3f3f3f3f){
				dist[i] = dist[t.first] + g[t.first][i] < dist[i] ? dist[t.first] + g[t.first][i] : dist[i];
				pq.push({i, dist[i]});
			}
		}
	}
	for(int i = 0; i < n; ++i){
		printf("%c:%d\n", i + 'a', dist[i]);
	}
	 
	return 0;
}