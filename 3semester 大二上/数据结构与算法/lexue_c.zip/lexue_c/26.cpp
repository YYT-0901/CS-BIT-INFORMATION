#include<iostream>
#include<cstring>

using namespace std;

const int N = 25;

#define x first
#define y second
long long g[N][N];

int dx[] = {2, 2, 1, 1, -2, -2, -1, -1};
int dy[] = {1, -1, 2, -2, 1, -1, 2, -2};

int main(){
	memset(g, -1, sizeof(g));
	typedef pair<int, int> PII;
	PII b, c;
	scanf("%d %d %d %d", &b.x, &b.y, &c.x, &c.y);
	
	g[c.x][c.y] = 0;
	for(int i = 0; i < 8; ++i){
		int xx = c.x + dx[i], yy = c.y + dy[i];
		if(xx < 0 || yy < 0) continue;
		if(xx > b.x || yy > b.y) continue;
		g[xx][yy] = 0;
	}
	for(int i = 0; i <= b.x; ++i){
		for(int j = 0; j <= b.y; ++j){
			if(g[i][j] == 0) continue;
			if(i == 0 && j == 0){
				g[i][j] = 1;
				continue;
			}
			if(i < 1){
				g[i][j] = g[i][j - 1];
				continue;
			}
			if(j < 1){
				g[i][j] = g[i - 1][j];
				continue;
			}
			g[i][j] = g[i - 1][j] + g[i][j - 1];
		}
	}
	printf("%lld\n", g[b.x][b.y]);
	return 0;
}