#include<iostream>
#include<algorithm>

using namespace std;

const int N = 300010;

int main(){
	pair<int, int> ti[N];
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d %d", &ti[i].second, &ti[i].first);
	}
	sort(ti, ti + n);
	
	int cnt = 0, t = 0;
	for(int i = 0; i < n; ++i){
		if(t <= ti[i].second){
			t = ti[i].first;
			cnt++;
		}
	}
	printf("%d\n", cnt);
	return 0;
}