#include<iostream>
#include<queue>

using namespace std;
queue<int> q;
int main(){
	int l = 1;
	int cnt = 0;
	int n, m, k;
	
	scanf("%d,%d,%d", &n, &k, &m);
	if(n < 1 || k < 1 || m < 1){
		printf("n,m,k must bigger than 0.\n");
	}
	else if(k > n){
		printf("k should not bigger than n.\n");
	}
	else{
		for(int i = 0; i < n; ++i){
			q.push(l++);
		}
		for(int i = 0; i < k - 1; ++i){
			auto t = q.front();
			q.pop();
			q.push(t);
		}
		
		while(q.size()){
			for(int i = 0; i < m; ++i){
				if(i < m - 1){
					auto t = q.front();
					q.push(t);
					q.pop();
				}
				else{
					printf("%d", q.front());
					q.pop();
					++cnt;
					if(cnt % 10 != 0 && q.size()){
						printf(" ");
					}
					else{
						printf("\n");
					}	
				}
			}
		}
	}
	return 0;
	
}