#include<iostream>
#include<string>
#include<cstring>
#include<queue>
#include<unordered_map>

using namespace std;

const int N = 30;
char g[N][N];

queue<string> q;
int n, m;
string ans;
unordered_map<string, int> haxi;

int dx[] = {-1, 0, 1, 0};
int dy[] = {0, 1, 0, -1};

string compress(){
	string s = "";
	for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            s += g[i][j];
        }
    }
    return s;
}

void decompress(string s){
	g[][] = {0};
	int k = 0;
	for (int i = 1; i <= n; ++i){
        for (int j = 1; j <= m; ++j){
            g[i][j] = s[k++];
        }
    }
}

int bfs(){
	bool flag = false;
	bool flag2 = false;
	int lock = 0;
	int save_push[100010] = {0};
	int push_index = 0;
	int cnt = 0;
	int cnt_push = 0;
	string s = compress();
	q.push(s);
	
	haxi.emplace(s, 1);
	if(s == ans) return cnt;
	cnt++;
	while(!q.empty()){
		string t = q.front();
		q.pop();
			for(int j = 1; j <= m; ++j){
				decompress(t);
				g[1][j] = g[1][j] == '0'? '1' : '0';
				for(int k = 0; k < 4; ++k){
					int a = 1 + dx[k], b = j + dy[k];
					
					if(a < 1 || a > n || b < 1 || b > m) continue;
					if(k == 0 && g[a][b] == '0'){ // 如果上面暗则不按
						flag2 = true;
						break;
					}
					g[a][b] = g[a][b] == '0' ? '1' : '0';
				}
			if(flag2) continue;
			
			string str = compress();
			if(str == ans) return cnt;
			
			if(haxi.count(str)){
				continue;
			}
			
			haxi.emplace(str, 1);
			q.push(str);
			cnt_push++;
			}
		}
		save_push[push_index++] = cnt_push;
		cnt_push = 0;
		if(!flag){
			++cnt;
			flag = true;
		}
		if(!save_push[lock]--){
			lock++;
			cnt++;
		}
	}
	return -1;
}

int main(){
	scanf("%d %d", &n, &m);
	for(int i = 0; i < n * m; ++i){
		ans += '0';
	}
	for(int i = 1; i <= n; ++i){
		scanf("%s", g[i] + 1);
	}
	int res = bfs();
	printf("%d\n", res);
	
	return 0;
}