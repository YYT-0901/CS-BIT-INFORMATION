#include<iostream>
#include<algorithm>

using namespace std;

const int N = 3010;

int n, v;
int a[N], b[N];
int sum;

int main(){
	cin >> n >> v;
	for(int i = 1; i <= n; ++i){
		cin >> a[i] >> b[i];
	}
	
	for(int i = 1; i < n; ++i){
		for(int j = i + 1; j <= n; ++j){
			if(a[i] > a[j]){
				int swap = a[i];
				a[i] = a[j];
				a[j] = swap;
				
				swap = b[i];
				b[i] = b[j];
				b[j] = swap;
			}
		}
	}
	
	for(int i = 1; i <= a[n] + 1; ++i){
		int cnt = v;
		for(int j = 1; j <= n && a[j] <= i; ++j){
//			k = j;
			if(i - 1 == a[j]){
				while(b[j] && cnt){
					b[j]--;
					cnt--;
					sum++;
				}
//				++k;
			}
//			k = j;
			if(a[j] == i){
				while(b[j] && cnt){
					b[j]--;
					cnt--;
					sum++;
				}
			}
		}
	}
	
	cout << sum << endl;
	return 0;
}