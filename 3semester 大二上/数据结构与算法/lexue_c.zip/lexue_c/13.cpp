#include<iostream>
#include<vector>

using namespace std;

int main(){
	bool flag = false;
	int n;
	int cnt = 0;
	int a;
	vector<int> arr;
	vector<int>::iterator p;
	vector<int>::iterator q;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d", &a);
	}
	for(int i = 0; i < n; ++i){
		q = arr.end() - 1;
		p = arr.begin();
		int k = i;
		while(k--){
			if( <= *q){
				arr.emplace(p + k, *q);
				arr.pop_back();
				cnt += k;
				break;
			}
		}
	}
	printf("%d\n", cnt);
	return 0;
}