#include<stdio.h>
#include<string.h>

int main(){
	int one = 1;
	int flag2 = 1;
	int flag = 0;
	char x[2020] = {0}, y[2020] = {0};
	int z[2020] = {0};
	int i = 0, j = 0;
	
	memset(x, 0, sizeof(x));
	memset(y, 0, sizeof(y));
	memset(z, 0, sizeof(z));
	
	scanf("%s", x);
	scanf("%s", y);

	int len_x = strlen(x);
	int len_y = strlen(y);
	
	for(i = 0, j = 0; (x[i] != '.' && i < len_x) || (y[j] != '.' && j < len_y);){
		if(x[i] != '.' && i < len_x){
			++i;
		}
		if(y[j] != '.' && j < len_y){
			++j;
		}
	}
	
	// len_x表示x数组的长度，包含‘.’在内
	// len_Lx表示x数组小数点左边的长度
	// len_Rx表示x数组小数点右边的长度
	
	// l表示小数点左边比较长的长度
	// s表示小数点左边比较短的长度
	
	// r表示小数点右边比较长的长度
	// m表示小数点右边比较短的长度
	
	// z数组从1下标开始
	// x，y数组从下标0开始
	int len_Lx = i;
	int len_Rx = len_x - len_Lx - 1;
	int len_Ly = j;
	int len_Ry = len_y - len_Ly - 1;
	
	int l = len_Lx >= len_Ly ? len_Lx : len_Ly;
	int s = l == len_Lx ? len_Ly : len_Lx;
	
	int r = len_Rx >= len_Ry ? len_Rx : len_Ry;
//	int m = r == len_Rx ? len_Ry : len_Rx;
	
	if(i >= len_x && j >= len_y){
		x[i] = '.';
		y[j] = '.';
		flag = 1;
	}
//	else if(i >= len_x){
//		x[i] = '.';
//	}
//	else if(j >= len_y){
//		y[j] = '.';
//	}

	if(!flag){
		for(int k = l + 1, o = s + 1; k < r + l + 1; ++k, ++o){
			// a表示x数组
			// b表示y数组
			int a = len_Lx >= len_Ly ? x[k] : x[o];
			int b = len_Lx >= len_Ly ? y[o] : y[k];
			b = b > 10 ? b - '0' : b;
			a = a > 10 ? a - '0' : a;
			z[k] += a + b;
			z[k - 1] += z[k] / 10;
			int cnt = k - 1;
			while(cnt > 0 && z[cnt] > 9){
				z[cnt - 1] += z[cnt] / 10;
				z[cnt] %= 10;
				cnt--;
			}
			z[k] %= 10;
		}
	}
	
	for(int k = 0, p = 0; k < l && p < s; ++k){
		int b = 0;
		if(k >= l - s){
			b = len_Lx >= len_Ly ? y[p++] : x[p++];
			b = b > 10 ? b - '0' : b;
		}
		int a = len_Lx >= len_Ly ? x[k] : y[k];
		a = a > 10 ? a - '0' : a;
		z[k + 1] += a + b;
		z[k] += z[k + 1] / 10;
		int cnt = k;
		while(cnt > 0 && z[cnt] > 9){
			z[cnt - 1] += z[cnt] / 10;
			z[cnt] %= 10;
			cnt--;
		}
		z[k + 1] %= 10;
	}
	if(z[0] > 0 && z[0] < 10){
		++l;
	}
	
	for(int k = 0; k < l - len_Lx + 3; ++k){
		printf(" ");
	}
	for(int k = 0; k < len_x; ++k){
		printf("%c", x[k]);
	}
	for(int k = 0; k < r - len_Rx; ++k){
		printf(" ");//
	}
	printf("\n");
	printf("+");
	for(int k = 0; k < l - len_Ly + 2; ++k){
		printf(" ");
	}
	for(int k = 0; k < len_y; ++k){
		printf("%c", y[k]);
	}
	for(int k = 0; k < r - len_Ry; ++k){
		printf(" ");//
	}
	printf("\n");
	for(int k = 0; k < l + r + 4; ++k){
		printf("-");
	}
	printf("\n");
	
	if(z[0] > 0 && z[0] < 10){
		--l;
	}
	printf("  ");
	for(int k = 0; k < l + 1; ++k){
		if(!z[k] && one){
			if(k == l){
				printf("0");
			}
			else{
				flag2 = 0;
				printf(" ");
			}
		}
		else{
			if(flag2){
				flag2 = 0;
				printf(" ");
			}
			one = 0;
			printf("%d", z[k]);
		}
	}
	if(!flag){
		printf(".");
		for(int k = l + 1; k < r + l + 1; ++k){
			printf("%d", z[k]);
		}
	}
	printf("\n");
	return 0;
}