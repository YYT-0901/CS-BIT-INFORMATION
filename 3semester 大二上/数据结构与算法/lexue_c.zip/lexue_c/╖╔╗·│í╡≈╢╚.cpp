#include<iostream>
#include<queue>

using namespace std;

int main(){
	int n, downTime, upTime;
	int up = 0;
	int down = 0;
	int curTime = 0;
	int downid = 5001;
	int upid = 0001;
	pair<int, int> runway[1010];
	int runTime[1010] = {0};
	queue<pair<int, int>> qdown;
	queue<pair<int, int>> qup;
	int landSum = 0;
	int takeoffSum = 0;
	float landTime = 0;
	float takeoffTime = 0;
	scanf("%d %d %d", &n, &downTime, &upTime);
	printf("Current Time: %4d\n", curTime);
	for(int i = 0; i < n; ++i){
		runway[i].first = 0;
		runway[i].second = 0;
	}
	while(1){
		scanf("%d %d", &down, &up);
		if(down < 0 && up < 0) break;
		curTime++;
		for(int i = 0; i < down; ++i){
			landSum++;
			qdown.push({downid++, curTime});
		}
		for(int i = 0; i < up; ++i){
			takeoffSum++;
			qup.push({upid++, curTime});
		}
		for(int i = 1; i <= n ;++i){
			if(runway[i].first == 0){
				if(qdown.size()){
					runway[i].first = 5;
					runway[i].second = 0;
					printf("airplane %04d is ready to land on runway %02d\n", qdown.front().first, i);
					landTime += curTime - qdown.front().second;
					qdown.pop();
				}
				else if(qup.size()){
					runway[i].first = 1;
					runway[i].second = 0;
					printf("airplane %04d is ready to takeoff on runway %02d\n", qup.front().first, i);
					takeoffTime += curTime - qup.front().second;
					qup.pop();
				}
			}
			runway[i].second++;
		}
		
		printf("Current Time: %4d\n", curTime);
		for(int i = 1; i <= n ;++i){
			if(runway[i].first == 5 && runway[i].second == downTime){
				runway[i].first = 0;
				runTime[i] += runway[i].second;
				
				runway[i].second = 0;
				printf("runway %02d is free\n", i);
				
			}
			else if(runway[i].first == 1 && runway[i].second == upTime){
				runway[i].first = 0;
				runTime[i] += runway[i].second;
				
				runway[i].second = 0;
				printf("runway %02d is free\n", i);
			}
		}
	}
	int flag = 0;
	while(flag != n){
		curTime++;
		flag = 0;
		for(int i = 1; i <= n ;++i){
			if(runway[i].first == 0){
				if(qdown.size()){
					runway[i].first = 5;
					runway[i].second = 0;
					printf("airplane %04d is ready to land on runway %02d\n", qdown.front().first, i);
					landTime += curTime - qdown.front().second;
					qdown.pop();
				}
				else if(qup.size()){
					runway[i].first = 1;
					runway[i].second = 0;
					printf("airplane %04d is ready to takeoff on runway %02d\n", qup.front().first, i);
					takeoffTime += curTime - qup.front().second;
					qup.pop();
				}
			}
			runway[i].second++;
		}
		printf("Current Time: %4d\n", curTime);
		for(int i = 1; i <= n ;++i){
			if(runway[i].first == 5 && runway[i].second == downTime){
				runway[i].first = 0;
				runTime[i] += runway[i].second;
				
				runway[i].second = 0;
				printf("runway %02d is free\n", i);
			}
			else if(runway[i].first == 1 && runway[i].second == upTime){
				runway[i].first = 0;
				runTime[i] += runway[i].second;
				
				runway[i].second = 0;
				printf("runway %02d is free\n", i);
			}
		}
		if(qdown.empty() && qup.empty()){
			for(int i = 1; i <= n; ++i){
				if(runway[i].first == 0){
					flag++;
				}
			}
		}
	}
	float total = 0.0;
	printf("simulation finished\n");
	printf("simulation time: %4d\n", curTime);
	printf("average waiting time of landing: %4.1f\n", landTime / landSum);
	printf("average waiting time of takeoff: %4.1f\n", takeoffTime / takeoffSum);
	for(int i = 1; i <= n; ++i){
		printf("runway %02d busy time: %4d\n", i, runTime[i]);
		total += runTime[i];
	}
	printf("runway average busy time percentage: %4.1f%%\n", total * 100 / curTime);
	return 0;
}