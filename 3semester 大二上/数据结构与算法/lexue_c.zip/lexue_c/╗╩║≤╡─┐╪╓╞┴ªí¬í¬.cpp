#include<iostream>
#include<vector>

using namespace std;

int cnt = 0;
int ans = 0;

bool check(vector<vector<bool>>& chess, int n){
	vector<vector<bool>> chesswalked(n, vector<bool>(n, false));
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			if(chess[i][j]){
				for(int i2 = i; i2 < n; ++i2){
					chesswalked[i2][j] = true;
				}
				for(int i2 = i - 1; i2 >= 0; --i2){
					chesswalked[i2][j] = true;
				}
				for(int j2 = j + 1; j2 < n; ++j2){
					chesswalked[i][j2] = true;
				}
				for(int j2 = j - 1; j2 >= 0; --j2){
					chesswalked[i][j2] = true;
				}
				for(int i2 = i + 1, j2 = j + 1; j2 < n && i2 < n; ++j2, ++i2){
					chesswalked[i2][j2] = true;
				}
				for(int i2 = i + 1, j2 = j - 1; j2 >= 0 && i2 < n; --j2, ++i2){
					chesswalked[i2][j2] = true;
				}
				for(int i2 = i - 1, j2 = j + 1; j2 < n && i2 >= 0; ++j2, --i2){
					chesswalked[i2][j2] = true;
				}
				for(int i2 = i - 1, j2 = j - 1; j2 >= 0 && i2 >= 0; --j2, --i2){
					chesswalked[i2][j2] = true;
				}
			}
		}
	}
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			if(!chesswalked[i][j]) return false;
		}
	}
	return true;
}

bool isValid(int x, int y, int n, vector<vector<bool>>& chess){
	for(int i = 0; i < x; ++i){
		if(chess[i][y]) return false;
	}
	for(int i = x - 1, j = y + 1; i >= 0 && j < n; --i, ++j){
		if(chess[i][j]) return false;
	}
	for(int i = x - 1, j = y - 1; i >= 0 && j >= 0; --i, --j){
		if(chess[i][j]) return false;
	}
	return true;
}

void bt(int n, int m, int start1, vector<vector<bool>>& chess){
	if(cnt == m){
		if(check(chess, n)){
			ans++;
		}
		return;
	}
	
	for(int i = start1; i < n; ++i){
		for(int j = 0; j < n; ++j){
			if(isValid(i, j, n, chess)){
				chess[i][j] = true;
				cnt++;
				bt(n, m, i+1, chess);
				chess[i][j] = false;
				cnt--;
			}
		}
	}
}

int main(){
	int n, m;
	cin >> n >> m;
	vector<vector<bool>> chess(n, vector<bool>(n, false));
	
	bt(n, m, 0, chess);

	cout << ans << endl;
	return 0;
}