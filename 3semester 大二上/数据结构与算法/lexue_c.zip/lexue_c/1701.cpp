#include<iostream>
#include<stack>
#include<cstring>

using namespace std;
const int N = 1000010;

int t, i, n, temp;
int bucket[N];
int build_color[N];
int build_height[N];
int color;
stack <int> stc, sth;

int main()
{
	scanf("%d", &t);
	while (t-- > 0){
		memset(bucket, 0, sizeof(bucket));
		while(stc.size()){
			stc.pop();
			sth.pop();
		}
		
		color = 0;
		scanf("%d", &n);
		for (i = 0; i < n; i++){
			scanf("%d", &build_color[i]);
		}
			
		for (i = 0; i < n; i++){
			scanf("%d", &build_height[i]);
		}
			
		for (i = 0; i < n; i++)
		{
			while (sth.size() && build_height[i] >= sth.top()){
				if (--bucket[stc.top()] == 0){
					color--;
				}
				sth.pop();
				stc.pop();
			}
			sth.push(build_height[i]);
			stc.push(build_color[i]);
			if(++bucket[build_color[i]] == 1) color++;
				
			printf("%d%c", color, i == n - 1 ? '\n' : ' ');
		}
	}
 
	return 0;
}