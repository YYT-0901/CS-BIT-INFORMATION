#include<iostream>
#include<algorithm>
#include<vector>

using namespace std;

long long arr[2010];
long long dp[2010][2010];

int main(){
	int n;
	long long a;
	scanf("%d", &n);
	scanf("%lld", &arr[0]);
	dp[1][arr[0]] = 1;
	long long sum = 0;

	for(long long i = 1; i <= n; ++i){
		scanf("%lld", &arr[i]);
		for(long long j = 0; j <= n + 1; ++j){
			long long l = min(arr[i - 1], j);
			long long r = max(arr[i - 1], j);
			if(arr[i] <= l){
				dp[i][r] = (dp[i - 1][j] + dp[i][r]) % 2147483647;
			}
			if(arr[i] >= r){
				dp[i][l] = (dp[i - 1][j] + dp[i][l]) % 2147483647;
			}
			if(arr[i] < r && arr[i] > l){
				dp[i][l] = (dp[i - 1][j] + dp[i][l]) % 2147483647;
				dp[i][r] = (dp[i - 1][j] + dp[i][r]) % 2147483647;
			}
		}
	}
	for(int i = 0; i <= n + 1; ++i){
		sum += dp[n][i];
		sum %= 2147483647;
	}
	printf("%lld\n", sum);
	return 0;
}