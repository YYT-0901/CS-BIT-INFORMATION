#include<stdio.h>
#include<stdlib.h>

#define N 100010

struct node{
	long long a;
	long long b;
	long long c;
	long long id;
}ball[N];

int cmp(const void *a1, const void *b1){
	struct node *aa = (struct node *)a1;
	struct node *bb = (struct node *)b1;
	if(aa -> a != bb -> a){
		return ((aa -> a) - (bb -> a));
	}
	else
	{
		if(aa -> b != bb -> b){
			return (aa -> b - bb -> b);
		}
		else{
			return ((aa -> c) - (bb -> c));
		}
	}
}

int main(){
	long long max, minMax = 0, minMaxId, cminMax, id1, id2;
	int k = 1, n, flag = 0;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d %d %d", &ball[i].a, &ball[i].b, &ball[i].c);
		if(ball[i].a < ball[i].b){
			int swap = ball[i].a;
			ball[i].a = ball[i].b;
			ball[i].b = swap;
		}
		if(ball[i].a < ball[i].c){
			int swap = ball[i].a;
			ball[i].a = ball[i].c;
			ball[i].c = swap;
		}
		if(ball[i].b < ball[i].c){
			int swap = ball[i].c;
			ball[i].c = ball[i].b;
			ball[i].b = swap;
		}
		ball[i].id = i;
		if(ball[i].c > minMax)
		{
			minMax = ball[i].c;
			minMaxId = i;
		}
	}
	qsort(ball, n, sizeof(struct node), cmp);
//	for(int i = 0; i < n; ++i){
//		printf("%d %d %d\n", ball[i].a, ball[i].b, ball[i].c);
//	}
	for(int i = 0; i < n - 1; ++i){
		if(ball[i + 1].a == ball[i].a && ball[i + 1].b == ball[i].b){
			cminMax = ball[i + 1].c + ball[i].c;
			cminMax = cminMax < ball[i].b ? cminMax : ball[i].b;
			if(cminMax > minMax){
				flag = 1;
				minMax = cminMax;
				id1 = ball[i].id;
				id2 = ball[i + 1].id;
			}
		}
	}
	
	if(!flag){
		printf("1\n%lld\n", minMaxId + 1);
	}
	else{
		if(id1 > id2)
		{
			printf("2\n%lld %lld\n", id2 + 1, id1 + 1);
		}
		else{
			printf("2\n%lld %lld\n", id1 + 1, id2 + 1);
		}	
	}
	
	return 0;
}