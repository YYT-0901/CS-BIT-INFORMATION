#include<iostream>
#include<string>
#include<queue>

using namespace std;

struct treeNode{
	char data;
	treeNode *left;
	treeNode *right;
};

string s1, s2;
queue<treeNode*> q;

void out(){
	while(q.size()){
		auto t = q.front();
		q.pop();
		
		if(t == NULL) continue;
		printf("%c", t -> data);
		q.push(t -> left);
		q.push(t -> right);
	}
}

treeNode* findh(int s, int e){
	int break2 = 0;
	static int index = e;
	if(s > e) return NULL;
	
	treeNode* p = new treeNode();
	p -> left = NULL;
	p -> right = NULL;
	
	if(s == e){
		p -> data = s1[s];
		return p;
	}
	
	for(int j = index; j > 0; --j){
		for(int i = s; i <= e; ++i){
			if(s1[i] == s2[j]){
				p -> data = s2[j];
				break2 = 1;
				p -> left = findh(s, i - 1);
				p -> right = findh(i + 1, e);
				break;
			}
		}
		if(break2) break;
	}
	return p;
}

int main(){
	cin >> s1;
	cin >> s2;
	treeNode* head = findh(0, s1.length() - 1);
	q.push(head);
	out();
	printf("\n");
	return 0;
}