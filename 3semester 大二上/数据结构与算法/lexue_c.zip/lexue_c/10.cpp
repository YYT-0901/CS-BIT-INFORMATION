#include<iostream>

using namespace std;

int main(){
	int t;
	scanf("%d", &t);
	while(t--){
		
	}
	return 0;
}