#include<iostream>
#include<string>

using namespace std;

struct treeNode{
	char data;
	treeNode *left;
	treeNode *right;
};

int cnt = 0;

treeNode* createTree(int deep){
	treeNode *p;
	char c;
	c = getchar();
	if(c == '#') p = NULL;
	else{
		p = new treeNode();
		p -> data = c;
		for(int i = 0; i < deep; ++i){
			printf("    ");
		}
		printf("%c\n", c);
		
		p -> left = createTree(deep + 1);
		p -> right = createTree(deep + 1);
		
		if(p -> left == NULL && p -> right == NULL){
			++cnt;
		}
	}
	if(c == '\n') return p;
	return p;
}

treeNode* swapTree(treeNode *head, int deep){
	treeNode *p;
	if(head == NULL) p = NULL;
	else{
		p = new treeNode();
		p -> data = head -> data;
		for(int i = 0; i < deep; ++i){
			printf("    ");
		}
		printf("%c\n", head -> data);
		
		p -> left = swapTree(head -> right, deep + 1);
		p -> right = swapTree(head -> left, deep + 1);
	}
	return p;
}

void preS(treeNode *head){
	if(head){
		printf("%c", head -> data);
		preS(head -> left);
		preS(head -> right);
	}
}

void inS(treeNode *head){
	if(head){
		inS(head -> left);
		printf("%c", head -> data);
		inS(head -> right);
	}
}

void postS(treeNode *head){
	if(head){
		postS(head -> left);
		postS(head -> right);
		printf("%c", head -> data);
	}
}

int main(){
	printf("BiTree\n");
	treeNode *head = createTree(0);
	printf("pre_sequence  : ");
	preS(head);
	printf("\n");
	printf("in_sequence   : ");
	inS(head);
	printf("\n");
	printf("post_sequence : ");
	postS(head);
	printf("\n");
	printf("Number of leaf: %d\n", cnt);
	printf("BiTree swapped\n");
	treeNode *head2 = swapTree(head, 0);
	printf("pre_sequence  : ");
	preS(head2);
	printf("\n");
	printf("in_sequence   : ");
	inS(head2);
	printf("\n");
	printf("post_sequence : ");
	postS(head2);
	printf("\n");
	
	return 0;
}