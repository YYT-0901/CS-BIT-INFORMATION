#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

vector<int> nums;
vector<int> result;
int flag = 1; // 标记原数组是大到小排序还是小到大排序

void bs(int l, int r){
	if(l > r) return;
	int m = (l + r) / 2;
	if(nums[m] == m){
		result.push_back(m);
		bs(l, m - 1);
		bs(m + 1, r);
	}
	else if(nums[m] < m){
		if(flag) bs(m + 1, r);
		else bs(l, m - 1);
	}
	else{
		if(flag) bs(l, m - 1);
		else bs(m + 1, r);
	}
}

int main(){
	int n, num;
	cin >> n;
	for(int i = 0; i < n; ++i){
		cin >> num;
		nums.push_back(num);
	}
	if(nums[0] > nums[n-1]) flag = 0;
	bs(0, n-1);
	if(result.size()){
		sort(result.begin(), result.end());
		for(auto x : result) cout << x << " ";
		cout << endl;
	}
	else{
		cout << "No " << endl;
	}
	
	
	return 0;
}