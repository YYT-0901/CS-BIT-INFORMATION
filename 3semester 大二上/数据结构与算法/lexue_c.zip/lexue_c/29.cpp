#include<iostream>
#include<cstring>

using namespace std;

long long p[2010];
long long n, v;
long long dp[2010][2010] = {0}; 

int main() {
    scanf("%d %d", &n, &v);
    dp[0][0] = 1;
    for (long long i = 1; i <= n; ++i) {
        scanf("%d", &p[i]);
        for(long long j = 0; j < v; ++j){
        	dp[i][j] = (dp[i - 1][j] + dp[i][j]) % 10000000;
        }
        for(long long j = 0; j < v; ++j){
        	dp[i][(j + p[i]) % v] = (dp[i - 1][j] + dp[i][(j + p[i]) % v]) % 10000000;
        }
    }
    printf("%lld\n", dp[n][0] - 1);
    return 0;
}
