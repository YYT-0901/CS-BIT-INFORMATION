#include<iostream>
#include<vector>

using namespace std;

vector<bool> used(15);
int sum = 0;
int num = 0;

void dfs(int x, int n, vector<vector<int>>& p, vector<vector<int>>& q, vector<int>& maxn){
		if(x == n){
			num = max(num, sum);
			return;
		}
		
		int sum2 = sum;
		for(int i = x; i < n; ++i){
			sum2 += maxn[i];
		}
		if(sum2 < num) return;
		
		for(int i = 0; i < n; ++i){
			if(!used[i]){
				used[i] = true;
				sum += p[x][i];
				dfs(x + 1, n, p, q, maxn);
				used[i] = false;
				sum -= p[x][i];
			}
		}
}

int main(){
	int n;
	cin >> n;
	vector<int> maxn(n + 10, 0);
	vector<vector<int>> p(n + 10, vector<int>(n + 10, 0));
	vector<vector<int>> q(n + 10, vector<int>(n + 10, 0));
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			cin >> p[i][j];
			maxn[i] = max(maxn[i], p[i][j]);
		}
	}
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			cin >> q[i][j];
		}
	}
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j){
			p[i][j] = p[i][j] * q[j][i];
			maxn[i] = max(maxn[i], p[i][j]);
		}
	}
	dfs(0, n, p, q, maxn);
	cout << num << endl;
	return 0;
}