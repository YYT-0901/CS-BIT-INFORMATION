#include<iostream>
#include<map>
#include<queue>
#include<vector>
#include<cstring>

using namespace std;

int main(){
	int s1, s2, s3, s4;
	int e1, e2, e3, e4;
	map<int, vector<int>> g;
	int n;
//	bool break2;
	int temp1, temp2;
	queue<int> q;
	bool vis[300010];
	int dist[300010];
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d %*d %*d %d", &temp1, &temp2);
		g[temp1].push_back(temp2);
	}
	scanf("%d %d %d %d", &s1, &s2, &s3, &s4);
	scanf("%d %d %d %d", &e1, &e2, &e3, &e4);
	
	if(s1 == e1 && s2 == e2 && s3 == e3 && s4 == e4){
		printf("1\n");
		return 0;
	}else{
		q.push(s4);
		vis[s4] = true;
		dist[s4] = 1;

		while(q.size()){
			auto t = q.front();
			q.pop();
			
			for(auto x : g[t]){
				if(vis[x]) continue;
				
				q.push(x);
				
				if(t != e1 && x == e4);
				else{
					vis[x] = true;
					dist[x] = dist[t] + 1;
				}
				
				if(t == e1 && x == e4){
//					break2 = true;
					break;
				}
			}
//			if(break2) break;
		}
	}
	printf("%d\n", dist[e4] == 0 ? -1 : dist[e4]);
	return 0;
}