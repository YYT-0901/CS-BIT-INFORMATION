#include<iostream>
#include<stack>

using namespace std;

int main(){
	int n;
	int a[200010] = {0};
	while(~scanf("%d", &n)){
		int no = 0;
		int max_h = 0;
		stack<int> st;
		while(st.size()){
			st.pop();
		}
		for(int i = 0; i < n; ++i){
			scanf("%d", &a[i]);
			max_h = max_h >= a[i] ? max_h : a[i];
		}
		
		for(int i = 0; i < n; ++i){
			if(st.size() && st.top() == a[i]){
				st.pop();
			}
			else if(st.size() && st.top() < a[i]){
				no = 1;
				break;
			}
			else{
				st.push(a[i]);
			}
		}
		
		if(no){
			printf("NO\n");
		}
		else if(st.size()){
			if(st.top() != max_h){
				printf("NO\n");
			}
			else{
				printf("YES\n");
			}
		}
		else printf("YES\n");
			
	}
	return 0;
}