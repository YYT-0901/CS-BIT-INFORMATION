#include<iostream>
#include<vector>
#include<string>

using namespace std;

vector<int> save;

int getmedian3(vector<int> &arr, int l ,int r){
	int m = (l + r) / 2;
	if(arr[l] > arr[m]) swap(arr[l], arr[m]);
	if(arr[l] > arr[r]) swap(arr[l], arr[r]);
	if(arr[m] > arr[r]) swap(arr[m], arr[r]);
	swap(arr[r - 1], arr[m]);
	save.push_back(arr[r - 1]);
	return arr[r - 1];
}

void quicksort(vector<int> &arr, int l, int r){
	const int CUTOFF = 5;
	if(r - l >= CUTOFF){
		int pivot = getmedian3(arr, l, r);
		int left = l + 1;
		int right = r - 2;
		while(left < right){
			while(arr[left] <= pivot) left++;
			while(arr[right] > pivot) right--;
			if(left < right) swap(arr[left], arr[right]);
		}
		swap(arr[left], arr[r - 1]);
		quicksort(arr, l, left - 1);
		quicksort(arr, left + 1, r);
	}
	else{
		for(int i = l; i < r; ++i){
			int end = i;
			int temp = arr[end + 1];
			while(end >= l && arr[end] > temp){
				arr[end + 1] = arr[end];
				end--;
			}
			arr[end + 1] = temp;
		}
	}
}

int main(){
	string n;
	int cnt = 0;
	vector<int> arr;
	while(true){
		cin >> n;
		if(n == "#") break;
		arr.push_back(stoi(n));
		++cnt;
	}
	quicksort(arr, 0, cnt - 1);
	printf("After Sorting:\n");
	for(int i = 0; i < cnt; ++i){
		printf("%d ", arr[i]);
	}
	printf("\nMedian3 Value:\n");
	if(save.size()){
		for(int i = 0; i < save.size(); ++i){
			printf("%d ", save[i]);
		}
		printf("\n");
	}
	else{
		printf("none\n");
	}
	return 0;
}