#include<iostream>

using namespace std;

int a[100010];
int n;
long long res = 0;

void merge(int l, int m, int r){
	int temp[100010];
	int left = l;
	int right = m + 1;
	int index = l;
	
	while(left <= m && right <= r){
		if(a[left] > a[right]){
			temp[index++] = a[right++];
			res += right - index;
		}
		else{
			temp[index++] = a[left++];
		}
	}
	while(left <= m){
		temp[index++] = a[left++];
	}
	while(right <= r){
		temp[index++] = a[right++];
	}
	while(l <= r){
		a[l] = temp[l];
		++l;
	}
}

void mergeSort(int l, int r){
	if(l + 1 > r) return;
	if(l < r){
		int m = (l + r) / 2;
		mergeSort(l, m);
		mergeSort(m + 1, r);
		merge(l, m, r);
	}
}

int main(){
	scanf("%d", &n);
	for(int i = 1; i <= n; ++i){
		scanf("%d", &a[i]);
	}
	mergeSort(1, n);
	
	for(int i = 1; i <= n; ++i){
		printf("%d ", a[i]);
	}
	printf("%lld\n", res);
	return 0;
}