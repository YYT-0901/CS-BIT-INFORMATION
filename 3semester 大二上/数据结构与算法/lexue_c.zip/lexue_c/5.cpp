#include<iostream>
#include<algorithm>

using namespace std;
const int N = 100010;

int t;
int n;
int sum = 0;

int main(){
	cin >> t;
	while(t--){
		bool break2 = false;
		int height[N] = {0};
//		memset(height, 0, sizeof(height));
		int cnt = 0;
//		bool con = true;
//		int water_cur = 0;
//		int water_sum = 0;
		cin >> n;
		for(int i = 0; i < n; ++i){
			cin >> height[i];
		}
		for(int i = 0; i < n - 1; ++i){
			if(break2){
				break;
			}
			for(int j = i + 1; j < n; ++j){
				if(height[j] >= height[i]){
					break2 = false;
					sum += (j - i - 1) * height[i] - cnt;
					cnt = 0;
					i = j - 1;
					break;
				}
				else{
					cnt += height[j];
					break2 = true;
				}
				
			}
		}
		break2 = false;
		cnt = 0;
		for(int i = n - 1; i > 0; --i){
			if(break2){
				break;
			}
			for(int j = i - 1; j >= 0; --j){
				if(height[j] >= height[i]){
					break2 = false;
					sum += (i - j - 1) * height[i] - cnt;
					cnt = 0;
					i = j + 1;
					break;
				}
				else{
					cnt += height[j];
					break2 = true;
				}
			}
		}
		cout << sum << endl;
//		for(int i = 1; i < *max_element(height, height + n); ++i){
//			if(!con){
//				break;
//			}
//			con = false;
//			water_cur = 0;
//			cnt = 0;
//			for(int j = 0; j < n; ++j){
//				if(height[j] >= i){
//					++cnt;
//					if(cnt == 2){
//						con = true;
//						cnt = 1;
//						water_sum += water_cur - 1;
//					}
//					water_cur = 0;
//				}
//				water_cur++;
//			}
//		}
//		cout << water_sum << endl;
	}
	return 0;
}