#include<iostream>
#include<cstring>

using namespace std;

int step[5][5];
char g[20][20];
char g2[20][20];
char temp[5][5];
int c[20];
char x[20];
bool flag;
bool flag2;

void back(int x, int y){
	for(int i = 0; i < 4; ++i){
		for(int j = 0; j < 4; ++j){
			g[i + (x - 1) * 4][j + (y - 1) * 4] = g2[i + (x - 1) * 4][j + (y - 1) * 4];
		}
	}
}

bool check_col(){
	memset(c, 0, sizeof(c));
	for(int i = 0; i< 16; ++i){
		switch(x[i]){
			case '0': c[0]++; break;
			case '1': c[1]++; break;
			case '2': c[2]++; break;
			case '3': c[3]++; break;
			case '4': c[4]++; break;
			case '5': c[5]++; break;
			case '6': c[6]++; break;
			case '7': c[7]++; break;
			case '8': c[8]++; break;
			case '9': c[9]++; break;
			case 'A': c[10]++; break;
			case 'B': c[11]++; break;
			case 'C': c[12]++; break;
			case 'D': c[13]++; break;
			case 'E': c[14]++; break;
			case 'F': c[15]++; break;
		}
	}
	for(int i = 0; i < 16; ++i){
		if(c[i] != 1){
			return false;
		}
	}
	return true;
}

bool check_row(int x){
	memset(c, 0, sizeof(c));
	for(int i = 0; i < 16; ++i){
		switch(g[x][i]){
			case '0': c[0]++; break;
			case '1': c[1]++; break;
			case '2': c[2]++; break;
			case '3': c[3]++; break;
			case '4': c[4]++; break;
			case '5': c[5]++; break;
			case '6': c[6]++; break;
			case '7': c[7]++; break;
			case '8': c[8]++; break;
			case '9': c[9]++; break;
			case 'A': c[10]++; break;
			case 'B': c[11]++; break;
			case 'C': c[12]++; break;
			case 'D': c[13]++; break;
			case 'E': c[14]++; break;
			case 'F': c[15]++; break;
		}
	}
	for(int i = 0; i < 16; ++i){
		if(c[i] != 1){
			return false;
		}
	}
	return true;
}

void rotate(int n, int x, int y){
	for(int i = 0; i < n; ++i){
		for(int j = 3; j >= 0; --j){
			for(int k = 0; k < 4; ++k){
				temp[3 - j][k] = g[k + (x - 1) * 4][j + (y - 1) * 4];
			}
		}
		for(int j = 0; j < 4; ++j){
			for(int k = 0; k < 4; ++k){
				g[j + (x - 1) * 4][k + (y - 1) * 4] = temp[j][k];
			}
		}
	}
	step[x - 1][y - 1] = n;
}

void dfs(int x, int y){
	if(y == 4){
		for(int i = 0; i < 4; ++i){
			rotate(i, x, y);
			
			if(check_row(4*x - 4)){
				flag = true;
				return;
			}
			else{
				back(x, y);
				step[x - 1][y - 1] = 0;
			}
		}
	}
	else{
		for(int i = 0; i < 4; ++i){
			rotate(i, x, y);
			dfs(x, y + 1);
			
			if(flag){
				return;
			}
			else{
				back(x, y);
				step[x - 1][y - 1] = 0;
			}
		}
	}
}


int main(){
	int T;
	scanf("%d", &T);
	while(T--){
		memset(g, 0, sizeof(g));
		memset(g2, 0, sizeof(g2));
		
		for(int i = 0; i < 16; ++i){
			scanf("%s", g[i]);
			for(int j = 0; j < 16; ++j){
				g2[i][j] = g[i][j];
			}
		}
	for(int i = 1; i <= 4; ++i){
		flag = false;
		dfs(i, 1);
	}
	
	flag2 = false;
	for(int i1 = 0; i1 < 2; ++i1){
		for(int i2 = 0; i2 < 2; ++i2){
			for(int i3 = 0; i3 < 2; ++i3){
				for(int i4 = 0; i4 < 2; ++i4){
					x[0] = g[0][i1 * 3];
					x[1] = g[1][i1 * 3];
					x[2] = g[2][i1 * 3];
					x[3] = g[3][i1 * 3];
					x[4] = g[4][i2 * 3];
					x[5] = g[5][i2 * 3];
					x[6] = g[6][i2 * 3];
					x[7] = g[7][i2 * 3];
					x[8] = g[8][i3 * 3];
					x[9] = g[9][i3 * 3];
					x[10] = g[10][i3 * 3];
					x[11] = g[11][i3 * 3];
					x[12] = g[12][i4 * 3];
					x[13] = g[13][i4 * 3];
					x[14] = g[14][i4 * 3];
					x[15] = g[15][i4 * 3];
					if(check_col()){
						flag2 = true;
					}
					if(flag2) break;
					for(int i = 0; i < 4; ++i){
						step[3][i] = (step[3][i] + 2) % 4;
					}
				}
				if(flag2) break;
				for(int i = 0; i < 4; ++i){
					step[2][i] = (step[2][i] + 2) % 4;
				}
			}
			if(flag2) break;
			for(int i = 0; i < 4; ++i){
				step[1][i] = (step[1][i] + 2) % 4;
			}
		}
		if(flag2) break;
		for(int i = 0;i < 4; ++i){
			step[0][i] = (step[0][i] + 2) % 4;
		}
	}
	
	int total = 0;
	int total2 = 0;
	for(int i = 0; i < 4; ++i){
		for(int j = 0; j < 4; ++j){
			total += step[i][j];
			total2 += (step[i][j] + 2) % 4;
		}
	}
	
	if(total < total2){
		printf("%d\n", total);
		for(int i = 0; i < 4; ++i){
			for(int j = 0; j < 4; ++j){
				for(int k = 0; k < step[i][j]; ++k){
					printf("%d %d\n", i + 1, j + 1);
				}
			}
		}
	}
	else{
		printf("%d\n", total2);
		for(int i = 0; i < 4; ++i){
			for(int j = 0; j < 4; ++j){
				for(int k = 0; k < (step[i][j] + 2) % 4; ++k){
					printf("%d %d\n", i + 1, j + 1);
				}
			}
		}
	}
	}
	return 0;
}