#include<iostream>
#include<algorithm>
#include<cmath>

using namespace std;

int t;
long long n;

int main(){
	cin >> t;
	while(t--){
		cin >> n;
		if(n == 1){
			cout << 0 << endl;
		}
		else{
			for(int i = 1; i <= 60; ++i){
				if(pow(2, i) >= n){
					cout << i << endl;
					break;
				}
			}
		}
	}
	return 0;
}