#include<iostream>
#include<string>

using namespace std;

int main(){
	int n;
	string s[1010];
	int cnt = 0;
	scanf("%d", &n);
	for(int k = 0; k < n; ++k){
		bool flag = false;
		cin >> s[k];
		if(s[k].length() <= 10) continue;
		
		for(int j = 0; j < k; ++j){
			if(s[j] == s[k]){
				flag = true;
				break;
			}
		}
		
		if(flag) continue;
		
		cnt++;
	}
	
	printf("%d\n", cnt);
	return 0;
}