#include<iostream>
#include<string>

using namespace std;
typedef struct GNode *GList;
struct GNode{
	int Tag;
	union{
		char data;
		GList SubList;
	};
	GList next;
};

void out(GList head){
	GList p;
	GList q = head;
	bool flag = false;
	while(q != NULL){
		p = q;
		if(p -> Tag == 1){
			if(flag){
				printf(",");
			}
			printf("(");
			out(p -> SubList);
			printf(")");
			flag = true;
		}
		else if(p -> Tag == 0){
			if(flag){
				printf(",");
			}
			flag = true;
			printf("%c", p -> data);
		}
		q = q -> next;
	}
}

GList GetHead(GList head, int *one){
	head -> next -> next = NULL;
	if(head -> next -> Tag == 1){
		head -> next = head -> next -> SubList;
		(*one)++;
	}
	return head;
}

GList GetTail(GList head){
	head -> next = head -> next -> next;
	return head;
}

int main(){
	string s;
	int k = 0;
	int left = -1;
	int cnt;
	GList head = new GNode();
	GList p;
	GList q = head;
	cin >> s;
	printf("generic list: ");
	cout << s << endl;
	while(s[k] != '\0'){
		if(s[k] == '('){
			++left;
			if(left > 0){
				p = new GNode();
				p -> Tag = 1;
				p -> next = NULL;
				p -> SubList = NULL;
				q -> next = p;
				q = q -> next;
			}
		}
		else if(s[k] == ')'){
			if(left > 0){
				q = head;
				cnt = left - 1;
				while(q -> next != NULL){
					q = q -> next;
					if(cnt && q -> Tag == 1 && q -> SubList != NULL){
						q = q -> SubList;
						cnt--;
					}
				}
			}
			--left;
		}
		else if(s[k] == ',');
		else{
			p = new GNode();
			p -> Tag = 0;
			p -> next = NULL;
			p -> data = s[k];
			if(left && s[k - 1] == '('){
				q -> SubList = p;
				q = q -> SubList;
			}
			else{
				q -> next = p;
				q = q -> next;
			}
		}
		++k;
	}
	int n;
	int one = 0;
	while(~scanf("%d", &n)){
		if(n == 1){
			printf("destroy tail\nfree list node\ngeneric list: ");
			head = GetHead(head, &one);
			if(one) printf("(");
			out(head -> next);
			if(one){
				one--;
				printf(")");
			}
			printf("\n");
			if(head -> next == NULL){
				break;
			}
			if(head -> next -> next == NULL && head -> next -> Tag == 0){
				break;
			}
		}
		else if(n == 2){
			printf("free head node\nfree list node\ngeneric list: ");
			head = GetTail(head);
			printf("(");
			out(head -> next);
			printf(")\n");
			// GList p = new GNode();
			// p -> Tag = 1;
			// p -> SubList = head -> next;
			// p -> next = NULL;
			// head -> next = p;
			if(head -> next == NULL){
				break;
			}
			if(head -> next -> next == NULL && head -> next -> Tag == 0){
				break;
			}
		}
	}
	return 0;
}