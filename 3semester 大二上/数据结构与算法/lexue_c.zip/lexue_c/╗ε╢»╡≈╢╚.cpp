#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main(){
	int n;
	vector<int> s;
	vector<int> e;
	cin >> n;
	for(int i = 0; i < n; ++i){
		int temp1, temp2;
		cin >> temp1 >> temp2;
		s.push_back(temp1);
		e.push_back(temp2);
	}
	sort(s.begin(), s.end());
	sort(e.begin(), e.end());
	int i = 0, j = 0;
	int ans = 0;
	int res = 0;
	while(i < n && j < n){
		if(s[i] < e[j]){
			++res;
			++i;
			ans = max(ans, res);
		}
		else if(s[i] > e[j]){
			--res;
			++j;
		}
		else{
			++i;
			++j;
			ans = max(ans, res);
		}
	}
	cout << ans << endl;
	return 0;
}