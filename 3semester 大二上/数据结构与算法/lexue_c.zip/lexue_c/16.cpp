#include<iostream>
#include<algorithm>

using namespace std;

int main(){
	int n;
	int hf = 0;
	int cnt = 0;
	int ffl[100010] = {0};
	int ffr[100010] = {0};
	
	scanf("%d", &n);
	getchar();
	for(int i = 0; i < n; ++i){
		int r = 0;
		int l = 0;
		char w = '0';
		while(w != '\n'){
			w = getchar();
			if(w == '(') l++;
			else if(w == ')'){
				if(l) l--;
				else r++;
			}
		}
		if(l == 0 && r == 0){
			++hf;
		}
		else if(r && l);
		else if(r){
			ffr[r]++;
		}
		else if(l){
			ffl[l]++;
		}
	}
	
	for(int i = 1; i < 100001; ++i){
		cnt += min(ffl[i], ffr[i]);
	}
	
	cnt += hf / 2;
	printf("%d\n", cnt);
	return 0;
}