#include<bits/stdc++.h>

using namespace std;
string a;
int flag = 0;
double sp = 1;
double t = 0;
int main(){
	int n;
	scanf("%d", &n);
	for(int i = 0; i < 4; ++i){
		cin >> a;
		for(int j = 0; j < n; ++j){
			sp = 1;
			
			if(a[j] == 'w') sp = 0.5;
			else if(a[j] == '>'){
				flag = 5;
			}
			else if(a[j] == 's'){
				t++;
				continue;
			}
			else if(a[j] == 'm'){
				t+=2;
				continue;
			}
			if(flag--){
				t += sp*2;
			}
			else{
				t += sp;
			}
			
			printf("%.1lf", t);
			if(i == 3){
				printf("\n");
			}
			else{
				printf(" ");
			}
		}
	}
	
}

