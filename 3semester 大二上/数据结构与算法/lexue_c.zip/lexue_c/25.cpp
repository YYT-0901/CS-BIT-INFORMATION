#include<iostream>
#include<queue>
#include<cstring>

using namespace std;
int n, m, k;
int xx1, xx2, yy1, yy2;
char g[1010][1010];
int dist[1010][1010];
queue<pair<int, int>> q;

int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};

void bfs(int x, int y){
	memset(dist, -1, sizeof(dist));
	q.push({x, y});
	dist[x][y] = 0;
	
	if(x == xx2 && y == yy2) {
		printf("0\n");
		return;
	}
	
	while(q.size()){
		auto t = q.front();
		q.pop();
		
		for(int i = 0; i < 4; ++i){
			int a = t.first, b = t.second;
			for(int j = 0; j < k; ++j){
				a += dx[i];
				b += dy[i];
				
				if(a == xx2 && b == yy2){
					printf("%d\n", dist[t.first][t.second] + 1);
					return;
				}
				
				if(a < 1 || b < 1 || a > n || b > m) break;
				if(dist[a][b] >= 0) continue;
				if(g[a][b] == '#') break;

				q.push({a, b});
				dist[a][b] = dist[t.first][t.second] + 1;
			}
		}
	}
	printf("-1\n");
	return;
}

int main(){
	scanf("%d %d %d", &n, &m, &k);
	for(int i = 1; i <= n; ++i){
		scanf("%s", g[i] + 1);
	}
	scanf("%d %d %d %d", &xx1, &yy1, &xx2, &yy2);
	
	bfs(xx1, yy1);
	return 0;
}