#include<iostream>
#include<vector>
#include<string>

using namespace std;

const int N = 100010;

vector<int> ne(N + 10);

void getNext(string &pat){
	int m = pat.length();
	for(int i = 1, j = 0; i < m; ++i){
		while(j && pat[i] != pat[j]) j = ne[j - 1];
		if(pat[i] == pat[j]) j++;
		ne[i] = j;
	}
}

int KMP(string &txt, string &pat){
	int n = txt.length();
	int m = pat.length();
	for(int i = 0, j = 0; i < n; ++i){
		while(j && txt[i] != pat[j]) j = ne[j - 1];
		if(txt[i] == pat[j]) j++;
		if(j == m) return i - m + 1;
	}
	return -1;
}

int main(){
	string pat;
	string txt;
	int index;
	cin >> txt >> pat;
	getNext(pat);
	index = KMP(txt, pat);
	cout << index;
	return 0;
}