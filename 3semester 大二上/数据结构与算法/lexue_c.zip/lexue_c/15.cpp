#include<iostream>
#include<vector>

using namespace std;

int main(){
//	a[k] + 1 + n - k;
	vector<int> a;
	bool isSorted;
	int b, n;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d", &b);
	}
	for(int i = 0; i < n; ++i){
		scanf("%d", &b);
		a.push_back(b);
	}
	int index = n - 1;
	int last_ele = a[n - 1];
	int temp = last_ele;
	
	if(last_ele == 1){
		isSorted = true;
	}
	else{
		while(index--){
			if(a[index] == temp - 1){
				if(a[index] == 1){
					isSorted = true;
				}
				temp--;
			}
			else{
				if(temp == last_ele){ // 如果最后前一个不是最后-1
					index++;
				}
				index++;
				break;
			}
		}
	}
	
	for(int i = 0; i < index; ++i){
		if(a[i] && (last_ele + 2 + i) > a[i]){ // 当前位置非零而且这个位置是不符合条件的字
			isSorted = false;
			break;
		}
	}
	
	if(isSorted){
		printf("%d\n", n - last_ele);
	}
	else{ // 如果无序，结果就是某数到自己的位置的最大值 + n
		int max;
		for(int i = 0; i < n; ++i){
			if(a[i] && (i + 2 - a[i]) > 0){ // 如果这个数在它的位置后面， 把他顶回去
				max = (i + 2 - a[i]) > max ?  (i + 2 -a[i]) : max;
			}
		}
		printf("%d\n", max + n);
	}
	
	return 0;
}