#include<iostream>

using namespace std;

typedef struct Node{
	int num;
	struct Node *next;
}people;

int main(){
	people *p, *q;
	int n, m, k;
	int l = 1;
	int cnt = 0;
	scanf("%d,%d,%d", &n, &k, &m);
	if(n < 1 || k < 1 || m < 1){
		printf("n,m,k must bigger than 0.\n");
	}
	else if(k > n){
		printf("k should not bigger than n.\n");
	}
	else{
		q = new people();
		p = q;
		q -> num = l++;
		for(int i = 1; i < n; ++i){
			q -> next = new people();
			q = q -> next;
			q -> num = l++;
		}
		q -> next = p;
		for(int i = 0; i < k - 1; ++i){
			q = q -> next;
		}
		while(q != p){
			for(int j = 0; j < m - 1; ++j){
				q = q -> next;
			}
			p = q -> next -> next;
			printf("%d", q -> next -> num);
			delete(q -> next);
			++cnt;
			if(cnt % 10 != 0){
				printf(" ");
			}
			else{
				printf("\n");
			}
			q -> next = p;
		}
		printf("%d\n", q -> num);
		delete(q);
	}
	return 0;
}