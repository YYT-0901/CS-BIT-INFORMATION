#include <iostream>
#include<vector>
using namespace std;

int dx[] = {-1, -1, -1, 0, 0, 1, 1, 1};
int dy[] = {-1, 0, 1, -1, 1, -1, 0, 1};
int n, m;
int a[10010][10010];

int check(int x, int y){
    int cnt = 0;
    for(int i = 0; i < 8; ++i){
        int x1 = x + dx[i], y1 = y + dy[i];
        if(x1 < 0 || x1 >= n || y1 < 0 || y1 >= m) continue;
        if(a[x1][y1]) cnt++;
    }
    return cnt;
}

int main()
{
  // 请在此输入您的代码
  int cnt;
  cin >> n >> m;
  for(int i = 0; i < n; ++i){
      for(int j = 0; j < m; ++j){
          cin >> a[i][j];
      }
  }
  for(int i = 0; i < n; ++i){
      for(int j = 0; j < m; ++j){
      	if(a[i][j] == 1){
      		cout << "9 ";
      	}
      	else{
      		cnt = check(i, j);
          	cout << cnt << " ";
      	}
      }
      cout << endl;
  }
  return 0;
}