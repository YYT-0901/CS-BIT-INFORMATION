#include<iostream>
#include<set>

using namespace std;

multiset<int> ms;
int main(){
	int n;
	int a;
	int ans = 0, wpl = 0;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d", &a);
		ms.insert(a);
	}
	while(ms.size() > 1){
		ans = 0;
		auto it = ms.begin();
		ans += *it;
		ms.erase(it);
		it = ms.begin();
		ans += *it;
		ms.erase(it);
		wpl += ans;
		ms.insert(ans);
	}
	printf("WPL=%d\n", wpl);
	return 0;
}