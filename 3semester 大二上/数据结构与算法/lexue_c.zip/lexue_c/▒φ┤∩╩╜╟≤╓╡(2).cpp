#include<iostream>
#include<stack>
#include<unordered_map>
#include<string>
#include<cmath>

using namespace std;

stack<int> st1;
stack<char> st2;
unordered_map<string, int> g;
string a;
int n;
string save;
int pos = 0;
int ans = 0;
int flag = 0;
bool flag_equal = false;

int doit(char op) {
	if (op == '(') {
		return 0;
	}
	else if (op == ')') {
		return 0;
	}
	int b = st1.top();
	st1.pop();
	int a = st1.top();
	st1.pop();
	switch (op) {
	case '+':return a + b; break;
	case '-':return a - b; break;
	case '*':return a * b; break;
	case '/':return a / b; break;
	case '%':return a % b; break;
	case '^':return pow(a, b); break;
	}
	return 0;
}

int main() {
	string str, s;
	while (1) {
		while (st1.size()) {
			st1.pop();
		}
		while (st2.size()) {
			st2.pop();
		}
		a = "";
		save = "";
		flag = 0;
		flag_equal = false;
		pos = 0;
		cin >> a;
		if (a == "end") break;
		while (a[pos] != '\0') {
			if (a[pos] >= 'a' && a[pos] <= 'z') {
				s = "";
				s += a[pos];
				pos++;
				while (a[pos] != '\0' && a[pos] >= 'a' && a[pos] <= 'z') {
					s += a[pos];
					pos++;
				}
				if (!g.count(s)) {
					g.insert({ s, 0 });
					save = s;
				}
				else if(flag_equal){
					st1.push(g[s]);
				}
				else {
					save = s;
				}
				pos--;
			}
			else if (a[pos] == '=') {
				flag_equal = true;
			}
			else if (a[pos] == '?') {
				string ss;
				cin >> ss;
				cout << ss << "=" << g[ss] << endl;
				flag = 1;
				break;
			}
			else if (a[pos] >= '0' && a[pos] <= '9') {
				ans = a[pos] - '0';
				pos++;
				while (a[pos] != '\0' && a[pos] >= '0' && a[pos] <= '9') {
					ans *= 10;
					ans += a[pos] - '0';
					pos++;
				}
				st1.push(ans);
				pos--;
			}
			else if (a[pos] == '(' || a[pos] == '^') {
				if (a[pos] == '(') {
					if (pos - 1 > 0 && (a[pos - 1] >= '0' && a[pos - 1] <= '9') || a[pos + 1] == '+' || a[pos + 1] == '*' || a[pos + 1] == '/' || a[pos + 1] == '%' || a[pos + 1] == '^') {
						printf("error.\n");
						flag = 3;
					}
				}
				st2.push(a[pos]);
			}
			else if (a[pos] == '*' || a[pos] == '/' || a[pos] == '%') {
				if (st2.size() && (st2.top() == '*' || st2.top() == '/' || st2.top() == '%')) {
					st1.push(doit(st2.top()));//
					st2.pop();
					st2.push(a[pos]);
				}
				else if (st2.empty() || st2.top() != '^') {
					st2.push(a[pos]);
				}
				else {
					while (st2.size() && (st2.top() != '(' && st2.top() != '+' && st2.top() != '-')) {
						st1.push(doit(st2.top()));
						st2.pop();
					}
					st2.push(a[pos]);
				}
			}
			else if (a[pos] == '+' || a[pos] == '-') {
				if (a[pos] == '-' && (pos - 1 < 0 || (a[pos - 1] == '+' || a[pos - 1] == '-' || a[pos - 1] == '*' || a[pos - 1] == '/' || a[pos - 1] == '%' || a[pos - 1] == '^' || a[pos - 1] == '=' || a[pos - 1] == '('))) {
					pos++;
					ans = a[pos] - '0';
					pos++;
					while (a[pos] != '\0' && a[pos] >= '0' && a[pos] <= '9') {
						ans *= 10;
						ans += a[pos] - '0';
						pos++;
					}
					st1.push(-ans);
					pos--;
				}
				else if (st2.size() && (st2.top() == '+' || st2.top() == '-')) {
					st1.push(doit(st2.top()));
					st2.pop();
					st2.push(a[pos]);
				}
				else if (st2.empty() || (st2.top() != '^' && st2.top() != '*' && st2.top() != '/' && st2.top() != '%')) {
					st2.push(a[pos]);
				}
				else {
					while (st2.size() && st2.top() != '(') {
						st1.push(doit(st2.top()));
						st2.pop();
					}
					st2.push(a[pos]);
				}
			}
			else if (a[pos] == ')') {
				while (st2.size() && st2.top() != '(') {
					st1.push(doit(st2.top()));
					st2.pop();
				}
				st2.pop();
			}
			pos++;
		}
		if(flag) continue;
		while (st2.size()) {
			st1.push(doit(st2.top()));
			st2.pop();
		}
		if (st1.size() == 1) {
			g[save] = st1.top();
		}
	}
	return 0;
}