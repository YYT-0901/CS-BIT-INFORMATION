#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>

using namespace std;

int main(){
	int n;
	int l = 0, r = 11;
	string s;
	while(~scanf("%d", &n)){
		if(n == 0) break;
		getline(cin, s);
		if(s == "too low"){
			l = max(l, n);
		}
		else if(s == "too high"){
			r = min(r, n);
		}
		else if(s == "right on"){
			if(n >= r || n <= l){
				cout << "Tom is dishonest" << endl;
			}
			else{
				cout << "Tom may be honest" << endl;
			}
			l = 0, r = 11;
		}
	}
	return 0;
}