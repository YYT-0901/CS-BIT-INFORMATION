#include<iostream>
#include<string>

using namespace std;

int dp[10010][256];

void KMP(string pat){
	int M = pat.length();
	dp[0][(int)pat[0]] = 1;
	int x = 0;
	for(int j = 1; j < M; ++j){
		for(int c = 0; c < 256; ++c){
			if(c == pat[j]){
				dp[j][c] = j + 1;
			}
			else{
				dp[j][c] = dp[x][c];
			}
		}
		x = dp[x][(int)pat[j]];
	}
}

int search(string txt, string pat){
	int N = txt.length();
	int M = pat.length();
	int j = 0;
	for(int i = 0; i < N; ++i){
		j = dp[j][(int)txt[i]];
		if(j == M) return i - M + 1;
	}
	return -1;
}

int main(){
	string pat;
	string txt;
	int index;
	cin >> txt >> pat;
	KMP(pat);
	index = search(txt, pat);
	cout << index;
	return 0;
}