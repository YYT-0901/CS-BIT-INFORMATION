#include<stdio.h>
#include<string.h>

int n, m;
char g[20][20] = {0};

int min_press;

int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};

void press_state(char (*p)[20], int x, int y){
	p[x][y] = p[x][y] == '1' ? '0' : '1';
	for(int i = 0; i < 4; ++i){
		int a = x + dx[i], b = y + dy[i];
		
		if(a < 1 || a > n || b < 1 || b > m) continue;
		
		p[a][b] = p[a][b] == '1' ? '0' : '1';
	}
}

int cnt_press(){
	char temp[20][20] = {0};
	int x = 0;
//	memcpy(temp, g, sizeof(g));
	for(int i = 1; i <= n; ++i){
		for(int  j = 1; j <= m; ++j){
			temp[i][j] = g[i][j];
		}
	}
	for(int i = 1; i < n; ++i){
		for(int j = 1; j <= m; ++j){
			if(temp[i][j] == '1'){ // 如果当前是亮的,则按下面的
				x++;
				press_state(temp, i + 1, j);
			}
		}
	}
	for(int i = 1; i <= m; ++i){
		if(temp[n][i] == '1') return -1; // 如果最底层不是全暗
	}
	return x;
}

void press(int x, int cnt){
	if(x > m){
		int t = cnt_press();
		if(t == -1) return; // 没有结果
		if(t + cnt < min_press) min_press = t + cnt;
		return;
	}	
	press_state(g, 1, x); // 改变点击位置g[1][x]后的状态
	press(x + 1, cnt + 1); // 按下
	press_state(g, 1, x); // 回溯状态
	press(x + 1, cnt); // 不按
}

int main(){
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; ++i){
		scanf("%s", g[i] + 1); // 地图又[1][1]开始
	}
	min_press = n * m; // 一开始设置最多
	press(1, 0);
	printf("%d\n", min_press);
	
	return 0;
}