#include<iostream>
#include<cmath>

using namespace std;

int ans = 0;
void cnt(int a, int b){
	if(a <= b){
		return;
	}
	else if(a == b + 1){
		ans++;
		return;
	}
	else{
		ans++;
		a = a - (b + 1);
		int floor = 1;
		
		if(a == 0 || floor > b) return;
		
		int need;
		need = pow(2, floor) - 1;
		
		while(a > need){
			ans += pow(2, floor - 1);
			a = a - need;
			floor++;
			need = pow(2, floor) - 1;
			if(floor > b) return;
		}
		if(a == need){
			ans += pow(2, floor - 1);
			return;
		}
		else{
			cnt(a, floor - 1);
		}
	}
	
}

int main(){
	int n;
	int a, b;
	scanf("%d", &n);
	while(n--){
		scanf("%d %d", &a, &b);
		ans = 0;
		cnt(a, b);
		printf("%d\n", ans);
	}
	return 0;
}