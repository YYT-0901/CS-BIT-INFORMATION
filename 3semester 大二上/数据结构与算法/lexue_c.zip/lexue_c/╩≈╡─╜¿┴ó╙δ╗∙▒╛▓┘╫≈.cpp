#include<iostream>

using namespace std;

int main(){
	char c;
	int left = -1;
	int pos = 0;
	int maxn = 0;
	int d = 0;
	int deep[10010];
	// char abc[10010];
	int degree[10010] = {0};
	
	c = getchar();
	while(c != '\n'){
		if(c == '('){
			left++;
		}
		else if(c == ')'){
			left--;
		}
		else if(c ==',');
		else{
			for(int i = 0; i < left; ++i){
				printf("    ");
			}
			printf("%c\n", c);
			// abc[pos] = c;
			deep[pos] = left;
			pos++;
		}
		c = getchar();
	}
	
	for(int i = 0; i < pos; ++i){
		for(int j = i + 1; j < pos; ++j){
			if(deep[i] == deep[j]){
				break;
			}
			else if(deep[i] + 1 == deep[j]){
				d++;
			}
		}
		maxn = maxn >= d ? maxn : d;
		degree[d]++;
		d = 0;
	}
	printf("Degree of tree: %d\n", maxn);
	for(int i = 0; i <= maxn; ++i){
		printf("Number of nodes of degree %d: %d\n", i, degree[i]);
	}
	return 0;
}