#include<iostream>
#include<vector>

using namespace std;

signed main(){
	int n;
	cin >> n;
	int resmin = 0x3f3f3f3f; // 因为是环, 用来记录最大的合成代价
	int resmax = 0; // 因为是环, 用来记录最小的合成代价
	vector<int> stone_sum(2 * n + 1, 0); // 用来记录石头累加的总和, 方便我直接获得一个区间内的总和
	for(int i = 1; i <= n; ++i){
		cin >> stone_sum[i]; // 读入数据
		stone_sum[i + n] = stone_sum[i]; // 复制一份在后面
	}
	for(int i = 2; i <= 2 * n; ++i){
		stone_sum[i] += stone_sum[i - 1]; // 累加操作
	}
	// dpmax[i][j] 表示从区间i到j合成的最大代价
	// dpmin[i][j] 表示从区间i到j合成的最小代价
	vector<vector<int>> dpmax(2 * n + 1, vector<int>(2 * n + 1, 0));
	vector<vector<int>> dpmin(2 * n + 1, vector<int>(2 * n + 1, 0x3f3f3f3f));
	for(int i = 1; i <= 2 * n; ++i){
		dpmin[i][i] = 0; // 自己和自己不能合并, 所以合并代价为0
	}
	for(int len = 2; len <= 2 * n; ++len){ // 遍历区间长度
		for(int i = 1; i + len - 1 <= 2 * n; ++i){ // 
			int j = i + len - 1;
			for(int k = i + 1; k <= j; ++k){ // 遍历分割k 从i到k-1这段 与 k到j这段进行合并 每个当中拿 最小/最大 的
				dpmax[i][j] = max(dpmax[i][j], dpmax[i][k - 1] + dpmax[k][j] + stone_sum[j] - stone_sum[i - 1]);
				dpmin[i][j] = min(dpmin[i][j], dpmin[i][k - 1] + dpmin[k][j] + stone_sum[j] - stone_sum[i - 1]);
			}
		}
	}
	// 处理环的合并
	for(int i = 1; i <= n; ++i){
		if(dpmax[i][n + i - 1] > resmax){
			resmax = dpmax[i][n + i - 1];
		}
		if(dpmin[i][n + i - 1] < resmin){
			resmin = dpmin[i][n + i - 1];
		}
	}
	// 输出
	cout << resmin << endl << resmax << endl;
}