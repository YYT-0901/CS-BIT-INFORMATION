#include<iostream>
#include<stack>
// 原理有待了解 
//首先我们可以分析得出:若相邻两块石头高度相同则可不考虑它们对结果的影响，因为它们可以通过垒长2宽1的石头达到最终高度。我们先找到所有石头中高度最高的石头并计算每块石头与其高度的差值，若为奇数标记为1，若为偶数标记为0。随后我们建立一个栈来使石头的标记出入栈。若当前石头标记和队尾石头标记相同则pop队尾的石头标记，否则push当前石头入栈。最后统计栈内元素个数，若小于等于1则输出yes，否则输出no。

using namespace std;

int main(){
	int n;
	int a[200010] = {0};
	while(~scanf("%d", &n)){
		int max_h = 0;
		stack<int> st;
		while(st.size()){
			st.pop();
		}
		for(int i = 0; i < n; ++i){
			scanf("%d", &a[i]);
			max_h = max_h >= a[i] ? max_h : a[i];
		}
		for(int i = 0; i < n; ++i){
			a[i] = (max_h - a[i]) % 2;

			if(st.size() && st.top() == a[i]){
				st.pop();
			}
			else{
				st.push(a[i]);
			}
		}
		
		if(st.size() <= 1){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}