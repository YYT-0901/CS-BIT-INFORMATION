#include<iostream>

using namespace std;
struct no{
	bool rev = false;
	char ch;
};
bool m[5];
bool M[5];
int index = 0;
char c;
char type;
bool flag = true;
no no1, no2;

int main(){
	c = getchar();
	while(c != '\n'){
		if(flag){
			if(c == '!'){
				no1.rev = !(no1.rev);
			}
			else if(c == '(' || c == ')');
			else{
				flag = false;
				no1.ch = c;
				type = getchar();
			}
		}
		else{
			if(c == '!'){
				no2.rev = !(no2.rev);
			}
			else if(c == '(' || c == ')');
			else{
				flag = false;
				no2.ch = c;
			}
		}
		c = getchar();
	}
	
	for(int i = 0; i < 2; ++i){
		for(int j = 0; j < 2; ++j){
			int a = i;
			int b = j;
			if(no1.ch == no2.ch){
				a = i;
				b = i;
			}
			if(no1.rev){
				a = !a;
			}
			if(no2.rev){
				b = !b;
			}
			if(type == '&'){
				if(a && b){
					m[index++] = true;
				}
				else{
					M[index++] = true;
				}
			}
			else if(type == '|'){
				if(a || b){
					m[index++] = true;
				}
				else{
					M[index++] = true;
				}
			}
			else if(type == '-'){
				if(a == 1 && b == 0){
					M[index++] = true;
				}
				else{
					m[index++] = true;
				}
			}
			else if(type == '+'){
				if(a == b){
					m[index++] = true;
				}
				else{
					M[index++] = true;
				}
			}
			
			if(no1.ch == no2.ch){
				index++;
				index++;
				break;
			}
		}
	}
	
	bool yes = true;
	for(int i = 0; i < 4; ++i){
		if(m[i]){
			if(!yes){
				printf("∨ ");
			}
			yes = false;
			printf("m%d ", i);
		}
	}
	if(yes){
		printf("0 ");
	}
	printf(";");
	yes = true;
	for(int i = 0; i < 4; ++i){
		if(M[i]){
			if(!yes){
				printf(" ∧");
			}
			yes = false;
			printf(" M%d", i);
		}
	}
	if(yes){
		printf(" 1");
	}
	printf("\n");
	
	return 0;
}