#include<iostream>
#include<vector>

using namespace std;

struct node{
	int value;
	node* left;
	node* right;
	
	node(int n){
		value = n;
		left = NULL;
		right = NULL;
	};
};

vector<int> result;

void dfs(node *head, int degree){
	if(head == NULL) return;
	
	dfs(head -> left, degree + 1);
	result.push_back(head -> value);
	for(int i = 0; i < degree; ++i){
		printf("    ");
	}
	printf("%d\n", head -> value);
	dfs(head -> right, degree + 1);
}

void create(int n, node*& head){
	node* p = head;
	if(p == NULL){
		head = new node(n);
		return;
	}
	if(n > p -> value){
		if(p -> right)
			create(n, p -> right);
		else{
			p -> right = new node(n);
		}
	}
	else{
		if(p -> left)
			create(n, p -> left);
		else{
			p -> left = new node(n);
		}
	}
}

int main(){
	node* head = NULL;
	int n;
	while(1){
		scanf("%d", &n);
		if(n == 0) break;
		create(n, head);
	}
	dfs(head, 0);
	printf("\n");
	for(int x : result){
		printf(" %d", x);
	}
	return 0;
}