#include<iostream>
#include<vector>

using namespace std;

vector<int> save;
vector<int> a(100010);
vector<int> w(100010);
int c, n, maxn = 0;

void dfs(int x, int cnt, int index){
	if(cnt > c) return;
	if(x > n){
		if(cnt > maxn){
			maxn = cnt;
			a[0] = cnt;
			save = a;
		}
		return;
	}
	a[index] = x;
	dfs(x + 1, cnt + w[x], index + 1);
	a[index] = 0;
	dfs(x + 1, cnt, index);
}

int main(){
	scanf("%d%d", &c, &n);
	
	for(int i = 1; i <= n; ++i){
		scanf("%d", &w[i]);
	}
	dfs(1, 0, 1);
	vector<int>::iterator it = save.begin();
	cout << (*it) << endl;;
	it++;
	for(;it != save.end(); ++it){
		if((*it) != 0){
			cout << (*it) << " ";
		}
	}
	cout << endl;
	return 0;
}
