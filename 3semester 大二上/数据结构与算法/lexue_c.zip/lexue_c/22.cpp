#include<iostream>
#include<queue>
#include<cstring>

using namespace std;
int T;
int n, m, k;
char g[110][110];
bool dist[110][110][55];
char ch;

typedef struct{
	int x;
	int y;
	int step;
}node;

queue<node> q;

int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};

void bfs(node p){
	node next;
	q = queue<node>();
	q.push(p);
	dist[p.x][p.y][p.step % k] = true;

	while(q.size()){
		auto cur = q.front();
		q.pop();
		
		for(int i = 0; i < 4; ++i){
			next.x = cur.x + dx[i], next.y = cur.y + dy[i];
			next.step = cur.step + 1;
			
			if(next.x < 1 || next.y < 1 || next.x > n || next.y > m) continue;
			if(g[next.x][next.y] == '#') continue;
			if(dist[next.x][next.y][next.step % k]) continue;
			if(g[next.x][next.y] == '*' && (next.step) % k != 0) continue;
			
			dist[next.x][next.y][next.step % k] = true;
			if(g[next.x][next.y] == 'E'){
				printf("%d\n", next.step);
				return;
			}
			q.push(next);
		}
	}
	printf("-1\n");
	return;
}

int main(){
	scanf("%d", &T);
	while(T--){
		scanf("%d %d %d\n", &n, &m, &k);
		memset(g, 0, sizeof(g));
		memset(dist, false, sizeof(dist));
		node start;
		for(int i = 1; i <= n; ++i){
			for(int j = 1; j <= m; ++j){
				ch = getchar();
				g[i][j] = ch;
				if(ch == 'S'){
					start.x = i;
					start.y = j;
					start.step = 0;
				}
			}
			getchar();
		}
		bfs(start);
	}
	return 0;
}