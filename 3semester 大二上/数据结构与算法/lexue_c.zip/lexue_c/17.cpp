#include<iostream>
#include<cstring>
#include<stack>

using namespace std;
const int N = 10000 + 10;
int main(){
	int t, n;
	int build_height;
	int save[N] = {0};
	int bucket[N] = {0};
	int build_color[N] = {0};
	stack<int> st;
	scanf("%d", &t);
	while(t--){
		int color = 0;
		
		memset(build_color, 0, sizeof(build_color));
		memset(save, 0, sizeof(save));
		memset(bucket, 0, sizeof(bucket));
		
		while(st.size()){
			st.pop();
		}
		
		scanf("%d", &n);
		for(int i = 0; i < n; ++i){
			scanf("%d", &build_color[i]);
		}
		
		for(int i = 0; i < n; ++i){
			int c = build_color[i];
			int k = 0;
			scanf("%d", &build_height);
			while(st.size() && build_height >= st.top()){
				k++;
				bucket[build_color[i - k]]--;
				if(bucket[build_color[i - k]] == 0) color--;
				st.pop();
			}
			
			st.push(build_height);
			bucket[c]++;
			if(bucket[c] == 1) color++;
			
			save[i] = color;
		}
		
		printf("%d", save[0]);
		for(int i = 1; i < n; ++i){
			printf(" %d", save[i]);
		}
		printf("\n");
	}
	return 0;
}