#include<iostream>

using namespace std;

int main(){
	int m1[110][5];
	int m2[110][5];
	int m3[110][5];
	int row1, row2, col1, col2, num1, num2;
	int cnt = 0;
	scanf("%d%d%d", &row1, &col1, &num1);
	for(int i = 1; i <= num1; ++i){
		scanf("%d %d %d", &m1[i][1], &m1[i][2], &m1[i][3]);
	}
	scanf("%d%d%d", &row2, &col2, &num2);
	for(int i = 1; i <= num2; ++i){
		scanf("%d %d %d", &m2[i][1], &m2[i][2], &m2[i][3]);
	}
	printf("%d\n%d\n", row1, col2);
	for(int i = 1; i <= num1; ++i){
		for(int j = 1; j <= num2; ++j){
			if(m1[i][2] == m2[j][1]){
				++cnt;
				int res = cnt - 1;
				bool flag = false;
				while(res > 0){
					if(m3[res][1] == m1[i][1] && m3[res][2] == m2[j][2]){
						m3[res][3] += m1[i][3] * m2[j][3];
						flag = true;
						if(m3[res][3] == 0){
							cnt--;
						}
						break;
					}
					res--;
				}
				if(flag){
					cnt--;
					continue;
				}
				m3[cnt][1] = m1[i][1];
				m3[cnt][2] = m2[j][2];
				m3[cnt][3] = m1[i][3] * m2[j][3];
			}
		}
	}
	printf("%d\n", cnt);
	
	for(int i = 1; i < cnt; ++i){
		for(int j = i + 1; j <= cnt; ++j){
			if(m3[i][1] > m3[j][1]){
				int temp = m3[i][1];
				m3[i][1] = m3[j][1];
				m3[j][1] = temp;
				
				temp = m3[i][2];
				m3[i][2] = m3[j][2];
				m3[j][2] = temp;
				
				temp = m3[i][3];
				m3[i][3] = m3[j][3];
				m3[j][3] = temp;
			}
			else if(m3[i][1] == m3[j][1]){
				if(m3[i][2] > m3[j][2]){
					int temp = m3[i][1];
					m3[i][1] = m3[j][1];
					m3[j][1] = temp;
					
					temp = m3[i][2];
					m3[i][2] = m3[j][2];
					m3[j][2] = temp;
					
					temp = m3[i][3];
					m3[i][3] = m3[j][3];
					m3[j][3] = temp;
				}
			}
		}
	}
	for(int i = 1; i <= cnt; ++i){
		printf("%d,%d,%d\n", m3[i][1], m3[i][2], m3[i][3]);
	}
	return 0;
}