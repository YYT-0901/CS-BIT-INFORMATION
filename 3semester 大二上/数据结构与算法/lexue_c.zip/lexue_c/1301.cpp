#include<iostream>

using namespace std;

const int N = 300010;

int n;
int arr[N];
int cnt = 0;

void quickSort(int l, int r){
	if(l >= r){
		return;
	}
	int pivot = arr[l]; // 基准数
	int i = l;
	int j = r;
	while(i < j){
		while(arr[j] >= pivot && i < j) --j;
		while(arr[i] <= pivot && i < j) ++i;
		swap(arr[i], arr[j]);
	}
	swap(arr[l], arr[i]);
	cnt += i - l;
	quickSort(l, j - 1);
	quickSort(i + 1, r);
}

int main(){
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d", &arr[i]);
	}
	quickSort(0, n);
	printf("%d\n", cnt);
	return 0;
}