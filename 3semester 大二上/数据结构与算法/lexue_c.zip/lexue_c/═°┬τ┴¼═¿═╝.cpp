#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

struct edge{
	int v, w, cost;
};

struct Unionfind{
	vector<int> parent;
	vector<int> rank;
	
	Unionfind(int n):parent(n + 1), rank(n + 1, 0){
		for(int i = 0; i <= n; ++i){
			parent[i] = i;
		}
	}
	
	int find(int x){
		if(x == parent[x]) return x;
		return parent[x] = find(parent[x]);
	}
	
	bool Union(int x, int y){
		x = find(x);
		y = find(y);
		if(x == y) return false;
		if(rank[x] < rank[y]){
			parent[x] = y;
		}
		else if(rank[x] > rank[y]){
			parent[y] = x;
		}
		else{
			parent[x] = y;
			rank[y]++;
		}
		return true;
	}
};

bool compare(const edge& a, const edge& b){
	return a.cost < b.cost;
}

int main(){
	vector<edge> edges;
	int N, M;
	cin >> N >> M;
	for(int i = 0; i < M; ++i){
		int v, w, cost;
		cin >> v >> w >> cost;
		edges.push_back({v, w, cost}); 
	}
	
	sort(edges.begin(), edges.end(), compare);
	
	Unionfind uf(N);
	int ans = 0;
	for(auto x : edges){
		if(uf.Union(x.v, x.w)){
			ans += x.cost;
		}
	}
	
	for(int i = 2; i <= N; ++i){
		if(uf.find(i) != uf.find(1)){
			cout << -1 << endl;
			return 0;
		}
	}
	cout << ans << endl;
}