#include<iostream>
#include<queue>
#include<algorithm>

using namespace std;
const int N = 300010;
bool no;
int a[N][5] = {0};
int b[3][5] = {0};
int save[N] = {0};
int state[N] = {0};
int res = -1;
int n;
queue<pair<int*, int>> q;
queue<pair<int*, int>> q2;
	
int main(){
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d %d %d %d", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
	}
	// for(int i = 0; i < n; ++i){
		// printf("%d %d %d %d\n", a[i][0], a[i][1], a[i][2], a[i][3]);
	// }
	for(int i = 0; i < 2; ++i){
		scanf("%d %d %d %d", &b[i][0], &b[i][1], &b[i][2], &b[i][3]);
	}
	q.push({b[0], 1});

	if(b[0][0] == b[1][0] && b[0][1] == b[1][1] && b[0][2] == b[1][2] && b[0][3] == b[1][3]){
		printf("1\n");
		return 0;
	}
	while(q.size() || q2.size()){
		auto t = q.front().first;
		auto r = q.front().second;
		q.pop();
		
		for(int i = 0; i < n; ++i){
			if(state[i]) continue;
			
			if(t[3] == a[i][0]){
				state[i] = 1;
				if(a[i][0] == b[1][0] && a[i][1] == b[1][1] && a[i][2] == b[1][2] && a[i][3] == b[1][3]){
					printf("%d\n", r + 1);
					return 0;
				}
				q.push({a[i], r + 1});
			}
		}
	}
	printf("%d\n", res);
	return 0;
}