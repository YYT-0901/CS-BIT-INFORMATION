#include<iostream>
#include<algorithm>
#include<cstring>

using namespace std;

int n, q;
int w[110] = {0}, v[110] = {0}, g[110] = {0};
long long dp[510][510];
long long res = -1;
int W, V;

int main(){
	memset(dp, -1, sizeof(dp));
	scanf("%d %d", &n, &q);
	dp[0][0] = 0;
	
	for(int i = 1; i <= n; ++i){
		scanf("%d %d %d", &w[i], &v[i], &g[i]);
	}
	
	for(int i = 1; i <= n; ++i){
		for(int j = 500; j >= 0; --j){
			for(int k = 500; k >= 0; --k){
				if(dp[j][k] >= 0){
					if(j + w[i] <= 500){
						dp[j + w[i]][min(k + v[i], 500)] = max(dp[j][k] + g[i], dp[j + w[i]][min(k + v[i], 500)]);
					}
				}
			}
		}
	}
	for(int i = 0; i < q; ++i){
		scanf("%d %d", &W, &V);
		res = -1;
		for(int j = 0; j <= W; ++j){
			for(int k = V; k <= 500; ++k){
				res = max(res, dp[j][k]);
			}
		}	
		printf("%lld\n", res);
	}
	
	return 0;
}