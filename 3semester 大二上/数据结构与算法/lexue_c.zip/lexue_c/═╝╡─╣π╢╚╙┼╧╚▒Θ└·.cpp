#include<iostream>
#include<vector>
#include<queue>

using namespace std;

struct u{
	char c;
	bool used = false;
	vector<int> vec;
}pai[10010];

int main(){
	char c;
	int index = 0;
	int x, y;
	while(1){
		scanf("%c", &c);
		getchar();
		if(c == '*') break;
		pai[index++].c = c;
	}
	while(1){
		scanf("%d,%d", &x, &y);
		if(x == -1 && y == -1) break;
		pai[x].vec.push_back(y);
		pai[y].vec.push_back(x);
	}
	printf("the ALGraph is\n");
	for(int i = 0; i < index; ++i){
		printf("%c", pai[i].c);
		for(int j = pai[i].vec.size() - 1; j >= 0; --j){
			printf(" %d", pai[i].vec[j]);
		}
		printf("\n");
	}
	printf("the Breadth-First-Seacrh list:");
	queue<u> q;
	q.push(pai[0]);
	pai[0].used = true;
	while(q.size()){
		auto t = q.front();
		cout << t.c;
		q.pop();
		for(int it = t.vec.size() - 1; it >= 0; --it){
			if(pai[t.vec[it]].used == true) continue;
			pai[t.vec[it]].used = true;
			q.push(pai[t.vec[it]]);
		}
	}
	for(int i = 0; i < index; ++i){
		if(!pai[i].used){
			printf("%c", pai[i].c);
		}
	}
	cout << endl;
	
	return 0;
}