#include<iostream>
#include<algorithm>

using namespace std;

const int N = 100010;
int height[N];
int h;
int n;

int main(){
	long long sum = 0;
	cin >> n >> h;
	for(int i = 0; i < n; ++i){
		scanf("%d", &height[i]);
	}
	
	height[n] = h;
	for(int i = 0; i < n; ++i){
		if(height[i + 1] - height[i] > 0){
			sum += height[i+1] - height[i];
		}
	}
	cout << sum << endl;
	return 0;
}