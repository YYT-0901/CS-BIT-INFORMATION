#include<iostream>
#include<vector>

using namespace std;

vector<int> t;
vector<int> w;
int dp[30010] = {0};
int n, m;

int main(){
	int temp1, temp2;
	scanf("%d %d", &n, &m);
	for(int i = 0; i < m; ++i){
		scanf("%d %d", &temp1, &temp2);
		t.push_back(temp1);
		w.push_back(temp2 * temp1);
	}
	for(int i = 0; i < m; ++i){
		for(int j = n; j >= t[i]; --j){
			dp[j] = max(dp[j], dp[j - t[i]] + w[i]);
		}
	}
	printf("%d\n", dp[n]);
	return 0;
}