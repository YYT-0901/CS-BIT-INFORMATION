#include<iostream>
#include<string>

using namespace std;

int s[10000];
int temp[10000];

void mergeSort(int l, int r){
	if(l >= r) return;
	
	int m = (l + r) / 2;
	mergeSort(l, m);
	mergeSort(m + 1, r);
	
	int left = l;
	int right = m + 1;
	int index = l;
	while(left <= m && right <= r){
		if(s[left] <= s[right]){
			temp[index++] = s[left++];
		}
		else{
			temp[index++] = s[right++];
		}
	}
	while(left <= m){
		temp[index++] = s[left++];
	}
	while(right <= r){
		temp[index++] = s[right++];
	}
	for(int i = l; i <= r; ++i){
		s[i] = temp[i];
	}
}


int main(){
	int n;
	cin >> n;
	for(int i = 0; i < n; ++i){
		cin >> s[i];
	}
	mergeSort(0, n - 1);
	for(int i = 0; i < n; ++i)
		cout << s[i] << endl;
	return 0;
}