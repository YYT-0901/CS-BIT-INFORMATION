#include<iostream>
#include<stack>
#include<string>

using namespace std;

int main(){
	stack<char> st;
	string a;
	int n;
	int pos = 0;
	scanf("%d", &n);	
	while(n--){
		pos = 0;
		a = "";
		cin >> a;
		while(a[pos] != '#'){
			if((a[pos] >= 'A' && a[pos] <= 'Z') || (a[pos] >= 'a' && a[pos] <= 'z')){
				printf("%c", a[pos]);
			}
			else if(a[pos] == '(' || a[pos] == '^'){
				st.push(a[pos]);
			}
			else if(a[pos] == '*' || a[pos] == '/'){
				if(st.size() && (st.top() == '*' || st.top() == '/')){
					printf("%c", st.top());
					st.pop();
					st.push(a[pos]);
				}
				else if(st.empty() || st.top() != '^'){
					st.push(a[pos]);
				}
				else{
					while(st.size() && (st.top() != '(' && st.top() != '+' && st.top() != '-')){
						printf("%c", st.top());
						st.pop();
					}
					st.push(a[pos]);
				}
			}
			else if(a[pos] == '+' || a[pos] == '-'){
				if(st.size() && (st.top() == '+' || st.top() == '-')){
					printf("%c", st.top());
					st.pop();
					st.push(a[pos]);
				}
				else if(st.empty() || (st.top() != '^' && st.top() != '*' && st.top() != '/')){
					st.push(a[pos]);
				}
				else{
					while(st.size() && st.top() != '('){
						printf("%c", st.top());
						st.pop();
					}
					st.push(a[pos]);
				}
			}
			else if(a[pos] == ')'){
				while(st.top() != '('){
					printf("%c", st.top());
					st.pop();
				}
				st.pop();
			}
			pos++;
		}
		while(st.size()){
			printf("%c", st.top());
			st.pop();
		}
		printf("\n");
	}
	return 0;
}