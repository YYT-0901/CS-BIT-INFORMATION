#include<iostream>

using namespace std;
const int N = 300010;

int arr[N];
int temp[N];
long long cnt = 0;

void merge(int l, int m, int r){
	int l_pos = l; // 左半部的起点
	int r_pos = m + 1; // 右半部起点
	int pos = l; // 临时数组下标
	
	while(l_pos <= m && r_pos <= r){ // 比较左右半区放进数组
		if(arr[l_pos] <= arr[r_pos]){
			temp[pos++] = arr[l_pos++];
		}
		else{
			temp[pos] = arr[r_pos];
			cnt += r_pos - pos;
			pos++;
			r_pos++;
		}
	}
	while(l_pos <= m){ // 左边剩下的放进数组
		temp[pos++] = arr[l_pos++];
	}
	while(r_pos <= r){ // 右边剩下的放进数组
		temp[pos++] = arr[r_pos++];
	}
	while(l <= r){ // 复制回去原数组
		arr[l] = temp[l];
		l++;
	}
}

void mergeSort(int l, int r){
	if(l < r){
		int m = (l + r) / 2;
		mergeSort(l, m);
		mergeSort(m + 1, r);
		merge(l, m, r);
	}
}

int main(){
	int n;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d", &arr[i]);
	}
	mergeSort(0, n - 1);
	printf("%lld\n", cnt);
	return 0;
}