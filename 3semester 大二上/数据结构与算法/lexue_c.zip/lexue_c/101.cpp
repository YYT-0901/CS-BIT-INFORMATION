#include<stdio.h>
#include<string.h>

int main(){
	char save[10010] = {0};
	char s[10010] = {0};
	char fh[] = "fattyhappy";
	int t;
	scanf("%d", &t);
	while(t--){
		memset(s, 0 ,sizeof(s));
		memset(save, 0, sizeof(save));
		int flag = 0;
		int cnt = 0;
		int index = 0;
		scanf("%s", s);
		int len_s = strlen(s);
		for(int i = 0; i < len_s - 9; ++i){
			index = 0;
			cnt = 0;
			int p = 0;
			for(int j = i; j < 10 + i; ++j){
				if(s[j] != fh[p++]){
					++cnt;
					save[index++] = j;
				}
				if(cnt >= 3){
					break;
				}
			}
			index = 0;
			if(cnt < 3){
				if(cnt == 0){
					printf("%d %d\n", i + 3, i + 4);
					flag = 1;
					break;
				}
				else if(cnt == 1){
					for(int k = 0; k < i; ++k){
						if(s[k] == fh[save[index] - i]){
							printf("%d %d\n", k + 1, save[index] + 1);
							flag = 1;
							break;
						}
					}
					if(flag) break;
					for(int k = i + 10; k < len_s; ++k){
						if(s[k] == fh[save[index] - i]){
							printf("%d %d\n", save[index] + 1, k + 1);
							flag = 1;
							break;
						}
					}
					if(flag) break;
				}
				else{
					if(fh[save[index] - i] == s[save[index + 1]] && fh[save[index + 1] - i] == s[save[index]]){
						printf("%d %d\n", save[index] + 1, save[index + 1] + 1);
						flag = 1;
						break;
					}
				}
			}
		}
		if(!flag){
			printf("-1\n");
		}
	}
	return 0;
}