#include<stdio.h>
#include<string.h>

int main(){
	int t;
	scanf("%d", &t);
	while(t--){
		int one = 1;
		char x[100010] = {0}, y[100010] = {0};
		int z[100010] = {0};
		int k = 0;
		scanf("%s", x);
		scanf("%s", y);
		
		int len_x = strlen(x);
		int len_y = strlen(y);
		
		for(int i = 0; i < len_x / 2; ++ i){
			int swap = x[len_x - 1 - i];
			x[len_x - i - 1] = x[i];
			x[i] = swap;
		}
		
		for(int i = 0; i < len_y / 2; ++i){
			int swap = y[len_y - 1 - i];
			y[len_y - i - 1] = y[i];
			y[i] = swap;
		}

		int n = len_x >= len_y ? len_x : len_y;
		
		for(k = 0; k < n; ++k){
			int a = x[k];
			a = a > 1 ? a - '0' : a;
			int b = y[k];
			b = b > 1 ? b - '0' : b;
			z[k] += a + b;
			z[k + 1] += z[k] / 2;
			z[k] %= 2;
		}
		if(z[k]){
			n++;
		}
		
		for(k = 0; k < n - len_x + 2; ++k){
			printf(" ");
		}
		for(int i = len_x - 1; i >= 0; --i){
			printf("%c", x[i]);
		}
		printf("\n");
		printf("+ ");
		for(int k = 0; k < n - len_y; ++k){
			printf(" ");
		}
		for(int i = len_y - 1; i >= 0; --i){
			printf("%c", y[i]);
		}
		printf("\n");
		for(int k = 0; k <= n + 1; ++k){
			printf("-");
		}
		printf("\n");
		
		for(int k = n + 1; k >= 0; --k){
			if(!z[k] && one){
				if(k == 0){
					printf("0");
				}
				else{
					printf(" ");
				}
			}
			else{
				one = 0;
				printf("%d", z[k]);
			}
		}
		printf("\n");
	}
	return 0;
}