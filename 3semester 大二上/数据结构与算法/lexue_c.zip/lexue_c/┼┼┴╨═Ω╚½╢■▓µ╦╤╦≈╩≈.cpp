// 给定一个数组，把它变成完全二叉搜索树
// 树的知识 归并排序
#include<iostream>
#include<vector>
#include<cmath>

using namespace std;

vector<int> nums;
vector<int> temp;
vector<int> result;

int getLeftLength(int n){
	int h = log2(n + 1);
	int x = n + 1 - pow(2, h);
	x = x > pow(2, h-1) ? pow(2, h-1) : x;
	return pow(2, h - 1) - 1 + x;
}

void solve(int Aleft, int Aright, int Troot){
	int n = Aright - Aleft + 1;
	if(n == 0) return;
	int L = getLeftLength(n);
	result[Troot] = nums[Aleft + L];
	solve(Aleft, Aleft + L - 1, Troot * 2 + 1);
	solve(Aleft + L + 1, Aright, Troot * 2 + 2);
}

void mergesort(int l, int r){
	if(l + 1 > r) return;
	int m = (l + r) / 2;
	mergesort(l, m);
	mergesort(m + 1, r);
	
	
	temp.resize(r + 1);
	int left = l;
	int right = m + 1;
	int index = l;
	while(left <= m && right <= r){
		if(nums[left] <= nums[right]){
			temp[index++] = nums[left++];
		}
		else{
			temp[index++] = nums[right++];
		}
	}
	while(left <= m){
		temp[index++] = nums[left++];
	}
	while(right <= r){
		temp[index++] = nums[right++];
	}
	for(int i = 0; i <= r; ++i){
		nums[i] = temp[i];
	}
}

int main(){
	int n;
	int a;
	cin >> n;
	for(int i = 0; i < n; ++i){
		cin >> a;
		nums.push_back(a);
	}
	mergesort(0, n - 1);
	result.resize(nums.size());
	solve(0, n - 1, 0);
	for(auto x : result) cout << x << " ";
	return 0;
}