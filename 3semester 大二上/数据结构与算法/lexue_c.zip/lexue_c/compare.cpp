#include <stdio.h>

int main(){
	int a,b;
	printf("inter a,b:");
	scanf("%d %d",&a,&b);
	printf("交换前，a=%d,b=%d\n",a,b);
	printf("交换后，a=%d,b=%d",b,a);
}