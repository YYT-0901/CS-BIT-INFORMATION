#include<iostream>

using namespace std;

int main(){
	int n, k, a[100010];
	long long ans_max = 0;
	long long res = 0;
	scanf("%d", &n);
	for(int i = 0; i < n; ++i){
		scanf("%d", &a[i]);
		ans_max += a[i];
	}
	scanf("%d", &k);
	
	long long l = 0, r = ans_max + 1;
	while(l + 1 < r){
		int mid = (l + r) / 2;
		res = 0;
		for(int i = 0; i < n; ++i){
			res += a[i] / mid;
		}
		if(res >= k){
			l = mid;
		}
		else{
			r = mid;
		}
	}
	printf("%lld\n", l);
	return 0;
}