#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 5e6 + 100;
const int MOD = 998244353;
char s[6];
void sol() {
    cin >> s;
    sort(s, s + 4);
    if (s[0] == s[3]) {
        cout << "No\n";
    } else {
        if (s[0] == s[2] || s[1] == s[3]) {
            cout << "Yes\n";
        } else {
            cout << "No\n";
        }
    }
}

int main() {

    int T = 1;
    cin >> T;
    while (T--) {
        sol();
    }
    exit(0);
}