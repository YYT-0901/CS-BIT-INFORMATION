import java.util.Scanner;

public class Main {

    public static boolean chk(String a) {
        if (a.charAt(0) == a.charAt(1) &&
            a.charAt(0) == a.charAt(2) &&
            a.charAt(0) != a.charAt(3)
            ) {
            return true;
        }
        if (a.charAt(0) == a.charAt(1) &&
                a.charAt(0) != a.charAt(2) &&
                a.charAt(0) == a.charAt(3)
        ) {
            return true;
        }
        if (a.charAt(0) != a.charAt(1) &&
                a.charAt(0) == a.charAt(2) &&
                a.charAt(0) == a.charAt(3)
        ) {
            return true;
        }
        if (a.charAt(1) == a.charAt(2) &&
                a.charAt(1) == a.charAt(3) &&
                a.charAt(0) != a.charAt(1)
        ) {
            return true;
        }
        if (a.charAt(0) == a.charAt(1) &&
                a.charAt(0) == a.charAt(2) &&
                a.charAt(0) == a.charAt(3)
        ) {
            return false;
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int T = in.nextInt();
        String tmp;
        while ((T--) > 0) {
            tmp = in.next();
            if (chk(tmp)) {
                System.out.println("Yes");
            } else {
                System.out.println("No");
            }
        }
        in.close();
    }
}
