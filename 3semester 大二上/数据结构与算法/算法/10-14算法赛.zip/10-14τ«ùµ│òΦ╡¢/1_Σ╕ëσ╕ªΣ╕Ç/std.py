
def chk(a):
    if (a[0] == a[1]) and (a[0] == a[2]) and (a[0] == a[3]):
        return False
    if (a[0] == a[1]) and (a[0] == a[2]) and (a[0] != a[3]):
        return True
    if (a[0] == a[1]) and (a[0] == a[3]) and (a[0] != a[2]):
        return True
    if (a[0] == a[3]) and (a[0] == a[2]) and (a[0] != a[1]):
        return True
    if (a[1] == a[2]) and (a[1] == a[3]) and (a[0] != a[1]):
        return True
    return False
    

if __name__ == '__main__':
    a = int(input())
    for i in range(0, a):
        p = input()
        if chk(p) == True:
            print("Yes")
        else:
            print("No")
        