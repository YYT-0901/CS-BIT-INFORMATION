#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 2e6 + 100;
const int MOD = 998244353;

int L[N], R[N], val[N];
int depVal[N];
int op = 1;

void build(int u, int dpt) {
    val[u] = ++depVal[dpt];
    if (dpt == 20) {
        return;
    }
    L[u] = ++op;
    build(L[u], dpt + 1);
    R[u] = ++op;
    build(R[u], dpt + 1);
}
char s[40];

void dfs(int u, char *c) {
    if (*c == '\0') {
        cout << val[u] << '\n';
        return;
    }
    if (*c == 'L') {
        dfs(L[u], c + 1);
    } else {
        dfs(R[u], c + 1);
    }
}

void sol() {
    build(1, 1);
    int n, q;
    cin >> n >> q;
    while (q--) {
        cin >> s;
        dfs(1, s);
    }
}

int main() {
    // ios::sync_with_stdio(0);
    // cin.tie(0);
    // cout.tie(0);
    int T = 1;
    // cin >> T;
    while (T--) {
        sol();
    }
    exit(0);
}