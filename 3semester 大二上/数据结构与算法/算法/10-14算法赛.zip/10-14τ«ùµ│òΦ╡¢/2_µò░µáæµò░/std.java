import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt(), T = in.nextInt();

        while ((T--) > 0) {
            String tmp = in.next();
            long ans = 1;
            for (int i = 0; i < tmp.length(); ++i) {
                if (tmp.charAt(i) == 'R') {
                    ans += (1l << (tmp.length() - i - 1));
                }
            }
            System.out.println(ans);
        }

        in.close();
    }
}
