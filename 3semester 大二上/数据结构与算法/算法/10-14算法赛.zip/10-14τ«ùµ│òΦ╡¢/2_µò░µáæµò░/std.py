def ans(a):
    n = len(a)
    p = 1
    for i in range(0, n):
        if a[i] == 'R':
            p = p + (2 ** (n - i - 1))
    return p
    

if __name__ == '__main__':
    n, q = map(int, input().split(' '))
    for i in range(0, q):
        p = input()
        print(ans(p))
        