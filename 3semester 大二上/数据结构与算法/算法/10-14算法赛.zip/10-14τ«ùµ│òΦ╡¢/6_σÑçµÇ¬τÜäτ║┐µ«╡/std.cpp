#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 2e5 + 100;

vector<int> posL[N], posR[N];
int n, q;
vector<pair<int, int> > query[N];
int ans[N];

#define lowbit(x) ((x) & (-(x)))
int sumf[N];
int get_sum(int x) {
    int sum = 0;
    while (x) {
        sum += sumf[x];
        x -= lowbit(x);
    }
    return sum;
}

void update(int pos, int val) {
    while (pos < N) {
        sumf[pos] += val;
        pos += lowbit(pos);
    }
}

void L_to_R() {
    memset(sumf, 0, sizeof(sumf));
    for (int i = 1; i < N; ++i) {
        for (int r : posL[i]) {
            update(r, 1);
        }

        for (auto [b, id] : query[i]) {
            if (b > i) {
                ans[id] = get_sum(b - 1);
            }
        }

        update(i, -posR[i].size());
    }
}

void R_to_L() {
    memset(sumf, 0, sizeof(sumf));
    for (int i = N - 1; i > 0; --i) {
        for (int l : posR[i]) {
            update(l, 1);
        }
        
        for (auto [b, id] : query[i]) {
            if (b < i) {
                ans[id] = get_sum(N - 1) - get_sum(b);
            }
        }
        update(i, -posL[i].size());
    }
}

void sol() {
    int l, r, a, b;
    cin >> n >> q;
    for (int i = 1; i <= n; ++i) {
        cin >> l >> r;
        posL[l].push_back(r);
        posR[r].push_back(l);
    }    
    for (int i = 1; i <= q; ++i) {
        cin >> a >> b;
        query[a].push_back({b, i});
    }

    L_to_R();
    R_to_L();

    for (int i = 1; i <= q; ++i) {
        cout << ans[i] << '\n';
    }
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int T = 1;
    while (T--) {
        sol();
    }
    exit(0);
}