#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 2e5 + 100;
const int MOD = 998244353;

int n, q;
pair<int, int> lr[N];

bool chk(pair<int, int> lr, int a) {
    if (lr.first <= a && lr.second >= a) return 1;
    return 0;
}

void sol() {
    cin >> n >> q;
    for (int i = 1; i <= n; ++i) {
        cin >> lr[i].first >> lr[i].second;
    }
    sort(lr + 1, lr + n + 1);
    int a, b;
    while (q--) {
        cin >> a >> b;
        int ans = 0;
        for (int i = 1; i <= n; ++i) {
            if (chk(lr[i], a) && !chk(lr[i], b)) ans ++;
        }
        cout << ans << '\n';

    }
}

int main() {
    // ios::sync_with_stdio(0);
    // cin.tie(0);
    // cout.tie(0);
    int T = 1;
    // cin >> T;
    while (T--) {
        sol();
    }
    exit(0);
}