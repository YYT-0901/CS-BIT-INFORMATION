import java.util.*;
import java.io.*;

public class Main {
    static final int N = 2 * 100000 + 100;
    static List<Integer>[] posL = new ArrayList[N];
    static List<Integer>[] posR = new ArrayList[N];
    static List<Pair<Integer, Integer>>[] query = new ArrayList[N];
    static int[] ans = new int[N];
    static int[] sumf = new int[N];

    static int lowbit(int x) {
        return x & -x;
    }

    static int getSum(int x) {
        int sum = 0;
        while (x > 0) {
            sum += sumf[x];
            x -= lowbit(x);
        }
        return sum;
    }

    static void update(int pos, int val) {
        while (pos < N) {
            sumf[pos] += val;
            pos += lowbit(pos);
        }
    }

    static void L_to_R() {
        Arrays.fill(sumf, 0);
        for (int i = 1; i < N; ++i) {
            for (int r : posL[i]) {
                update(r, 1);
            }

            for (Pair<Integer, Integer> pair : query[i]) {
                int b = pair.getKey();
                int id = pair.getValue();
                if (b > i) {
                    ans[id] = getSum(b - 1);
                }
            }

            update(i, -posR[i].size());
        }
    }

    static void R_to_L() {
        Arrays.fill(sumf, 0);
        for (int i = N - 1; i > 0; --i) {
            for (int l : posR[i]) {
                update(l, 1);
            }

            for (Pair<Integer, Integer> pair : query[i]) {
                int b = pair.getKey();
                int id = pair.getValue();
                if (b < i) {
                    ans[id] = getSum(N - 1) - getSum(b);
                }
            }

            update(i, -posL[i].size());
        }
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int T = 1;
        while (T-- > 0) {
            StringTokenizer st = new StringTokenizer(br.readLine());
            int n = Integer.parseInt(st.nextToken());
            int q = Integer.parseInt(st.nextToken());

            for (int i = 0; i < N; ++i) {
                posL[i] = new ArrayList<>();
                posR[i] = new ArrayList<>();
                query[i] = new ArrayList<>();
            }

            for (int i = 1; i <= n; ++i) {
                st = new StringTokenizer(br.readLine());
                int l = Integer.parseInt(st.nextToken());
                int r = Integer.parseInt(st.nextToken());
                posL[l].add(r);
                posR[r].add(l);
            }

            for (int i = 1; i <= q; ++i) {
                st = new StringTokenizer(br.readLine());
                int a = Integer.parseInt(st.nextToken());
                int b = Integer.parseInt(st.nextToken());
                query[a].add(new Pair<>(b, i));
            }

            L_to_R();
            R_to_L();

            for (int i = 1; i <= q; ++i) {
                System.out.println(ans[i]);
            }
        }
    }

    static class Pair<A, B> {
        private final A key;
        private final B value;

        Pair(A key, B value) {
            this.key = key;
            this.value = value;
        }

        A getKey() {
            return key;
        }

        B getValue() {
            return value;
        }
    }
}
