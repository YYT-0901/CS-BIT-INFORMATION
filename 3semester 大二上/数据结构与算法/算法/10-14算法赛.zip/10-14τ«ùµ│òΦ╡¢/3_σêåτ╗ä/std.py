def chk(x, h, n):
    pre = -1e9 - 20
    cnt = 0
    for i in range(0, n):
        if h[i] - pre > x:
            cnt += 1
            pre = h[i]
    return cnt

def sol():
    n, k = map(int, input().split())
    h = list(map(int, input().split()))
    h.sort()
    l, r = 0, h[-1] - h[0]
    ans = r
    while l <= r:
        mid = (l + r) // 2
        if chk(mid, h, n) <= k:
            ans = mid
            r = mid - 1
        else:
            l = mid + 1
    print(ans)

if __name__ == "__main__":
    T = 1
    while T > 0:
        sol()
        T -= 1
