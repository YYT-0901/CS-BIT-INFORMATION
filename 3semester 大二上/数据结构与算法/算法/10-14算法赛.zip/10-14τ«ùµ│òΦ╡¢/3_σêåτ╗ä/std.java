import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public int[] h;
    int n, k;

    public Main(int _n, int _k) {
        n = _n;
        k = _k;
        h = new int[_n];
    }

    int chk(int x) {
        int pre = -2000000000, cnt = 0;
        for (int i = 0; i < n; ++i) {
            if (h[i] - pre > x) {
                cnt ++;
                pre = h[i];
            }
        }
        return cnt;
    }

    public int get_ans() {
        Arrays.sort(h);
        int l = 0, r = h[n - 1] - h[0], mid, ans = r;
        while (l <= r) {
            mid = (l + r) >> 1;
            if (chk(mid) <= k) {
                ans = mid;
                r = mid - 1;
            } else {
                l = mid + 1;
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt(), k = in.nextInt();
        Main ans = new Main(n, k);
        for (int i = 0; i < n; ++i) {
            ans.h[i] = in.nextInt();
        }
        System.out.println(ans.get_ans());
        in.close();
    }
}

