
import java.util.Scanner;

public class Main {

    public long[] dp, sw;
    public int[] sum;
    public int n;

    public Main(int _n) {
        n = _n;
        dp = new long[n + 4];
        sw = new long[23];
        sum = new int[n + 4];
    }

    public boolean chk(int l, int r) {
        if (l <= 0) return false;
        if (sum[r] - sum[l - 1] == 0) {
            return true;
        }
        return false;
    }

    public void set_sw(int k, int s) {
        if (s > sw[k]) sw[k] = s;
    }

    long Max(long a, long b) {
        if (a > b) return a;
        else return b;
    }

    public long get_ans() {
        for (int i = 1; i <= n; ++i) {
            dp[i] = dp[i - 1];
            for (int k = 0; k <= 20; ++k) {
                int l = i - (1 << k) + 1;
                if (chk(l, i)) {
                    dp[i] = Max(dp[i], dp[l - 1] + sw[k]);
                } else {
                    break;
                }
            }
        }
        return dp[n];
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt(), m = in.nextInt(), q = in.nextInt();
        Main ans = new Main(n);
        int x, k, s;
        for (int i = 1; i <= q; ++i) {
            x = in.nextInt();
            ans.sum[x] = 1;
        }
        for (int i = 1; i <= ans.n; ++i) {
            ans.sum[i] += ans.sum[i - 1];
        }
        for (int i = 1; i <= m; ++i) {
            k = in.nextInt();
            s = in.nextInt();
            ans.set_sw(k, s);
        }
        System.out.println(ans.get_ans());

        in.close();
    }
}
