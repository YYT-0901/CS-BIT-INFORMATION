def sol():
    n, m, q = map(int, input().split())
    x_values = list(map(int, input().split()))
    sum_values = [0] * (n + 1)
    
    for x in x_values:
        sum_values[x] += 1

    for i in range(1, n + 1):
        sum_values[i] += sum_values[i - 1]

    sw = [0] * 40

    for _ in range(m):
        k, s = map(int, input().split())
        sw[k] = max(sw[k], s)

    dp = [0] * (n + 1)

    for i in range(1, n + 1):
        dp[i] = dp[i - 1]
        for k in range(21):
            l = i - (1 << k)
            if l >= 0 and sum_values[i] - sum_values[l] == 0:
                dp[i] = max(dp[i], dp[l] + sw[k])
            else:
                break

    print(dp[n])

if __name__ == "__main__":
    T = 1
    while T > 0:
        sol()
        T -= 1
