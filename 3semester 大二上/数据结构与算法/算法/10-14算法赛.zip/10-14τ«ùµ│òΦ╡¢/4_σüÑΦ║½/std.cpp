#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 2e5 + 100;
const int MOD = 998244353;

ll dp[N];
int sum[N];
int n, m, q;
ll sw[40];

void sol() {
    cin >> n >> m >> q;
    int x;
    for (int i = 1; i <= q; ++i) {
        cin >> x;
        sum[x] ++;
    }
    for (int i = 1; i <= n; ++i) {
        sum[i] += sum[i - 1];
    }
    ll k, s;
    for (int i = 1; i <= m; ++i) {
        cin >> k >> s;
        sw[k] = max(sw[k], s);
    }

    for (int i = 1; i <= n; ++i) {
        dp[i] = dp[i - 1];
        for (int k = 0; k <= 20; ++k) {
            int l = i - (1 << k); // 2 ^ k
            if ((l >= 0) && (sum[i] - sum[l] == 0)) {
                dp[i] = max(dp[i], dp[l] + sw[k]);
            } else {
                break;
            }
        }
    }
    cout << dp[n] << endl;
}

// 背包九讲

int main() {
    int T = 1;
    while (T--) {
        sol();
    }
    exit(0);
}