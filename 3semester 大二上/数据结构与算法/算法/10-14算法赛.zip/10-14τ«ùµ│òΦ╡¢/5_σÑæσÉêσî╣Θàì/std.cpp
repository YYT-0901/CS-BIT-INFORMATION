#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 2e6 + 100;

int n;
char s[N], t[N];
int nxts[N];

void get_next(char *s, int *next, int n) {
    next[1] = 0;
    for (int i = 2, j = 0; i <= n; ++i) {
        while (j > 0 && s[j + 1] != s[i]) j = next[j];
        if (s[i] == s[j + 1]) ++j;
        next[i] = j;
    }
}

void sol() {
    cin >> n;
    cin >> s + 1;
    cin >> t + 1;
    for (int i = 1; i <= n; ++i) {
        if (s[i] >= 'a' && s[i] <= 'z') {
            s[i] += 'A' - 'a';
        } else if (s[i] >= 'A' && s[i] <= 'Z') {
            s[i] += 'a' - 'A';
        }
        s[i + n] = s[i];
    }
    get_next(t, nxts, n);
    int Mx = -1e9, Mn = 1e9;
    for (int i = 1, j = 0; i <= n + n; ++i) {

        while (j && s[i] != t[j + 1]) j = nxts[j];
        if (s[i] == t[j + 1]) ++j;
        if (j == n) {
            Mx = max(Mx, i - n + 1);
            Mn = min(Mn, i - n + 1);
            j = nxts[j];            
        }
    }
    if (Mx >= Mn) {
        cout << "Yes" << endl;
        int ans = min(Mx - 1, n + 1 - Mx);
        ans = min(ans, Mn - 1);
        ans = min(ans, n + 1 - Mn);
        cout << ans << endl;
    } else {
        cout << "No" << endl;
    }
}

int main() {
    int T = 1;
    while (T--) {
        sol();
    }
    exit(0);
}