import java.util.Scanner;

public class Main {

    public int n;
    public char[] s, t;
    public int[] nxts;

    public Main(int _n) {
        n = _n;
        s = new char[n + n + 10];
        t = new char[n + 10];
        nxts = new int[n + 10];
    }

    void get_next(char s[], int next[], int n) {
        next[1] = 0;
        for (int i = 2, j = 0; i <= n; ++i) {
            while (j > 0 && s[j + 1] != s[i]) j = next[j];
            if (s[i] == s[j + 1]) ++j;
            next[i] = j;
        }
    }

    int Max(int a, int b) {
        if (a > b) return a;
        return b;
    }

    int Min(int a, int b) {
        if (a < b) return a;
        return b;
    }

    void get_ans() {
        for (int i = 1; i <= n; ++i) {
            if (s[i] >= 'a' && s[i] <= 'z') {
                s[i] += 'A' - 'a';
            } else if (s[i] >= 'A' && s[i] <= 'Z') {
                s[i] += 'a' - 'A';
            }
            s[i + n] = s[i];
        }
        get_next(t, nxts, n);
        int Mx = -1000000000, Mn = 1000000000;
        for (int i = 1, j = 0; i < n + n; ++i) {
            while (j > 0 && s[i] != t[j + 1]) j = nxts[j];
            if (s[i] == t[j + 1]) ++j;
            if (j == n) {
                Mx = Max(Mx, i - j + 1);
                Mn = Min(Mn, i - j + 1);
                j = nxts[j];
            }
        }
        if (Mx >= Mn) {
            System.out.println("Yes");
            int ans = Min(Mx - 1, n + 1 - Mx);
            ans = Min(ans, Mn - 1);
            ans = Min(ans, n + 1 - Mn);
            System.out.println(ans);
        } else {
            System.out.println("No");
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        Main ans = new Main(n);
        String tmp = in.next();
        for (int i = 0; i < n; ++i) {
            ans.s[i + 1] = tmp.charAt(i);
        }
        tmp = in.next();
        for (int i = 0; i < n; ++i) {
            ans.t[i + 1] = tmp.charAt(i);
        }

        ans.get_ans();

        in.close();
    }
}
