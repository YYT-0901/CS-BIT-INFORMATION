def get_next(s, n):
    nxts = [0] * (n + 1)
    nxts[1] = 0
    j = 0
    for i in range(2, n + 1):
        while j > 0 and s[j + 1] != s[i]:
            j = nxts[j]
        if s[i] == s[j + 1]:
            j += 1
        nxts[i] = j
    return nxts

def sol():
    n = int(input())
    s = input()
    t = input()
    lent = n
    s = s + s  # 将s复制一遍，以处理循环字符串的情况
    s = s.swapcase()
    # n *= 2
    s = ' ' + s
    t = ' ' + t
    t_nxt = get_next(t, lent)
    
    Mx = -1e9
    Mn = 1e9
    j = 0
    
    for i in range(1, n + n + 1):
        while j > 0 and s[i] != t[j + 1]:
            j = t_nxt[j]
        if s[i] == t[j + 1]:
            j += 1
        if j == lent:
            Mx = max(Mx, i - lent + 1)
            Mn = min(Mn, i - lent + 1)
            j = t_nxt[j]

    if Mx >= Mn:
        print("Yes")
        ans = min(Mx - 1, n + 1 - Mx)
        ans = min(ans, Mn - 1)
        ans = min(ans, n + 1 - Mn)
        print(ans)
    else:
        print("No")

if __name__ == "__main__":
    T = 1
    while T > 0:
        sol()
        T -= 1
