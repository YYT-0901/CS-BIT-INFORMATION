#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int N = 2e6 + 100;
const int MOD = 998244353;
int n;
char S[N], T[N];

char grg(char s){
    if (s >= 'a' && s <= 'z') {
        s += 'A' - 'a';
    } else {
        s += 'a' - 'A';
    }
    return s;
}

bool chk(int x) {
    for (int i = 0; i < n; ++i) {
        if (S[(i + x) % n] != T[i]) return 0;
    }
    return 1;
}

void sol() {
    cin >> n;
    cin >> S >> T;
    for (int i = 0; i < n; ++i) {
        S[i] = grg(S[i]);
    }    
    // cout << S << ' ' << T << endl;
    int ans = 1e9;
    for (int i = 0; i < n; ++i) {
        if (chk(i)) {
            // cout << 1 << endl;
            ans = min(ans, n - i - 1);
            ans = min(ans, i);
        }
    }
    if (ans < 100000000) {
        cout << "Yes" << endl;
        cout << ans << endl;
    } else {
        cout << "No" << endl;
    }
    
}

int main() {
    // ios::sync_with_stdio(0);
    // cin.tie(0);
    // cout.tie(0);
    int T = 1;
    // cin >> T;
    while (T--) {
        sol();
    }
    exit(0);
}