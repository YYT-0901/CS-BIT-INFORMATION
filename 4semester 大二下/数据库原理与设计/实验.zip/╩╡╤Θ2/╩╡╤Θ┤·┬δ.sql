use sales;

# 1
SELECT 供应商名称, 供应商地址, 供应商电话 from supplier;

# 2
SELECT * FROM orders
WHERE STR_TO_DATE(订单日期, '%Y/%m/%d') BETWEEN '2014-01-01' AND '2014-10-31'
AND 订单总金额 > 1000;

# 3
SELECT orders.顾客编号, customer.姓名, SUM(orders.订单总金额) AS 订单总金额  FROM orders INNER JOIN customer ON orders.顾客编号 = customer.顾客编号
GROUP BY 顾客编号;

# 4
SELECT orders.顾客编号, customer.姓名
FROM orders INNER JOIN customer ON orders.顾客编号 = customer.顾客编号
GROUP BY 顾客编号
HAVING AVG(orders.订单总金额) > 1000;

# 5
SELECT s1.供应商编号, s1.供应商名称, s1.供应商地址
FROM supplier s1 INNER JOIN supplier s2 ON s1.国家编号 = s2.国家编号
WHERE s2.供应商名称 = '金仓集团';

# 6
SELECT 零件名称, 制造商, 零售价格, 供应价格
FROM part INNER JOIN partsupp ON part.零件编号 = partsupp.零件编号
WHERE 供应价格 > 零售价格;

# 7
SELECT l.订单编号, 订单总金额, 零件编号
FROM lineitem l INNER JOIN orders o ON l.订单编号 = o.订单编号
INNER JOIN customer c ON c.顾客编号 = o.顾客编号
WHERE 姓名 = '阿波罗';

