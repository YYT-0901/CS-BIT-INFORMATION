use sales;

-- 创建名为BIT的用户，密码为1234
CREATE USER BIT IDENTIFIED BY "1234";

-- 授于查找订单明细表的权限
GRANT SELECT ON lineitem TO BIT;

-- 授予修改订单明细表中折扣的权限
GRANT UPDATE (折扣) ON lineitem TO BIT;

-- 收回所有权限
REVOKE ALL PRIVILEGES ON *.* FROM 'BIT'@'%';

-- 显示权限
SHOW GRANTS FOR 'BIT'@'%';