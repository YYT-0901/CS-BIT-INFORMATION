create table customer
(
    顾客编号 int          not null
        primary key,
    姓名     varchar(255) null,
    国籍编号 int          null
);

create index 国籍编号
    on customer (国籍编号);

create table lineitem
(
    订单编号   int            not null,
    零件编号   int            not null,
    供应商编号 int            not null,
    数量       int            null,
    退货标记   char           null,
    折扣       decimal(10, 9) null,
    primary key (订单编号, 零件编号, 供应商编号)
);

create index 供应商编号
    on lineitem (供应商编号);

create index 零件编号
    on lineitem (零件编号);

create table nation
(
    国家编号 int          not null
        primary key,
    国家名称 varchar(255) null,
    地区编号 int          null,
    备注     text         null
);

create index 地区编号
    on nation (地区编号);

create table orders
(
    订单编号   int            not null
        primary key,
    顾客编号   int            null,
    订单日期   text           null,
    订单总金额 decimal(10, 2) null
);

create index 顾客编号
    on orders (顾客编号);

create table part
(
    零件编号 int            not null
        primary key,
    零件名称 varchar(255)   null,
    制造商   varchar(255)   null,
    尺寸     varchar(50)    null,
    零售价格 decimal(10, 2) null
);

create table partsupp
(
    零件编号   int            not null,
    供应商编号 int            not null,
    可用数量   int            null,
    供应价格   decimal(10, 2) null,
    primary key (零件编号, 供应商编号)
);

create index 供应商编号
    on partsupp (供应商编号);

create table region
(
    地区编号 int          not null
        primary key,
    地区名称 varchar(255) null,
    备注     text         null
);

create table supplier
(
    供应商编号 int          not null
        primary key,
    供应商名称 varchar(255) null,
    供应商地址 varchar(255) null,
    国家编号   int          null,
    供应商电话 varchar(20)  null
);

create index 国家编号
    on supplier (国家编号);

