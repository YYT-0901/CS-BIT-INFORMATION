# （1）
SELECT * FROM customer
WHERE 顾客编号 IN (
    SELECT o.顾客编号 FROM orders o
    JOIN lineitem l ON o.订单编号 = l.订单编号
    JOIN part p ON l.零件编号 = p.零件编号
    WHERE p.制造商 = '徐州市泰力公司矿山设备四厂' AND p.零件名称 = '活塞式减压阀'
);

# （2）
SELECT * FROM customer
WHERE 顾客编号 NOT IN (
    SELECT o.顾客编号 FROM orders o
    JOIN lineitem l ON o.订单编号 = l.订单编号
    JOIN part p ON l.零件编号 = p.零件编号
    WHERE p.制造商 = '徐州市泰力公司矿山设备四厂' AND p.零件名称 = '活塞式减压阀'
);

# （3）
SELECT * FROM customer
WHERE 国籍编号=(SELECT nation.国家编号 FROM nation WHERE 国家名称='中国') AND 顾客编号 IN (
    SELECT 顾客编号 FROM orders
                GROUP BY orders.顾客编号
                HAVING AVG(订单总金额) > 500
    );

# （4）
SELECT * FROM part
WHERE 零件编号 IN (
    SELECT 零件编号 from lineitem
                         WHERE 订单编号 IN (
                             SELECT 订单编号 FROM orders
                                         WHERE 顾客编号 IN (
                                             SELECT 顾客编号 FROM customer
                                                         WHERE 姓名='薜融'
                                             )
                             )
    ) AND 零件编号 NOT IN (
        SELECT 零件编号 from lineitem
                         WHERE 订单编号 IN (
                             SELECT 订单编号 FROM orders
                                         WHERE 顾客编号 IN (
                                             SELECT 顾客编号 FROM customer
                                                         WHERE 姓名='宣荣揣'
                                             )
                             )
    );

# 二（1）
CREATE TRIGGER AfterLineitemInsert
AFTER INSERT ON Lineitem
FOR EACH ROW
BEGIN
    DECLARE retail_price DECIMAL(10, 2);
    DECLARE itemTotal DECIMAL(10, 2);

    -- 获取零售价格
    SELECT 零售价格 INTO retail_price FROM part WHERE part.零件编号 = NEW.零件编号;
    SET itemTotal = retail_price * NEW.数量 * (1-NEW.折扣);

    -- 更新对应订单的总金额
    UPDATE Orders
    SET 订单总金额 = 订单总金额 + itemTotal
    WHERE 订单编号 = NEW.订单编号;
END;

# 二（1） 测试用例
INSERT INTO lineitem VALUES (1,1,1,1,0,0.5);

# 二（2）
CREATE TRIGGER before_update
BEFORE UPDATE ON lineitem
FOR EACH ROW
BEGIN
    DECLARE available_count INT;
    SELECT 可用数量 INTO available_count FROM partsupp
        WHERE 零件编号 = NEW.零件编号 AND 供应商编号 = NEW.供应商编号;

    -- 判断
    IF NEW.数量 > available_count THEN
        -- 自定义错误
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = '更新失败：零件供应不足。';
    END IF;
END;

# 二（2） 测试用例
UPDATE lineitem SET 数量=15 WHERE 订单编号=1 AND 零件编号=1 AND 供应商编号=1;